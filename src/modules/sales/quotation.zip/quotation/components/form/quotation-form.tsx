// "use client";

// import { useEffect } from "react";
// import { useForm, FormProvider } from "react-hook-form";
// import { zodResolver } from "@hookform/resolvers/zod";
// import { notify } from "@/lib/toast";

// import { quotationCreateSchema } from "../../schemas/quotation.schema";
// import {
//   useCreateQuotationMutation,
//   useUpdateQuotationMutation,
// } from "../../api/quotation.api";

// import type {
//   QuotationFormProps,
//   QuotationFormValues,
// } from "../../types/quotation-form.types";
// import {
//   getDefaultQuotationValues,
//   mapQuotationToFormValues,
// } from "../../utils/quotation-form.utils";

// import { QuotationDetailsSection } from "./quotation-details-section";
// import { QuotationPartiesSection } from "./quotation-parties-section";
// import { QuotationItemsSection } from "./quotation-items-section";
// import { QuotationSummarySection } from "./quotation-summary-section";
// import { QuotationAdditionalsSection } from "./quotation-additionals-section";
// import { QuotationPaymentSection } from "./quotation-payment-section";
// import { QuotationSignatureSection } from "./quotation-signature-section";
// import { QuotationFormActions } from "./quotation-form-actions";

// export function QuotationForm({
//   mode,
//   quotation,
//   onSuccess,
//   onCancel,
// }: QuotationFormProps) {
//   const [createQuotation, { isLoading: isCreating }] =
//     useCreateQuotationMutation();
//   const [updateQuotation, { isLoading: isUpdating }] =
//     useUpdateQuotationMutation();

//   const isSubmitting = isCreating || isUpdating;

//   const form = useForm<QuotationFormValues>({
//     resolver: zodResolver(quotationCreateSchema),
//     defaultValues:
//       mode === "edit" && quotation
//         ? mapQuotationToFormValues(quotation)
//         : getDefaultQuotationValues(),
//     mode: "onBlur",
//   });

//   const { handleSubmit, reset } = form;

//   useEffect(() => {
//     if (mode === "edit" && quotation) {
//       reset(mapQuotationToFormValues(quotation));
//     }
//   }, [mode, quotation, reset]);

//   const onSubmit = async (values: QuotationFormValues) => {
//     try {
//       if (mode === "create") {
//         const res = await createQuotation(values).unwrap();
//         notify.success(res.message || "Quotation created successfully");
//         onSuccess?.(res.data);
//       } else if (mode === "edit" && quotation?.id) {
//         const { createdBy, businessId, ...rest } = values;

//         const res = await updateQuotation({
//           id: quotation.id,
//           data: {
//             ...rest,
//             updatedBy: createdBy || "current-user", // TODO: real user id
//           },
//         }).unwrap();

//         notify.success(res.message || "Quotation updated successfully");
//         onSuccess?.(res.data);
//       }
//     } catch (err: any) {
//       notify.error(
//         err?.data?.message || err?.message || "Something went wrong",
//       );
//     }
//   };

//   return (
//     <FormProvider {...form}>
//       <form onSubmit={handleSubmit(onSubmit)} className="space-y-6" noValidate>
//         <QuotationDetailsSection />
//         <QuotationPartiesSection />
//         <QuotationItemsSection />

//         {/* Payment + Summary */}
//         <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
//           <div className="xl:col-span-2">
//             <QuotationPaymentSection />
//           </div>
//           <QuotationSummarySection />
//         </div>

//         {/* Terms + Signature */}
//         <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
//           <div className="xl:col-span-2">
//             <QuotationAdditionalsSection />
//           </div>
//           <QuotationSignatureSection />
//         </div>

//         <QuotationFormActions
//           mode={mode}
//           isSubmitting={isSubmitting}
//           onCancel={onCancel}
//         />
//       </form>
//     </FormProvider>
//   );
// }

// export default QuotationForm;




"use client";

import { useEffect, useMemo } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { notify } from "@/lib/toast";

import { quotationCreateSchema } from "../../schemas/quotation.schema";
import {
  useCreateQuotationMutation,
  useUpdateQuotationMutation,
} from "../../api/quotation.api";

import type {
  QuotationFormProps,
  QuotationFormValues,
} from "../../types/quotation-form.types";
import {
  getDefaultQuotationValues,
  mapQuotationToFormValues,
} from "../../utils/quotation-form.utils";

import { useCurrentSession } from "@/modules/sales/shared/hooks/use-current-session";

import { QuotationDetailsSection } from "./quotation-details-section";
import { QuotationPartiesSection } from "./quotation-parties-section";
import { QuotationItemsSection } from "./quotation-items-section";
import { QuotationSummarySection } from "./quotation-summary-section";
import { QuotationAdditionalsSection } from "./quotation-additionals-section";
import { QuotationPaymentSection } from "./quotation-payment-section";
import { QuotationSignatureSection } from "./quotation-signature-section";
import { QuotationFormActions } from "./quotation-form-actions";

/**
 * Build form defaults from current session (business + user).
 * Used for create mode so "Quotation From" is pre-filled.
 */
function getSessionDefaults(
  session: ReturnType<typeof useCurrentSession>["data"],
): Partial<QuotationFormValues> {
  if (!session) return {};

  const { business, user } = session;

  return {
    // Business ("Quotation From")
    businessId: business?.id ?? undefined,
    businessName: business?.name ?? "",
    businessLegalName: business?.legalName ?? undefined,
    businessGSTIN: business?.gstin ?? undefined,
    businessPhone: business?.phone ?? undefined,
    businessEmail: business?.email ?? undefined,

    // Audit
    createdBy: user?.id ?? undefined,
  };
}

export function QuotationForm({
  mode,
  quotation,
  onSuccess,
  onCancel,
}: QuotationFormProps) {
  const [createQuotation, { isLoading: isCreating }] =
    useCreateQuotationMutation();
  const [updateQuotation, { isLoading: isUpdating }] =
    useUpdateQuotationMutation();

  const { data: session } = useCurrentSession();

  const isSubmitting = isCreating || isUpdating;

  const sessionDefaults = useMemo(
    () => getSessionDefaults(session),
    [session],
  );

  const form = useForm<QuotationFormValues>({
    resolver: zodResolver(quotationCreateSchema),
    defaultValues:
      mode === "edit" && quotation
        ? mapQuotationToFormValues(quotation)
        : {
            ...getDefaultQuotationValues(),
            ...sessionDefaults,
          },
    mode: "onBlur",
  });

  const { handleSubmit, reset } = form;

  // Edit: always prefer quotation payload when it changes
  useEffect(() => {
    if (mode === "edit" && quotation) {
      reset(mapQuotationToFormValues(quotation));
    }
  }, [mode, quotation, reset]);

  // Create: apply session defaults once session is available
  // (covers both initial mount and late-loaded session)
  useEffect(() => {
    if (mode !== "create" || !session) return;

    reset({
      ...getDefaultQuotationValues(),
      ...getSessionDefaults(session),
    });
  }, [mode, session, reset]);

  const onSubmit = async (values: QuotationFormValues) => {
    try {
      const currentUserId = session?.user?.id ?? "current-user";

      if (mode === "create") {
        const payload: QuotationFormValues = {
          ...values,
          businessId: values.businessId ?? session?.business?.id,
          createdBy: values.createdBy ?? currentUserId,
        };

        const res = await createQuotation(payload).unwrap();
        notify.success(res.message || "Quotation created successfully");
        onSuccess?.(res.data);
      } else if (mode === "edit" && quotation?.id) {
        const { createdBy, businessId, ...rest } = values;

        const res = await updateQuotation({
          id: quotation.id,
          data: {
            ...rest,
            updatedBy: currentUserId,
          },
        }).unwrap();

        notify.success(res.message || "Quotation updated successfully");
        onSuccess?.(res.data);
      }
    } catch (err: any) {
      notify.error(
        err?.data?.message || err?.message || "Something went wrong",
      );
    }
  };

  return (
    <FormProvider {...form}>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6" noValidate>
        <QuotationDetailsSection />
        <QuotationPartiesSection />
        <QuotationItemsSection />

        {/* Payment + Summary */}
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          <div className="xl:col-span-2">
            <QuotationPaymentSection />
          </div>
          <QuotationSummarySection />
        </div>

        {/* Terms + Signature */}
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          <div className="xl:col-span-2">
            <QuotationAdditionalsSection />
          </div>
          <QuotationSignatureSection />
        </div>

        <QuotationFormActions
          mode={mode}
          isSubmitting={isSubmitting}
          onCancel={onCancel}
        />
      </form>
    </FormProvider>
  );
}

export default QuotationForm;