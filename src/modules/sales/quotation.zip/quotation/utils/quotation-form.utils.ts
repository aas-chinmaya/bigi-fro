// // ============================================================
// // quotation-form.utils.ts
// // ============================================================

// import type { Quotation } from "../types/quotation.types";
// import type { QuotationFormValues } from "../types/quotation-form.types";

// /** Empty form values for create mode */
// export function getDefaultQuotationValues(): QuotationFormValues {
//   return {
//     businessId: "", // TODO: from auth
//     branchId: null,
//     quotationDate: new Date().toISOString().slice(0, 10),
//     validUntil: "",
//     financialYear: null,

//     businessName: "",
//     businessLegalName: null,
//     businessGSTIN: null,
//     businessPAN: null,
//     businessPhone: null,
//     businessEmail: null,
//     businessAddressLine1: null,
//     businessAddressLine2: null,
//     businessCity: null,
//     businessState: null,
//     businessStateCode: null,
//     businessPincode: null,
//     businessCountry: "India",

//     prospectName: "",
//     prospectCompanyName: null,
//     prospectGSTIN: null,
//     prospectPAN: null,
//     prospectPhone: null,
//     prospectEmail: null,
//     prospectAddressLine1: null,
//     prospectAddressLine2: null,
//     prospectCity: null,
//     prospectState: null,
//     prospectStateCode: null,
//     prospectPincode: null,
//     prospectCountry: "India",

//     customerId: null,

//     placeOfSupply: null,
//     placeOfSupplyCode: null,
//     taxType: "CGST_SGST",
//     reverseCharge: false,
//     isExport: false,
//     isSEZ: false,
//     currency: "INR",
//     exchangeRate: null,

//     items: [
//       {
//         itemId: null,
//         itemName: "",
//         description: null,
//         quantity: 1,
//         unit: "NOS",
//         rate: 0,
//         discount: 0,
//         discountType: "PERCENTAGE",
//         taxRate: 18,
//         taxAmount: 0,
//         amount: 0,
//       },
//     ],

//     totalItems: 1,
//     totalQuantity: 1,
//     taxableAmount: 0,
//     discountAmount: 0,
//     cgstAmount: 0,
//     sgstAmount: 0,
//     igstAmount: 0,
//     cessAmount: 0,
//     roundOffAmount: 0,
//     grandTotal: 0,

//     notes: null,
//     termsAndConditions: null,
//     createdBy: "", // TODO: from auth
//   };
// }

// /** Map API Quotation → form values (edit mode) */
// export function mapQuotationToFormValues(q: Quotation): QuotationFormValues {
//   return {
//     businessId: q.businessId,
//     branchId: q.branchId ?? null,
//     quotationDate: q.quotationDate?.slice(0, 10) ?? "",
//     validUntil: q.validUntil?.slice(0, 10) ?? "",
//     financialYear: q.financialYear ?? null,

//     businessName: q.businessName,
//     businessLegalName: q.businessLegalName ?? null,
//     businessGSTIN: q.businessGSTIN ?? null,
//     businessPAN: q.businessPAN ?? null,
//     businessPhone: q.businessPhone ?? null,
//     businessEmail: q.businessEmail ?? null,
//     businessAddressLine1: q.businessAddressLine1 ?? null,
//     businessAddressLine2: q.businessAddressLine2 ?? null,
//     businessCity: q.businessCity ?? null,
//     businessState: q.businessState ?? null,
//     businessStateCode: q.businessStateCode ?? null,
//     businessPincode: q.businessPincode ?? null,
//     businessCountry: q.businessCountry ?? "India",

//     prospectName: q.prospectName,
//     prospectCompanyName: q.prospectCompanyName ?? null,
//     prospectGSTIN: q.prospectGSTIN ?? null,
//     prospectPAN: q.prospectPAN ?? null,
//     prospectPhone: q.prospectPhone ?? null,
//     prospectEmail: q.prospectEmail ?? null,
//     prospectAddressLine1: q.prospectAddressLine1 ?? null,
//     prospectAddressLine2: q.prospectAddressLine2 ?? null,
//     prospectCity: q.prospectCity ?? null,
//     prospectState: q.prospectState ?? null,
//     prospectStateCode: q.prospectStateCode ?? null,
//     prospectPincode: q.prospectPincode ?? null,
//     prospectCountry: q.prospectCountry ?? "India",

//     customerId: q.customerId ?? null,

//     placeOfSupply: q.placeOfSupply ?? null,
//     placeOfSupplyCode: q.placeOfSupplyCode ?? null,
//     taxType: q.taxType ?? "CGST_SGST",
//     reverseCharge: q.reverseCharge ?? false,
//     isExport: q.isExport ?? false,
//     isSEZ: q.isSEZ ?? false,
//     currency: q.currency ?? "INR",
//     exchangeRate: q.exchangeRate ?? null,

//     items:
//       q.items?.length > 0
//         ? q.items.map((item) => ({
//             id: item.id,
//             itemId: item.itemId ?? null,
//             itemName: item.itemName ?? "",
//             description: item.description ?? null,
//             quantity: item.quantity ?? 1,
//             unit: item.unit ?? "NOS",
//             rate: item.rate ?? 0,
//             discount: item.discount ?? 0,
//             discountType: item.discountType ?? "PERCENTAGE",
//             taxRate: item.taxRate ?? 0,
//             taxAmount: item.taxAmount ?? 0,
//             amount: item.amount ?? 0,
//           }))
//         : getDefaultQuotationValues().items,

//     totalItems: q.totalItems ?? 0,
//     totalQuantity: q.totalQuantity ?? 0,
//     taxableAmount: q.taxableAmount ?? 0,
//     discountAmount: q.discountAmount ?? 0,
//     cgstAmount: q.cgstAmount ?? 0,
//     sgstAmount: q.sgstAmount ?? 0,
//     igstAmount: q.igstAmount ?? 0,
//     cessAmount: q.cessAmount ?? 0,
//     roundOffAmount: q.roundOffAmount ?? 0,
//     grandTotal: q.grandTotal ?? 0,

//     notes: q.notes ?? null,
//     termsAndConditions: q.termsAndConditions ?? null,
//     createdBy: q.createdBy,
//   };
// }



// ============================================================
// quotation-form.utils.ts
// ============================================================

import type { Quotation, QuotationItem, TaxType, DiscountType } from "../types/quotation.types";
import type { QuotationFormValues } from "../types/quotation-form.types";
import type {
  QuotationCreatePayload,
  QuotationUpdatePayload,
} from "../types/quotation.types";

function round2(n: number) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

function calcLine(item: {
  quantity: number;
  rate: number;
  discount?: number;
  discountType?: DiscountType;
  taxRate?: number;
}) {
  const qty = Number(item.quantity) || 0;
  const rate = Number(item.rate) || 0;
  const discountVal = Number(item.discount) || 0;
  const discountType = item.discountType ?? "PERCENTAGE";
  const taxRate = Number(item.taxRate) || 0;

  const gross = qty * rate;
  let discountAmount =
    discountType === "PERCENTAGE" ? (gross * discountVal) / 100 : discountVal;
  discountAmount = Math.min(discountAmount, gross);

  const taxable = gross - discountAmount;
  const taxAmount = (taxable * taxRate) / 100;
  const amount = taxable + taxAmount;

  return {
    discountAmount: round2(discountAmount),
    taxable: round2(taxable),
    taxAmount: round2(taxAmount),
    amount: round2(amount),
  };
}

export interface CalculatedTotals {
  items: Array<{ taxAmount: number; amount: number }>;
  totalItems: number;
  totalQuantity: number;
  taxableAmount: number;
  discountAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  cessAmount: number;
  roundOffAmount: number;
  grandTotal: number;
}

export function calculateQuotationTotals(
  items: QuotationFormValues["items"],
  taxType: TaxType | null | undefined = "CGST_SGST",
): CalculatedTotals {
  let totalQuantity = 0;
  let taxableAmount = 0;
  let discountAmount = 0;
  let totalTax = 0;

  const calculatedItems = (items || []).map((item) => {
    const line = calcLine(item);
    totalQuantity += Number(item.quantity) || 0;
    taxableAmount += line.taxable;
    discountAmount += line.discountAmount;
    totalTax += line.taxAmount;
    return { taxAmount: line.taxAmount, amount: line.amount };
  });

  taxableAmount = round2(taxableAmount);
  discountAmount = round2(discountAmount);
  totalTax = round2(totalTax);

  let cgstAmount = 0;
  let sgstAmount = 0;
  let igstAmount = 0;

  if (taxType === "IGST") {
    igstAmount = totalTax;
  } else if (taxType === "CGST_SGST") {
    cgstAmount = round2(totalTax / 2);
    sgstAmount = round2(totalTax - cgstAmount);
  }

  const rawGrand = taxableAmount + totalTax;
  const grandTotal = Math.round(rawGrand);
  const roundOffAmount = round2(grandTotal - rawGrand);

  return {
    items: calculatedItems,
    totalItems: items?.length ?? 0,
    totalQuantity: round2(totalQuantity),
    taxableAmount,
    discountAmount,
    cgstAmount,
    sgstAmount,
    igstAmount,
    cessAmount: 0,
    roundOffAmount,
    grandTotal,
  };
}

/** Default values – inject real businessId / createdBy from props */
export function getDefaultQuotationValues(
  businessId = "temp-business-id",
  createdBy = "temp-user-id",
): QuotationFormValues {
  return {
    businessId,
    createdBy,
    branchId: null,
    quotationDate: new Date().toISOString().slice(0, 10),
    validUntil: "",
    financialYear: null,

    businessName: "",
    businessLegalName: null,
    businessGSTIN: null,
    businessPAN: null,
    businessPhone: null,
    businessEmail: null,
    businessAddressLine1: null,
    businessAddressLine2: null,
    businessCity: null,
    businessState: null,
    businessStateCode: null,
    businessPincode: null,
    businessCountry: "India",

    prospectName: "",
    prospectCompanyName: null,
    prospectGSTIN: null,
    prospectPAN: null,
    prospectPhone: null,
    prospectEmail: null,
    prospectAddressLine1: null,
    prospectAddressLine2: null,
    prospectCity: null,
    prospectState: null,
    prospectStateCode: null,
    prospectPincode: null,
    prospectCountry: "India",

    customerId: null,
    placeOfSupply: null,
    placeOfSupplyCode: null,
    taxType: "CGST_SGST",
    reverseCharge: false,
    isExport: false,
    isSEZ: false,
    currency: "INR",
    exchangeRate: null,

    items: [
      {
        itemId: null,
        itemName: "",
        description: null,
        quantity: 1,
        unit: "NOS",
        rate: 0,
        discount: 0,
        discountType: "PERCENTAGE",
        taxRate: 18,
        taxAmount: 0,
        amount: 0,
      },
    ],

    totalItems: 1,
    totalQuantity: 1,
    taxableAmount: 0,
    discountAmount: 0,
    cgstAmount: 0,
    sgstAmount: 0,
    igstAmount: 0,
    cessAmount: 0,
    roundOffAmount: 0,
    grandTotal: 0,

    notes: null,
    termsAndConditions: null,
    signature: undefined,
  };
}

export function mapQuotationToFormValues(
  q: Quotation,
  fallbackBusinessId?: string,
  fallbackCreatedBy?: string,
): QuotationFormValues {
  return {
    businessId: q.businessId || fallbackBusinessId || "temp-business-id",
    createdBy: q.createdBy || fallbackCreatedBy || "temp-user-id",
    branchId: q.branchId ?? null,
    quotationDate: q.quotationDate?.slice(0, 10) ?? "",
    validUntil: q.validUntil?.slice(0, 10) ?? "",
    financialYear: q.financialYear ?? null,

    businessName: q.businessName,
    businessLegalName: q.businessLegalName ?? null,
    businessGSTIN: q.businessGSTIN ?? null,
    businessPAN: q.businessPAN ?? null,
    businessPhone: q.businessPhone ?? null,
    businessEmail: q.businessEmail ?? null,
    businessAddressLine1: q.businessAddressLine1 ?? null,
    businessAddressLine2: q.businessAddressLine2 ?? null,
    businessCity: q.businessCity ?? null,
    businessState: q.businessState ?? null,
    businessStateCode: q.businessStateCode ?? null,
    businessPincode: q.businessPincode ?? null,
    businessCountry: q.businessCountry ?? "India",

    prospectName: q.prospectName,
    prospectCompanyName: q.prospectCompanyName ?? null,
    prospectGSTIN: q.prospectGSTIN ?? null,
    prospectPAN: q.prospectPAN ?? null,
    prospectPhone: q.prospectPhone ?? null,
    prospectEmail: q.prospectEmail ?? null,
    prospectAddressLine1: q.prospectAddressLine1 ?? null,
    prospectAddressLine2: q.prospectAddressLine2 ?? null,
    prospectCity: q.prospectCity ?? null,
    prospectState: q.prospectState ?? null,
    prospectStateCode: q.prospectStateCode ?? null,
    prospectPincode: q.prospectPincode ?? null,
    prospectCountry: q.prospectCountry ?? "India",

    customerId: q.customerId ?? null,
    placeOfSupply: q.placeOfSupply ?? null,
    placeOfSupplyCode: q.placeOfSupplyCode ?? null,
    taxType: q.taxType ?? "CGST_SGST",
    reverseCharge: q.reverseCharge ?? false,
    isExport: q.isExport ?? false,
    isSEZ: q.isSEZ ?? false,
    currency: q.currency ?? "INR",
    exchangeRate: q.exchangeRate ?? null,

    items:
      q.items?.length > 0
        ? q.items.map((item) => ({
            id: item.id,
            itemId: item.itemId ?? null,
            itemName: item.itemName ?? "",
            description: item.description ?? null,
            quantity: item.quantity ?? 1,
            unit: item.unit ?? "NOS",
            rate: item.rate ?? 0,
            discount: item.discount ?? 0,
            discountType: item.discountType ?? "PERCENTAGE",
            taxRate: item.taxRate ?? 0,
            taxAmount: item.taxAmount ?? 0,
            amount: item.amount ?? 0,
          }))
        : getDefaultQuotationValues().items,

    totalItems: q.totalItems ?? 0,
    totalQuantity: q.totalQuantity ?? 0,
    taxableAmount: q.taxableAmount ?? 0,
    discountAmount: q.discountAmount ?? 0,
    cgstAmount: q.cgstAmount ?? 0,
    sgstAmount: q.sgstAmount ?? 0,
    igstAmount: q.igstAmount ?? 0,
    cessAmount: q.cessAmount ?? 0,
    roundOffAmount: q.roundOffAmount ?? 0,
    grandTotal: q.grandTotal ?? 0,

    notes: q.notes ?? null,
    termsAndConditions: q.termsAndConditions ?? null,
    signature: undefined,
  };
}

/** Sanitize → exact API payload */
export function sanitizeCreatePayload(
  values: QuotationFormValues,
): QuotationCreatePayload {
  const { signature, ...rest } = values;

  return {
    businessId: rest.businessId,
    createdBy: rest.createdBy,
    branchId: rest.branchId || null,
    quotationDate: rest.quotationDate,
    validUntil: rest.validUntil,
    financialYear: rest.financialYear || null,

    businessName: rest.businessName,
    businessLegalName: rest.businessLegalName || null,
    businessGSTIN: rest.businessGSTIN || null,
    businessPAN: rest.businessPAN || null,
    businessPhone: rest.businessPhone || null,
    businessEmail: rest.businessEmail || null,
    businessAddressLine1: rest.businessAddressLine1 || null,
    businessAddressLine2: rest.businessAddressLine2 || null,
    businessCity: rest.businessCity || null,
    businessState: rest.businessState || null,
    businessStateCode: rest.businessStateCode || null,
    businessPincode: rest.businessPincode || null,
    businessCountry: rest.businessCountry || "India",

    prospectName: rest.prospectName,
    prospectCompanyName: rest.prospectCompanyName || null,
    prospectGSTIN: rest.prospectGSTIN || null,
    prospectPAN: rest.prospectPAN || null,
    prospectPhone: rest.prospectPhone || null,
    prospectEmail: rest.prospectEmail || null,
    prospectAddressLine1: rest.prospectAddressLine1 || null,
    prospectAddressLine2: rest.prospectAddressLine2 || null,
    prospectCity: rest.prospectCity || null,
    prospectState: rest.prospectState || null,
    prospectStateCode: rest.prospectStateCode || null,
    prospectPincode: rest.prospectPincode || null,
    prospectCountry: rest.prospectCountry || "India",

    customerId: rest.customerId || null,
    placeOfSupply: rest.placeOfSupply || null,
    placeOfSupplyCode: rest.placeOfSupplyCode || null,
    taxType: rest.taxType || "CGST_SGST",
    reverseCharge: rest.reverseCharge ?? false,
    isExport: rest.isExport ?? false,
    isSEZ: rest.isSEZ ?? false,
    currency: rest.currency || "INR",
    exchangeRate: rest.exchangeRate ?? null,

    items: rest.items.map((item) => ({
      id: item.id,
      itemId: item.itemId || null,
      itemName: item.itemName || "",
      description: item.description || null,
      quantity: Number(item.quantity) || 0,
      unit: item.unit || null,
      rate: Number(item.rate) || 0,
      discount: Number(item.discount) || 0,
      discountType: item.discountType || "PERCENTAGE",
      taxRate: Number(item.taxRate) || 0,
      taxAmount: Number(item.taxAmount) || 0,
      amount: Number(item.amount) || 0,
    })),

    totalItems: rest.totalItems,
    totalQuantity: rest.totalQuantity,
    taxableAmount: rest.taxableAmount,
    discountAmount: rest.discountAmount,
    cgstAmount: rest.cgstAmount,
    sgstAmount: rest.sgstAmount,
    igstAmount: rest.igstAmount,
    cessAmount: rest.cessAmount,
    roundOffAmount: rest.roundOffAmount,
    grandTotal: rest.grandTotal,

    notes: rest.notes || null,
    termsAndConditions: rest.termsAndConditions || null,
  };
}

export function sanitizeUpdatePayload(
  values: QuotationFormValues,
): QuotationUpdatePayload {
  const createPayload = sanitizeCreatePayload(values);
  const { businessId, createdBy, ...rest } = createPayload;

  return {
    ...rest,
    updatedBy: createdBy || "current-user",
  };
}