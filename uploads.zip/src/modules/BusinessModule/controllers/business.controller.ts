import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as service from "../services/business.service";
import { AuthRequest } from "../../../middleware/auth.middleware";

export const createBusiness = asyncHandler(async (req: AuthRequest, res: Response) => {

  const logo = (req as any).files?.logo?.[0];

  // Logged-in user ID from authentication middleware
    const createdBy = req.user?.id;

    if (!createdBy) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized: User not found",
      });
    }
  const result = await service.createBusinessService({
    ...req.body,
    logo: logo?.path || null,
    createdBy,
  });

  return res.status(result.status).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getBusinesses = asyncHandler(async (_req: Request, res: Response) => {
  const result = await service.getBusinessesService();

  return res.status(result.status).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});



export const getBusinessesByUser = asyncHandler(
  async (req: AuthRequest, res: Response) => {

    const userId = req.user?.id;

    console.log(
      "USER ID:",
      userId
    );

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized: User not found",
      });
    }

    const result =
      await service.getBusinessesByUserService(
        userId
      );

    return res.status(result.status).json({
      success: true,
      message: result.message,
      data: result.data,
    });
  }
);


export const getBusinessById = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  const result = await service.getBusinessByIdService(id);

  return res.status(result.status).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const updateBusiness = asyncHandler(async (req: AuthRequest, res: Response) => {
  const id = String(req.params.id);
  const logo = (req as any).files?.logo?.[0];
  const result = await service.updateBusinessService(id, {
    ...req.body,
    logo,
  });

  return res.status(result.status).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const deleteBusiness = asyncHandler(
  async (req: Request, res: Response) => {
    const id = String(req.params.id);

    const result = await service.deleteBusinessService(id);

    return res.status(result.status).json({
      success: result.status >= 200 && result.status < 300,
      message: result.message,
    });
  }
);