import { Router } from "express";
import * as taxController from "../controllers/tax.controller";

const router = Router();

router.post(
    "/create",
    taxController.createTax
);

router.get(
    "/getall",
    taxController.getAllTaxes
);

router.get(
    "/getbyid/:id",
    taxController.getTaxById
);

router.put(
    "/update/:id",
    taxController.updateTax
);

router.delete(
    "/delete/:id",
    taxController.deleteTax
);

router.patch(
    "/restore/:id",
    taxController.restoreTax
);

export default router;