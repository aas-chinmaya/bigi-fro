import { Router } from "express";
import * as subCategoryController from "../controllers/subCategory.controller";

const router = Router();

router.post(
    "/create",
    subCategoryController.createSubCategory
);

router.get(
    "/getall",
    subCategoryController.getAllSubCategories
);

router.get(
    "/getbyid/:id",
    subCategoryController.getSubCategoryById
);

router.get(
    "/category/:categoryId",
    subCategoryController.getSubCategoriesByCategory
);

router.put(
    "/update/:id",
    subCategoryController.updateSubCategory
);

router.delete(
    "/delete/:id",
    subCategoryController.deleteSubCategory
);


router.patch(
    "/restore/:id",
    subCategoryController.restoreSubCategory
);

export default router;