import { Router } from "express";
import * as serviceController from "../controllers/service.controller";

const router = Router();

router.post("/create",serviceController.createService);

router.get("/getall",serviceController.getAllServices);

router.get("/getby/:id",serviceController.getServiceById);

router.put("/update/:id",serviceController.updateService);

router.delete("/delete/:id",serviceController.deleteService);

router.patch("/restore/:id",serviceController.restoreService);

export default router;