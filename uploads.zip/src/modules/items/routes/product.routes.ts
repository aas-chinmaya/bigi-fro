import { Router } from "express";
import * as productController from "../controllers/product.controller";
import  uploadFactory  from "../../../middleware/multer.middleware";


const router = Router();
const upload = uploadFactory("Product");

// Create Product
router.post(
    "/create", upload.fields([{ name: "image", maxCount: 10 }]),
    productController.createProduct
);


// Get All Products
router.get(
    "/getall",
    productController.getAllProducts
);

// Get Product By ID
router.get(
    "/getbyid/:id",
    productController.getProductById
);

// Update Product
router.put(
    "/updatebyid/:id",
    upload.fields([{ name: "image", maxCount: 10 }]),
    productController.updateProduct
);

// Soft Delete Product
router.delete(
    "/deletebyid/:id",
    productController.deleteProduct
);

// Restore Product
router.patch(
    "/restore/:id",
    productController.restoreProduct
);


export default router;