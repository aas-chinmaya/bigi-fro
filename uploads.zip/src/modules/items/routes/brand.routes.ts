import { Router } from "express";
import * as brandController from "../controllers/brand.controller";

const router = Router();

/**
 * Create Brand
 * POST /api/brands
 */
router.post(
    "/create",
    brandController.createBrand
);

/**
 * Get All Brands
 * GET /api/brands
 */
router.get(
    "/getall",
    brandController.getAllBrands
);

/**
 * Get Brand By Id
 * GET /api/brands/:id
 */
router.get(
    "/getbyid/:id",
    brandController.getBrandById
);

/**
 * Update Brand
 * PUT /api/brands/:id
 */
router.put(
    "/update/:id",
    brandController.updateBrand
);

/**
 * Soft Delete Brand
 * DELETE /api/brands/:id
 */
router.delete(
    "/delete/:id",
    brandController.deleteBrand
);

/**
 * Restore Brand
 * PATCH /api/brands/:id/restore
 */
router.patch(
    "/restore/:id",
    brandController.restoreBrand
);

export default router;