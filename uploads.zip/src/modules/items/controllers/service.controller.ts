import { Request, Response, NextFunction } from "express";
import * as serviceService from "../services/service.service";

export const createService = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const service = await serviceService.createService(
            req.body
        );

        return res.status(201).json({
            success: true,
            message: "Service created successfully.",
            data: service,
        });

    } catch (error) {
        next(error);
    }
};

export const getAllServices = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const page =
            Number(req.query.page) || 1;

        const limit =
            Number(req.query.limit) || 10;

        const search =
            req.query.search
                ? String(req.query.search)
                : undefined;

        let status: boolean | undefined;

        if (req.query.status !== undefined) {

            status =
                String(req.query.status)
                    .toLowerCase() === "true";
        }

        const result =
            await serviceService.getAllServices(
                page,
                limit,
                search,
                status
            );

        return res.status(200).json({
            success: true,
            message: "Services fetched successfully.",
            data: result.data,
            pagination: result.pagination,
        });

    } catch (error) {
        next(error);
    }
};

export const getServiceById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const id = String(req.params.id) || req.params.id;

        const service =
            await serviceService.getServiceById(id as string);

        return res.status(200).json({
            success: true,
            message: "Service fetched successfully.",
            data: service,
        });

    } catch (error) {
        next(error);
    }
};

export const updateService = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const { id } = req.params;

        const service =
            await serviceService.updateService(
                id as string,
                req.body
            );

        return res.status(200).json({
            success: true,
            message: "Service updated successfully.",
            data: service,
        });

    } catch (error) {
        next(error);
    }
};

export const deleteService = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const { id } = req.params;

        await serviceService.deleteService(id as string );

        return res.status(200).json({
            success: true,
            message: "Service deleted successfully.",
        });

    } catch (error) {
        next(error);
    }
};

export const restoreService = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const { id } = req.params;

        const service =
            await serviceService.restoreService(id as string );

        return res.status(200).json({
            success: true,
            message: "Service restored successfully.",
            data: service,
        });

    } catch (error) {
        next(error);
    }
};