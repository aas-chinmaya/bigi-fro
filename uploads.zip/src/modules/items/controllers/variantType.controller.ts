import { Request, Response, NextFunction } from "express";
import  * as variantTypeService from "../services/variantType.service";

export const createVariantType = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const variantType =
            await variantTypeService.createVariantType(
                req.body
            );


        return res.status(201).json({

            success: true,

            message:
                "Variant Type created successfully.",

            data: variantType,

        });

    } catch (error) {

        next(error);

    }
};
export const getAllVariantTypes = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            page,
            limit,
            search,
            status,
        } = req.query;

        const pageValue =
            typeof page === "string"
                ? Number(page)
                : 1;
        const limitValue =
            typeof limit === "string"
                ? Number(limit)
                : 10;

        const searchValue =
            typeof search === "string"
                ? search
                : undefined;

        const statusValue =
            typeof status === "string"
                ? status === "true"
                : undefined;


        const variantTypes =
            await variantTypeService.getAllVariantTypes(

                pageValue,

                limitValue,

                searchValue,

                statusValue

            );


        return res.status(200).json({

            success: true,

            message:
                "Variant Types fetched successfully.",

            data: variantTypes,

        });

    } catch (error) {

        next(error);

    }
};

export const getVariantTypeById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Variant Type ID."
            );

        }


        const variantType =
            await variantTypeService.getVariantTypeById(
                id
            );


        return res.status(200).json({

            success: true,

            message:
                "Variant Type fetched successfully.",

            data: variantType,

        });

    } catch (error) {

        next(error);

    }
};
export const updateVariantType = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Variant Type ID."
            );

        }


        const variantType =
            await variantTypeService.updateVariantType(

                id,

                req.body

            );


        return res.status(200).json({

            success: true,

            message:
                "Variant Type updated successfully.",

            data: variantType,

        });

    } catch (error) {

        next(error);

    }
};

export const deleteVariantType = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Variant Type ID."
            );

        }


        await variantTypeService.deleteVariantType(
            id
        );


        return res.status(200).json({

            success: true,

            message:
                "Variant Type deleted successfully.",

        });

    } catch (error) {

        next(error);

    }
};

export const restoreVariantType = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Variant Type ID."
            );

        }


        const variantType =
            await variantTypeService.restoreVariantType(
                id
            );


        return res.status(200).json({

            success: true,

            message:
                "Variant Type restored successfully.",

            data: variantType,

        });

    } catch (error) {

        next(error);

    }
};