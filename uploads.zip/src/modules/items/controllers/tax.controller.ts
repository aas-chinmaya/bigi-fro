import { Request, Response, NextFunction } from "express";
import * as taxService from "../services/tax.service";

export const createTax = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const tax =
            await taxService.createTax(
                req.body
            );


        return res.status(201).json({

            success: true,

            message:
                "Tax created successfully.",

            data: tax,

        });

    } catch (error) {

        next(error);

    }
};

export const getAllTaxes = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            page,
            limit,
            search,
            status,
        } = req.query;


        const pageValue =
            typeof page === "string"
                ? Number(page)
                : 1;


        const limitValue =
            typeof limit === "string"
                ? Number(limit)
                : 10;


        const searchValue =
            typeof search === "string"
                ? search
                : undefined;

        const statusValue =
            typeof status === "string"
                ? status === "true"
                : undefined;


        const taxes =
            await taxService.getAllTaxes(
                pageValue,
                limitValue,
                searchValue,
                statusValue
            );


        return res.status(200).json({

            success: true,

            message:
                "Taxes fetched successfully.",

            data: taxes,

        });

    } catch (error) {

        next(error);

    }
};

export const getTaxById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Tax ID."
            );

        }


        const tax =
            await taxService.getTaxById(
                id
            );


        return res.status(200).json({

            success: true,

            message:
                "Tax fetched successfully.",

            data: tax,

        });

    } catch (error) {

        next(error);

    }
};


// =====================================================
// UPDATE TAX
// =====================================================

export const updateTax = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Tax ID."
            );

        }


        const tax =
            await taxService.updateTax(
                id,
                req.body
            );


        return res.status(200).json({

            success: true,

            message:
                "Tax updated successfully.",

            data: tax,

        });

    } catch (error) {

        next(error);

    }
};

export const deleteTax = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Tax ID."
            );

        }


        await taxService.deleteTax(
            id
        );


        return res.status(200).json({

            success: true,

            message:
                "Tax deleted successfully.",

        });

    } catch (error) {

        next(error);

    }
};

export const restoreTax = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Tax ID."
            );

        }


        const tax =
            await taxService.restoreTax(
                id
            );


        return res.status(200).json({

            success: true,

            message:
                "Tax restored successfully.",

            data: tax,

        });

    } catch (error) {

        next(error);

    }
};