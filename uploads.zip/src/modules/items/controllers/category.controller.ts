import { Request, Response, NextFunction } from "express";
import * as categoryService from "../services/category.service";


// CREATE CATEGORY
export const createCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const category = await categoryService.createCategory(req.body);

        return res.status(201).json({
            success: true,
            message: "Category created successfully",
            data: category,
        });

    } catch (error) {
        next(error);
    }
};


// GET ALL CATEGORIES
export const getAllCategories = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const {
            page = "1",
            limit = "10",
            search,
            status,
        } = req.query;

        const categories = await categoryService.getAllCategories(
            Number(page),
            Number(limit),
            search as string,
            status !== undefined
                ? status === "true"
                : undefined
        );

        return res.status(200).json({
            success: true,
            message: "Categories fetched successfully",
            data: categories,
        });

    } catch (error) {
        next(error);
    }
};


// GET CATEGORY BY ID
export const getCategoryById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const category = await categoryService.getCategoryById(
            req.params.id as string
        );

        return res.status(200).json({
            success: true,
            message: "Category fetched successfully",
            data: category,
        });

    } catch (error) {
        next(error);
    }
};


// UPDATE CATEGORY
export const updateCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const category = await categoryService.updateCategory(
            req.params.id as string,
            req.body
        );

        return res.status(200).json({
            success: true,
            message: "Category updated successfully",
            data: category,
        });

    } catch (error) {
        next(error);
    }
};


// DELETE CATEGORY
export const deleteCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        await categoryService.deleteCategory(
            req.params.id as string
        );

        return res.status(200).json({
            success: true,
            message: "Category deleted successfully",
        });

    } catch (error) {
        next(error);
    }
};

// RESTORE CATEGORY
export const restoreCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const category = await categoryService.restoreCategory(
            req.params.id as string
        );

        return res.status(200).json({
            success: true,
            message: "Category restored successfully",
            data: category,
        });

    } catch (error) {
        next(error);
    }
};