import { Request, Response, NextFunction } from "express";
import * as productUnitService from "../services/productUnit.service";


// CREATE PRODUCT UNIT
export const createProductUnit = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const productUnit =
            await productUnitService.createProductUnit(req.body);

        return res.status(201).json({
            success: true,
            message: "Product Unit created successfully.",
            data: productUnit,
        });

    } catch (error) {
        next(error);
    }
};


// GET ALL PRODUCT UNITS
export const getAllProductUnits = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const {
            page = "1",
            limit = "10",
            search,
            status,
        } = req.query;

        const productUnits =
            await productUnitService.getAllProductUnits(
                Number(page),
                Number(limit),
                search as string,
                status !== undefined
                    ? status === "true"
                    : undefined
            );

        return res.status(200).json({
            success: true,
            message: "Product Units fetched successfully.",
            data: productUnits,
        });

    } catch (error) {
        next(error);
    }
};


// GET PRODUCT UNIT BY ID
export const getProductUnitById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const productUnit =
            await productUnitService.getProductUnitById(
                req.params.id as string
            );

        return res.status(200).json({
            success: true,
            message: "Product Unit fetched successfully.",
            data: productUnit,
        });

    } catch (error) {
        next(error);
    }
};


// UPDATE PRODUCT UNIT
export const updateProductUnit = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const productUnit =
            await productUnitService.updateProductUnit(
                req.params.id as string,
                req.body
            );

        return res.status(200).json({
            success: true,
            message: "Product Unit updated successfully.",
            data: productUnit,
        });

    } catch (error) {
        next(error);
    }
};


// DELETE PRODUCT UNIT
export const deleteProductUnit = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        await productUnitService.deleteProductUnit(
            req.params.id as string
        );

        return res.status(200).json({
            success: true,
            message: "Product Unit deleted successfully.",
        });

    } catch (error) {
        next(error);
    }
};

// RESTORE PRODUCT UNIT
export const restoreProductUnit = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const productUnit =
            await productUnitService.restoreProductUnit(
                req.params.id as string
            );

        return res.status(200).json({
            success: true,
            message: "Product Unit restored successfully.",
            data: productUnit,
        });

    } catch (error) {
        next(error);
    }
};