import { Request, Response, NextFunction } from "express";
import * as productService from "../services/product.service";


// CREATE PRODUCT
export const createProduct = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const image = (req as any).files?.image?.[0];

        const payload = {

            ...req.body,

            image: image
                ? `/uploads/Product/image/${image.filename}`
                : undefined,

        };

        const product =
            await productService.createProduct(payload);

        return res.status(201).json({

            success: true,
            message: "Product created successfully.",
            data: product,

        });

    } catch (error) {

        next(error);

    }

};


// GET ALL PRODUCTS
export const getAllProducts = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            page = "1",
            limit = "10",
            search,
            status,
        } = req.query;

        const products =
            await productService.getAllProducts(
                Number(page),
                Number(limit),
                search as string,
                status !== undefined
                    ? status === "true"
                    : undefined
            );

        return res.status(200).json({

            success: true,
            message: "Products fetched successfully.",
            data: products,

        });

    } catch (error) {

        next(error);

    }

};
// GET PRODUCT BY ID
export const getProductById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const product =
            await productService.getProductById(
                req.params.id as string
            );

        return res.status(200).json({

            success: true,

            message: "Product fetched successfully.",

            data: product,

        });

    } catch (error) {

        next(error);

    }

};


// UPDATE PRODUCT
export const updateProduct = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {
        const image = (req as any).files?.image?.[0];

         const payload = {
            ...req.body,

            ...(image && {
                image: `/uploads/Product/image/${image.filename}`,
            }),
        };

        const product =
            await productService.updateProduct(
                req.params.id as string,
                payload
            );

        return res.status(200).json({

            success: true,
            message: "Product updated successfully.",
            data: product,

        });

    } catch (error) {

        next(error);

    }

};


// DELETE PRODUCT
export const deleteProduct = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        await productService.deleteProduct(
            req.params.id as string
        );

        return res.status(200).json({

            success: true,

            message: "Product deleted successfully.",

        });

    } catch (error) {

        next(error);

    }

};


// RESTORE PRODUCT
export const restoreProduct = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const product =
            await productService.restoreProduct(
                req.params.id as string
            );

        return res.status(200).json({

            success: true,

            message: "Product restored successfully.",

            data: product,

        });

    } catch (error) {

        next(error);

    }

};