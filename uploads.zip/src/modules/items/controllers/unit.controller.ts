import {Request,Response,NextFunction,} from "express";
import * as unitService from "../services/unit.service";


export const createUnit = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const unit =
            await unitService.createUnit(
                req.body
            );


        return res.status(201).json({

            success: true,

            message:
                "Unit created successfully.",

            data: unit,

        });

    } catch (error) {

        next(error);

    }
};

export const getAllUnits = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            page,
            limit,
            search,
            status,
        } = req.query;

        const pageValue =
            typeof page === "string"
                ? Number(page)
                : 1;

        const limitValue =
            typeof limit === "string"
                ? Number(limit)
                : 10;

        const searchValue =
            typeof search === "string"
                ? search
                : undefined;

        const statusValue =
            typeof status === "string"
                ? status === "true"
                : undefined;

        const units =
            await unitService.getAllUnits(

                pageValue,

                limitValue,

                searchValue,

                statusValue

            );

        return res.status(200).json({

            success: true,

            message:
                "Units fetched successfully.",

            data: units,

        });

    } catch (error) {

        next(error);

    }
};

export const getUnitById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Unit ID."
            );

        }

        const unit =
            await unitService.getUnitById(
                id
            );

        return res.status(200).json({

            success: true,

            message:
                "Unit fetched successfully.",

            data: unit,

        });

    } catch (error) {

        next(error);

    }
};

export const updateUnit = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Unit ID."
            );

        }


        const unit =
            await unitService.updateUnit(

                id,

                req.body

            );


        return res.status(200).json({

            success: true,

            message:
                "Unit updated successfully.",

            data: unit,

        });

    } catch (error) {

        next(error);

    }
};


export const deleteUnit = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Unit ID."
            );

        }


        await unitService.deleteUnit(
            id
        );


        return res.status(200).json({

            success: true,

            message:
                "Unit deleted successfully.",

        });

    } catch (error) {

        next(error);

    }
};

export const restoreUnit = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Unit ID."
            );

        }


        const unit =
            await unitService.restoreUnit(
                id
            );


        return res.status(200).json({

            success: true,

            message:
                "Unit restored successfully.",

            data: unit,

        });

    } catch (error) {

        next(error);

    }
};