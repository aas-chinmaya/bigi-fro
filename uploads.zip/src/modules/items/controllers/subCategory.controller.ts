import { Request, Response, NextFunction } from "express";
import * as subCategoryService from "../services/subCategory.service";

export const createSubCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const subCategory =
            await subCategoryService.createSubCategory(
                req.body
            );


        return res.status(201).json({

            success: true,

            message:
                "Sub Category created successfully.",

            data: subCategory,

        });

    } catch (error) {

        next(error);

    }
};

export const getAllSubCategories = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            page = "1",
            limit = "10",
            search,
            status,
        } = req.query;


        const searchValue =
            typeof search === "string"
                ? search
                : undefined;


        const statusValue =
            typeof status === "string"
                ? status === "true"
                : undefined;


        const subCategories =
            await subCategoryService.getAllSubCategories(
                Number(page),
                Number(limit),
                searchValue,
                statusValue
            );


        return res.status(200).json({

            success: true,

            message:
                "Sub Categories fetched successfully.",

            data: subCategories,

        });

    } catch (error) {

        next(error);

    }
};

export const getSubCategoryById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Sub Category ID."
            );

        }


        const subCategory =
            await subCategoryService.getSubCategoryById(
                id
            );


        return res.status(200).json({

            success: true,

            message:
                "Sub Category fetched successfully.",

            data: subCategory,

        });

    } catch (error) {

        next(error);

    }
};

export const updateSubCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Sub Category ID."
            );

        }


        const subCategory =
            await subCategoryService.updateSubCategory(
                id,
                req.body
            );


        return res.status(200).json({

            success: true,

            message:
                "Sub Category updated successfully.",

            data: subCategory,

        });

    } catch (error) {

        next(error);

    }
};

export const deleteSubCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Sub Category ID."
            );

        }


        await subCategoryService.deleteSubCategory(
            id
        );


        return res.status(200).json({

            success: true,

            message:
                "Sub Category deleted successfully.",

        });

    } catch (error) {

        next(error);

    }
};

export const restoreSubCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            id,
        } = req.params;


        if (Array.isArray(id)) {

            throw new Error(
                "Invalid Sub Category ID."
            );

        }


        const subCategory =
            await subCategoryService.restoreSubCategory(
                id
            );


        return res.status(200).json({

            success: true,

            message:
                "Sub Category restored successfully.",

            data: subCategory,

        });

    } catch (error) {

        next(error);

    }
};

export const getSubCategoriesByCategory = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {

    try {

        const {
            categoryId,
        } = req.params;


        if (Array.isArray(categoryId)) {

            throw new Error(
                "Invalid Category ID."
            );

        }


        const subCategories =
            await subCategoryService.getByCategory(
                categoryId
            );


        return res.status(200).json({

            success: true,

            message:
                "Sub Categories fetched successfully.",

            data: subCategories,

        });

    } catch (error) {

        next(error);

    }
};