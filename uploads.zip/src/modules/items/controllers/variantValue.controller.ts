
import { Request, Response, NextFunction } from "express";
import * as variantValueService from "../services/variantValue.service";

export const createVariantValue = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const variantValue =
            await variantValueService.createVariantValue(req.body);

        return res.status(201).json({
            success: true,
            message: "Variant Value created successfully.",
            data: variantValue,
        });

    } catch (error) {
        next(error);
    }
};

export const getAllVariantValues = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const {
            page = "1",
            limit = "10",
            search,
            status,
        } = req.query;

        const variantValues =
            await variantValueService.getAllVariantValues(
                Number(page),
                Number(limit),
                search as string,
                status !== undefined
                    ? status === "true"
                    : undefined
            );

        return res.status(200).json({
            success: true,
            message: "Variant Values fetched successfully.",
            data: variantValues,
        });

    } catch (error) {
        next(error);
    }
};

export const getVariantValueById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const variantValue =
            await variantValueService.getVariantValueById(
                req.params.id as string
            );

        return res.status(200).json({
            success: true,
            message: "Variant Value fetched successfully.",
            data: variantValue,
        });

    } catch (error) {
        next(error);
    }
};

export const updateVariantValue = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const variantValue =
            await variantValueService.updateVariantValue(
                req.params.id as string,
                req.body
            );

        return res.status(200).json({
            success: true,
            message: "Variant Value updated successfully.",
            data: variantValue,
        });

    } catch (error) {
        next(error);
    }
};

export const deleteVariantValue = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        await variantValueService.deleteVariantValue(
            req.params.id as string
        );

        return res.status(200).json({
            success: true,
            message: "Variant Value deleted successfully.",
        });

    } catch (error) {
        next(error);
    }
};

export const restoreVariantValue = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const variantValue =
            await variantValueService.restoreVariantValue(
                req.params.id as string
            );

        return res.status(200).json({
            success: true,
            message: "Variant Value restored successfully.",
            data: variantValue,
        });

    } catch (error) {
        next(error);
    }
};