import { Request, Response, NextFunction } from "express";
import * as brandService from "../services/brand.service";


// CREATE BRAND
export const createBrand = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const brand = await brandService.createBrand(req.body);

        return res.status(201).json({
            success: true,
            message: "Brand created successfully.",
            data: brand,
        });

    } catch (error) {
        next(error);
    }
};

export const getAllBrands = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const {
            page = "1",
            limit = "10",
            search,
            status,
        } = req.query;

        const brands = await brandService.getAllBrands(
            Number(page),
            Number(limit),
            search as string,
            status !== undefined
                ? status === "true"
                : undefined
        );

        return res.status(200).json({
            success: true,
            message: "Brands fetched successfully.",
            data: brands,
        });

    } catch (error) {
        next(error);
    }
};


// GET BRAND BY ID
export const getBrandById = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const brand = await brandService.getBrandById(
            req.params.id as string
        );

        return res.status(200).json({
            success: true,
            message: "Brand fetched successfully.",
            data: brand,
        });

    } catch (error) {
        next(error);
    }
};


// UPDATE BRAND
export const updateBrand = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const brand = await brandService.updateBrand(
            req.params.id as string,
            req.body
        );

        return res.status(200).json({
            success: true,
            message: "Brand updated successfully.",
            data: brand,
        });

    } catch (error) {
        next(error);
    }
};


// DELETE BRAND
export const deleteBrand = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        await brandService.deleteBrand(
            req.params.id as string
        );

        return res.status(200).json({
            success: true,
            message: "Brand deleted successfully.",
        });

    } catch (error) {
        next(error);
    }
};


// RESTORE BRAND
export const restoreBrand = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        const brand = await brandService.restoreBrand(
            req.params.id as string
        );

        return res.status(200).json({
            success: true,
            message: "Brand restored successfully.",
            data: brand,
        });

    } catch (error) {
        next(error);
    }
};