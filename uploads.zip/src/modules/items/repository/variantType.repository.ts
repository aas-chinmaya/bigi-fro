import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

export const create = async (
    data: Prisma.VariantTypeCreateInput
) => {

    return prisma.variantType.create({

        data,

    });

};
export const findById = async (
    id: string
) => {

    return prisma.variantType.findFirst({

        where: {

            id,

            // deletedAt: null,

        },

        include: {

            subCategory: true,

        },

    });

};

export const findByCode = async (
    variantTypeCode: string
) => {

    return prisma.variantType.findFirst({

        where: {

            variantTypeCode,

            // deletedAt: null,

        },

    });

};

export const findByName = async (
    subCategoryId: string,
    variantTypeName: string
) => {

    return prisma.variantType.findFirst({

        where: {

            subCategoryId,

            variantTypeName,

            // deletedAt: null,

        },

    });

};

export const findSubCategory = async (
    subCategoryId: string
) => {

    return prisma.productSubCategory.findUnique({

        where: {

            id: subCategoryId,

            // deletedAt: null,

        },

    });

};

export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip =
        (page - 1) * limit;


    const where: Prisma.VariantTypeWhereInput = {

        deletedAt: null,


        ...(search && {

            OR: [

                {
                    variantTypeCode: {

                        contains: search,

                        mode: "insensitive",

                    },
                },

                {
                    variantTypeName: {

                        contains: search,

                        mode: "insensitive",

                    },
                },

            ],

        }),


        ...(status !== undefined && {

            status,

        }),

    };


    const [
        variantTypes,
        total,
    ] = await prisma.$transaction([


        prisma.variantType.findMany({

            where,

            skip,

            take: limit,

            orderBy: {

                createdAt: "desc",

            },

            include: {

                subCategory: {

                    select: {

                        id: true,

                        subCategoryName: true,

                    },

                },

            },

        }),


        prisma.variantType.count({

            where,

        }),

    ]);


    return {

        data: variantTypes,

        total,

        page,

        limit,

        totalPages:
            Math.ceil(
                total / limit
            ),

    };

};

export const update = async (
    id: string,
    data: Prisma.VariantTypeUpdateInput
) => {

    return prisma.variantType.update({

        where: {

            id,

        },

        data,

    });

};

export const softDelete = async (
    id: string
) => {

    return prisma.variantType.update({

        where: {

            id,

        },

        data: {

            deletedAt:
                new Date(),

            status: false,

        },

    });

};

export const restore = async (
    id: string
) => {

    return prisma.variantType.update({

        where: {

            id,

        },

        data: {

            deletedAt: null,

            status: true,

        },

    });

};