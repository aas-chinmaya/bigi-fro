import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";


// CREATE
export const create = async (
    data: Prisma.ProductCreateInput
) => {

    return prisma.product.create({
        data,
        include: {
            category: true,
            subCategory: true,
            brand: true,
            inventoryUnit: true,
            tax: true,
            variantType: true,
            variantValue: true,
        },
    });
};


// FIND BY ID
export const findById = async (
    id: string
) => {

    return prisma.product.findFirst({
        where: {
            id,
            // deletedAt: null,
        },
        include: {
            category: true,
            subCategory: true,
            brand: true,
            inventoryUnit: true,
            tax: true,
            productUnits: true,
            variantType: true,
            variantValue: true,
        },
    });
};


// FIND BY ITEM CODE
export const findByItemCode = async (
    itemCode: string
) => {

    return prisma.product.findFirst({
        where: {
            itemCode,
            // deletedAt: null,
        },
    });
};


// FIND BY ITEM NAME
export const findByItemName = async (
    itemName: string
) => {

    return prisma.product.findFirst({
        where: {
            itemName,
            // deletedAt: null,
        },
    });
};


// FIND CATEGORY
export const findCategory = async (
    id: string
) => {

    return prisma.productCategory.findFirst({
        where: {
            id,
            // deletedAt: null,
        },
    });
};


// FIND SUB CATEGORY
export const findSubCategory = async (
    id: string
) => {

    return prisma.productSubCategory.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
};


// FIND BRAND
export const findBrand = async (
    id: string
) => {

    return prisma.brand.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
};


// FIND INVENTORY UNIT
export const findInventoryUnit = async (
    id: string
) => {

    return prisma.unit.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
};


// FIND TAX
export const findTax = async (
    id: string
) => {

    return prisma.tax.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
};


// FIND BY BARCODE
export const findByBarcode = async (
    barcode: string
) => {

    return prisma.product.findFirst({
        where: {
            barcode,
            deletedAt: null,
        },
    });
};


// FIND VARIANT TYPE
export const findVariantType = async (
    id: string
) => {

    return prisma.variantType.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
};


// FIND VARIANT VALUE
export const findVariantValue = async (
    id: string
) => {

    return prisma.variantValue.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
};


// GET ALL PRODUCTS
export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip = (page - 1) * limit;

    const where: Prisma.ProductWhereInput = {

        deletedAt: null,

        ...(status !== undefined && {
            status,
        }),

        ...(search && {

            OR: [

                {
                    itemCode: {
                        contains: search,
                        mode: "insensitive",
                    },
                },

                {
                    itemName: {
                        contains: search,
                        mode: "insensitive",
                    },
                },

            ],

        }),

    };

    const [products, total] = await prisma.$transaction([

        prisma.product.findMany({

            where,

            skip,

            take: limit,

            orderBy: {
                createdAt: "desc",
            },

            include: {
                category: true,
                subCategory: true,
                brand: true,
                inventoryUnit: true,
                tax: true,
                variantType: true,
                variantValue: true,
            },

        }),

        prisma.product.count({
            where,
        }),

    ]);

    return {

        data: products,

        total,

        page,

        limit,

        totalPages: Math.ceil(total / limit),

    };

};


// UPDATE
export const update = async (
    id: string,
    data: Prisma.ProductUpdateInput
) => {

    return prisma.product.update({

        where: {
            id,
        },

        data,

        include: {
            category: true,
            subCategory: true,
            brand: true,
            inventoryUnit: true,
            tax: true,
            variantType: true,
            variantValue: true,
        },

    });

};


// SOFT DELETE
export const softDelete = async (
    id: string
) => {

    return prisma.product.update({

        where: {
            id,
        },

        data: {

            deletedAt: new Date(),

            status: false,

        },

    });

};


// RESTORE
export const restore = async (
    id: string
) => {

    return prisma.product.update({

        where: {
            id,
        },

        data: {

            deletedAt: null,

            status: true,

        },

    });

};