import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

// =====================================================
// CREATE
// =====================================================

export const create = async (
    data: Prisma.VariantValueCreateInput
) => {

    return prisma.variantValue.create({
        data,
    });
};


// =====================================================
// FIND BY ID
// =====================================================

export const findById = async (
    id: string
) => {

    return prisma.variantValue.findFirst({
        where: {
            id,
            // deletedAt: null,
        },
        include: {
            variantType: true,
        },
    });
};


// =====================================================
// FIND VARIANT TYPE
// =====================================================

export const findVariantType = async (
    id: string
) => {

    return prisma.variantType.findFirst({
        where: {
            id,
            // deletedAt: null,
        },
    });
};


// =====================================================
// FIND BY VALUE
// =====================================================

export const findByValue = async (
    variantTypeId: string,
    value: string
) => {

    return prisma.variantValue.findFirst({
        where: {
            variantTypeId,
            value,
            // deletedAt: null,
        },
    });
};


// =====================================================
// GET ALL
// =====================================================

export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip = (page - 1) * limit;

    const where: Prisma.VariantValueWhereInput = {

        deletedAt: null,

        ...(search && {
            OR: [
                {
                    value: {
                        contains: search,
                        mode: "insensitive",
                    },
                },
                {
                    shortName: {
                        contains: search,
                        mode: "insensitive",
                    },
                },
            ],
        }),

        ...(status !== undefined && {
            status,
        }),

    };

    const [
        variantValues,
        total,
    ] = await prisma.$transaction([

        prisma.variantValue.findMany({

            where,

            skip,

            take: limit,

            orderBy: {
                displayOrder: "asc",
            },

            include: {
                variantType: {
                    select: {
                        id: true,
                        variantTypeName: true,
                        variantTypeCode: true,
                    },
                },
            },

        }),

        prisma.variantValue.count({
            where,
        }),

    ]);

    return {
        data: variantValues,
        total,
        page,
        limit,
        totalPages: Math.ceil(
            total / limit
        ),
    };
};


// =====================================================
// UPDATE
// =====================================================

export const update = async (
    id: string,
    data: Prisma.VariantValueUpdateInput
) => {

    return prisma.variantValue.update({
        where: {
            id,
        },
        data,
    });
};


// =====================================================
// SOFT DELETE
// =====================================================

export const softDelete = async (
    id: string
) => {

    return prisma.variantValue.update({
        where: {
            id,
        },
        data: {
            deletedAt: new Date(),
            status: false,
        },
    });
};


// =====================================================
// RESTORE
// =====================================================

export const restore = async (
    id: string
) => {

    return prisma.variantValue.update({
        where: {
            id,
        },
        data: {
            deletedAt: null,
            status: true,
        },
    });
};