import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

// =====================================================
// CREATE
// =====================================================

  export const create = async (
    data: Prisma.ServiceCreateInput
) => {

    return prisma.service.create({

        data,

        include: {
            category: true,
            subCategory: true,
            tax: true,
        },

    });
};

 export const findById = async (
    id: string
) => {

    return prisma.service.findFirst({

        where: {
            id,
            deletedAt: null,
        },

        include: {
            category: true,
            subCategory: true,
            tax: true,
        },

    });
};

 export const findByServiceCode = async (
    serviceCode: string
) => {

    return prisma.service.findFirst({

        where: {
            serviceCode,
            deletedAt: null,
        },

    });
};

 export const findByServiceName = async (
    serviceName: string
) => {

    return prisma.service.findFirst({

        where: {
            serviceName,
            deletedAt: null,
        },

    });
};

 export const findBySacCode = async (
    sacCode: string
) => {

    return prisma.service.findFirst({

        where: {
            sacCode,
            deletedAt: null,
        },

    });
};

 export const findCategory = async (
    categoryId: string
) => {

    return prisma.productCategory.findFirst({

        where: {
            id: categoryId,
            // deletedAt: null,
        },

    });
};

export const findSubCategory = async (
    subCategoryId: string
) => {

    return prisma.productSubCategory.findFirst({

        where: {
            id: subCategoryId,
            // deletedAt: null,
        },

    });
};

 export const findTax = async (
    taxId: string
) => {

    return prisma.tax.findFirst({

        where: {
            id: taxId,
            // deletedAt: null,
        },

    });
};

 export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip =
        (page - 1) * limit;


    const where: Prisma.ServiceWhereInput = {

        deletedAt: null,

        ...(status !== undefined && {
            status,
        }),

        ...(search && {
            OR: [

                {
                    serviceCode: {
                        contains: search,
                        mode: "insensitive",
                    },
                },

                {
                    serviceName: {
                        contains: search,
                        mode: "insensitive",
                    },
                },

                {
                    sacCode: {
                        contains: search,
                        mode: "insensitive",
                    },
                },

            ],
        }),
    };


    const [
        services,
        total,
    ] = await Promise.all([

        prisma.service.findMany({

            where,

            skip,

            take: limit,

            orderBy: {
                createdAt: "desc",
            },

            include: {
                category: true,
                subCategory: true,
                tax: true,
            },

        }),

        prisma.service.count({
            where,
        }),

    ]);


    return {

        data: services,

        pagination: {

            total,

            page,

            limit,

            totalPages:
                Math.ceil(
                    total / limit
                ),

        },

    };
};

 export const update = async (
    id: string,
    data: Prisma.ServiceUpdateInput
) => {

    return prisma.service.update({

        where: {
            id,
        },

        data,

        include: {
            category: true,
            subCategory: true,
            tax: true,
        },

    });
};


 export const softDelete = async (
    id: string
) => {

    return prisma.service.update({

        where: {
            id,
        },

        data: {
            deletedAt: new Date(),
            status: false,
        },

    });
};

export const restore = async (
    id: string
) => {

    return prisma.service.update({

        where: {
            id,
        },

        data: {
            deletedAt: null,
            status: true,
        },

        include: {
            category: true,
            subCategory: true,
            tax: true,
        },

    });
};