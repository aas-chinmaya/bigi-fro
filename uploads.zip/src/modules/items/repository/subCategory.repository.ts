import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

export const create = async (
    data: Prisma.ProductSubCategoryCreateInput
) => {

    return prisma.productSubCategory.create({

        data,

        include: {
            category: {
                select: {
                    id: true,
                    categoryName: true,
                },
            },
        },

    });
};


export const findById = async (
    id: string
) => {

    return prisma.productSubCategory.findFirst({

        where: {
            id,
            // deletedAt: null,
        },

        include: {
            category: {
                select: {
                    id: true,
                    categoryName: true,
                },
            },
        },

    });
};

export const findByName = async (
    categoryId: string,
    subCategoryName: string
) => {

    return prisma.productSubCategory.findFirst({

        where: {
            categoryId,
            subCategoryName,
            // deletedAt: null,
        },

    });
};

export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip =
        (page - 1) * limit;


    const where: Prisma.ProductSubCategoryWhereInput = {

        deletedAt: null,

        ...(search && {
            subCategoryName: {
                contains: search,
                mode: "insensitive",
            },
        }),

        ...(status !== undefined && {
            status,
        }),

    };


    const [
        subCategories,
        total,
    ] = await prisma.$transaction([

        prisma.productSubCategory.findMany({

            where,

            skip,

            take: limit,

            include: {
                category: {
                    select: {
                        id: true,
                        categoryName: true,
                        categoryType: true,
                    },
                },
            },

            orderBy: {
                createdAt: "desc",
            },

        }),

        prisma.productSubCategory.count({
            where,
        }),

    ]);


    return {

        data: subCategories,

        total,

        page,

        limit,

        totalPages:
            Math.ceil(
                total / limit
            ),

    };
};


export const update = async (
    id: string,
    data: Prisma.ProductSubCategoryUpdateInput
) => {

    return prisma.productSubCategory.update({

        where: {
            id,
        },

        data,

        include: {
            category: {
                select: {
                    id: true,
                    categoryName: true,
                },
            },
        },

    });
};

export const softDelete = async (
    id: string
) => {

    return prisma.productSubCategory.update({

        where: {
            id,
        },

        data: {
            deletedAt: new Date(),
            status: false,
        },

    });
};


export const restore = async (
    id: string
) => {

    return prisma.productSubCategory.update({

        where: {
            id,
        },

        data: {
            deletedAt: null,
            status: true,
        },

    });
};

export const getByCategoryId = async (
    categoryId: string
) => {

    return prisma.productSubCategory.findMany({

        where: {
            categoryId,
            deletedAt: null,
            status: true,
        },

        orderBy: {
            subCategoryName: "asc",
        },

    });
};