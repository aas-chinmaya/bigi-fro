import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";


// CREATE
export const create = async (
    data: Prisma.ProductUnitCreateInput
) => {

    return prisma.productUnit.create({
        data,
        include: {
            product: true,
            fromUnit: true,
            toUnit: true,
        },
    });
};


// FIND BY ID
export const findById = async (
    id: string
) => {

    return prisma.productUnit.findFirst({
        where: {
            id,
            deletedAt: null,
        },
        include: {
            product: true,
            fromUnit: true,
            toUnit: true,
        },
    });
};


// FIND PRODUCT
export const findProduct = async (
    productId: string
) => {

    return prisma.product.findFirst({
        where: {
            id: productId,
            deletedAt: null,
        },
    });
};


// FIND UNIT
export const findUnit = async (
    id: string
) => {

    return prisma.unit.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
};


// FIND DUPLICATE
export const findDuplicate = async (
    productId: string,
    fromUnitId: string,
    toUnitId: string
) => {

    return prisma.productUnit.findFirst({
        where: {
            productId,
            fromUnitId,
            toUnitId,
            deletedAt: null,
        },
    });
};


// GET ALL
export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip = (page - 1) * limit;

    const where: Prisma.ProductUnitWhereInput = {

        deletedAt: null,

        ...(status !== undefined && {
            status,
        }),

        ...(search && {
            product: {
                itemName: {
                    contains: search,
                    mode: "insensitive",
                },
            },
        }),

    };

    const [data, total] = await prisma.$transaction([

        prisma.productUnit.findMany({

            where,

            skip,

            take: limit,

            orderBy: {
                createdAt: "desc",
            },

            include: {
                product: true,
                fromUnit: true,
                toUnit: true,
            },

        }),

        prisma.productUnit.count({
            where,
        }),

    ]);

    return {

        data,

        total,

        page,

        limit,

        totalPages: Math.ceil(total / limit),

    };

};


// UPDATE
export const update = async (
    id: string,
    data: Prisma.ProductUnitUpdateInput
) => {

    return prisma.productUnit.update({

        where: {
            id,
        },

        data,

        include: {
            product: true,
            fromUnit: true,
            toUnit: true,
        },

    });
};


// SOFT DELETE
export const softDelete = async (
    id: string
) => {

    return prisma.productUnit.update({

        where: {
            id,
        },

        data: {
            deletedAt: new Date(),
            status: false,
        },

    });
};


// RESTORE
export const restore = async (
    id: string
) => {

    return prisma.productUnit.update({

        where: {
            id,
        },

        data: {
            deletedAt: null,
            status: true,
        },

    });
};


// FIND PRODUCT BY BARCODE
export const findByBarcode = async (
    barcode: string
) => {

    return prisma.product.findFirst({

        where: {

            barcode,

            deletedAt: null,

        },

    });

};