import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";


export const create = async (
    data: Prisma.UnitCreateInput
) => {

    return prisma.unit.create({

        data,

    });

};

export const findById = async (
    id: string
) => {

    return prisma.unit.findFirst({

        where: {

            id,

            // deletedAt: null,

        },

    });

};
export const findByName = async (
    unitName: string
) => {

    return prisma.unit.findFirst({

        where: {

            unitName,

            // deletedAt: null,

        },

    });

};

export const findByShortName = async (
    shortName: string
) => {

    return prisma.unit.findFirst({

        where: {

            shortName,

            // deletedAt: null,

        },

    });

};
export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip =
        (page - 1) * limit;


    const where: Prisma.UnitWhereInput = {

        deletedAt: null,


        ...(search && {

            OR: [

                {
                    unitName: {

                        contains: search,

                        mode: "insensitive",

                    },
                },

                {
                    shortName: {

                        contains: search,

                        mode: "insensitive",

                    },
                },

            ],

        }),


        ...(status !== undefined && {

            status,

        }),

    };


    const [
        units,
        total,
    ] = await prisma.$transaction([


        prisma.unit.findMany({

            where,

            skip,

            take: limit,

            orderBy: {

                createdAt: "desc",

            },

        }),


        prisma.unit.count({

            where,

        }),

    ]);


    return {

        data: units,

        total,

        page,

        limit,

        totalPages:
            Math.ceil(
                total / limit
            ),

    };

};


export const update = async (
    id: string,
    data: Prisma.UnitUpdateInput
) => {

    return prisma.unit.update({

        where: {

            id,

        },

        data,

    });

};

export const softDelete = async (
    id: string
) => {

    return prisma.unit.update({

        where: {

            id,

        },

        data: {

            deletedAt:
                new Date(),

            status: false,

        },

    });

};


export const restore = async (
    id: string
) => {

    return prisma.unit.update({

        where: {

            id,

        },

        data: {

            deletedAt: null,

            status: true,

        },

    });

};