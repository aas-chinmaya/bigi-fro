import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";


// CREATE
export const create = async (
    data: Prisma.ProductCategoryCreateInput
) => {

    return prisma.productCategory.create({
        data,
    });
};


// FIND BY ID
export const findById = async (
    id: string
) => {

    return prisma.productCategory.findFirst({
        where: {
            id,
            // deletedAt: null,
        },
    });
};


// FIND BY NAME
export const findByName = async (
    categoryName: string
) => {

    return prisma.productCategory.findFirst({
        where: {
            categoryName,
            // deletedAt: null,
        },
    });
};


// GET ALL
export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip = (page - 1) * limit;

    const where: Prisma.ProductCategoryWhereInput = {
        deletedAt: null,

        ...(search && {
            categoryName: {
                contains: search,
                mode: "insensitive",
            },
        }),

        ...(status !== undefined && {
            status,
        }),
    };

    const [categories, total] = await prisma.$transaction([

        prisma.productCategory.findMany({

            where,

            skip,

            take: limit,

            orderBy: {
                createdAt: "desc",
            },

        }),

        prisma.productCategory.count({
            where,
        }),

    ]);

    return {
        data: categories,
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
    };
};


// UPDATE
export const update = async (
    id: string,
    data: Prisma.ProductCategoryUpdateInput
) => {

    return prisma.productCategory.update({

        where: {
            id,
        },

        data,

    });
};


// SOFT DELETE
export const softDelete = async (
    id: string
) => {

    return prisma.productCategory.update({

        where: {
            id,
        },

        data: {
            deletedAt: new Date(),
            status: false,
        },

    });
};


// RESTORE
export const restore = async (
    id: string
) => {

    return prisma.productCategory.update({

        where: {
            id,
        },

        data: {
            deletedAt: null,
            status: true,
        },

    });
};