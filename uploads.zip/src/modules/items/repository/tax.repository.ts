import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";


export const create = async (
    data: Prisma.TaxCreateInput
) => {

    return prisma.tax.create({

        data,

    });
};


export const findById = async (
    id: string
) => {

    return prisma.tax.findFirst({

        where: {

            id,

            deletedAt: null,

        },

    });
};


export const findByHsnCode = async (
    hsnCode: string
) => {

    return prisma.tax.findFirst({

        where: {

            hsnCode,

            deletedAt: null,

        },

    });
};


export const findBySacCode = async (
    sacCode: string
) => {

    return prisma.tax.findFirst({

        where: {

            sacCode,

            deletedAt: null,

        },

    });
};

export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip =
        (page - 1) * limit;


    const where: Prisma.TaxWhereInput = {

        deletedAt: null,


        ...(search && {

            OR: [

                {
                    hsnCode: {

                        contains: search,

                        mode: "insensitive",

                    },
                },

                {
                    sacCode: {

                        contains: search,

                        mode: "insensitive",

                    },
                },

            ],

        }),


        ...(status !== undefined && {

            status,

        }),

    };


    const [
        taxes,
        total,
    ] = await prisma.$transaction([


        prisma.tax.findMany({

            where,

            skip,

            take: limit,

            orderBy: {

                createdAt: "desc",

            },

        }),


        prisma.tax.count({

            where,

        }),

    ]);


    return {

        data: taxes,

        total,

        page,

        limit,

        totalPages:
            Math.ceil(
                total / limit
            ),

    };
};

export const update = async (
    id: string,
    data: Prisma.TaxUpdateInput
) => {

    return prisma.tax.update({

        where: {

            id,

        },

        data,

    });
};

export const softDelete = async (
    id: string
) => {

    return prisma.tax.update({

        where: {

            id,

        },

        data: {

            deletedAt:
                new Date(),

            status: false,

        },

    });
};

export const restore = async (
    id: string
) => {

    return prisma.tax.update({

        where: {

            id,

        },

        data: {

            deletedAt: null,

            status: true,

        },

    });
};