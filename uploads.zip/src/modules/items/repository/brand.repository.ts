import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";


// CREATE
export const create = async (
    data: Prisma.BrandCreateInput
) => {

    return prisma.brand.create({
        data,
    });
};


// FIND BY ID
export const findById = async (
    id: string
) => {

    return prisma.brand.findFirst({
        where: {
            id,
            // deletedAt: null,
        },
    });
};


// FIND BY NAME
export const findByName = async (
    brandName: string
) => {

    return prisma.brand.findFirst({
        where: {
            brandName,
            // deletedAt: null,
        },
    });
};


// GET ALL
export const getAll = async (
    page: number,
    limit: number,
    search?: string,
    status?: boolean
) => {

    const skip = (page - 1) * limit;

    const where: Prisma.BrandWhereInput = {

        deletedAt: null,

        ...(search && {
            brandName: {
                contains: search,
                mode: "insensitive",
            },
        }),

        ...(status !== undefined && {
            status,
        }),

    };

    const [brands, total] = await prisma.$transaction([

        prisma.brand.findMany({

            where,

            skip,

            take: limit,

            orderBy: {
                createdAt: "desc",
            },

        }),

        prisma.brand.count({
            where,
        }),

    ]);

    return {

        data: brands,
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),

    };
};


// UPDATE
export const update = async (
    id: string,
    data: Prisma.BrandUpdateInput
) => {

    return prisma.brand.update({

        where: {
            id,
        },

        data,

    });

};


// SOFT DELETE
export const softDelete = async (
    id: string
) => {

    return prisma.brand.update({

        where: {
            id,
        },

        data: {
            deletedAt: new Date(),
            status: false,
        },

    });

};
// RESTORE
export const restore = async (
    id: string
) => {

    return prisma.brand.update({

        where: {
            id,
        },

        data: {
            deletedAt: null,
            status: true,
        },

    });

};




