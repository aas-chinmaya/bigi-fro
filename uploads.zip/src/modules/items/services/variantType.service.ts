import * as variantTypeRepository from "../repository/variantType.repository";
import ValidationError from "../../../common/exceptions/ValidationError";


export const createVariantType = async (
    payload: {
        subCategoryId: string;
        variantTypeCode: string;
        variantTypeName: string;
        description?: string;
        status?: boolean;
    }
) => {

    const {
        subCategoryId,
        variantTypeCode,
        variantTypeName,
        description,
        status = true,
    } = payload;
    if (!subCategoryId) {

        throw new ValidationError(
            "Sub Category is required."
        );

    }
   if (!variantTypeCode?.trim()) {

        throw new ValidationError(
            "Variant Type Code is required."
        );

    }

    if (!variantTypeName?.trim()) {

        throw new ValidationError(
            "Variant Type Name is required."
        );

    }

    const subCategory =
        await variantTypeRepository.findSubCategory(
            subCategoryId
        );


    if (!subCategory) {

        throw new ValidationError(
            "Sub Category not found."
        );

    }

    const existingCode =
        await variantTypeRepository.findByCode(
            variantTypeCode.trim()
        );


    if (existingCode) {

        // Existing but inactive / deleted
        if (
            existingCode.status === false ||
            existingCode.deletedAt !== null
        ) {

            return await variantTypeRepository.update(
                existingCode.id,
                {
                    description,
                    status: true,
                    deletedAt: null,
                }
            );

        }


        throw new ValidationError(
            "Variant Type Code already exists and is active."
        );

    }
    const existingName =
        await variantTypeRepository.findByName(
            subCategoryId,
            variantTypeName.trim()
        );


    if (existingName) {

        // Existing but inactive / deleted
        if (
            existingName.status === false ||
            existingName.deletedAt !== null
        ) {

            return await variantTypeRepository.update(
                existingName.id,
                {
                    description,
                    status: true,
                    deletedAt: null,
                }
            );

        }


        throw new ValidationError(
            "Variant Type Name already exists for this Sub Category."
        );

    }
    return await variantTypeRepository.create({

        variantTypeCode:
            variantTypeCode.trim(),

        variantTypeName:
            variantTypeName.trim(),

        description,

        status,

        subCategory: {

            connect: {

                id: subCategoryId,

            },

        },

    });

};

export const getAllVariantTypes = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    page = Number(page);

    limit = Number(limit);


    if (page < 1) {

        page = 1;

    }


    if (limit < 1) {

        limit = 10;

    }


    return await variantTypeRepository.getAll(

        page,

        limit,

        search,

        status

    );

};

export const getVariantTypeById = async (
    id: string
) => {

    const variantType =
        await variantTypeRepository.findById(
            id
        );


    if (!variantType) {

        throw new ValidationError(
            "Variant Type not found."
        );

    }


    return variantType;

};

export const updateVariantType = async (
    id: string,
    payload: {
        subCategoryId?: string;
        variantTypeCode?: string;
        variantTypeName?: string;
        description?: string;
        status?: boolean;
    }
) => {

    const variantType =
        await variantTypeRepository.findById(
            id
        );


    if (!variantType) {

        throw new ValidationError(
            "Variant Type not found."
        );

    }


    if (payload.subCategoryId) {

        const subCategory =
            await variantTypeRepository.findSubCategory(
                payload.subCategoryId
            );


        if (!subCategory) {

            throw new ValidationError(
                "Sub Category not found."
            );

        }

    }

    if (payload.variantTypeCode) {

        const existingCode =
            await variantTypeRepository.findByCode(
                payload.variantTypeCode.trim()
            );


        if (
            existingCode &&
            existingCode.id !== id
        ) {

            throw new ValidationError(
                "Variant Type Code already exists."
            );

        }

    }

    if (
        payload.variantTypeName &&
        (
            payload.subCategoryId ||
            variantType.subCategoryId
        )
    ) {

        const subCategoryId =
            payload.subCategoryId ||
            variantType.subCategoryId;


        const existingName =
            await variantTypeRepository.findByName(

                subCategoryId,

                payload.variantTypeName.trim()

            );

        if (
            existingName &&
            existingName.id !== id
        ) {

            throw new ValidationError(
                "Variant Type Name already exists."
            );

        }

    }

    return await variantTypeRepository.update(

        id,

        {

            variantTypeCode:
                payload.variantTypeCode?.trim(),

            variantTypeName:
                payload.variantTypeName?.trim(),

            description:
                payload.description,

            status:
                payload.status,


            ...(payload.subCategoryId && {

                subCategory: {

                    connect: {

                        id:
                            payload.subCategoryId,

                    },

                },

            }),

        }

    );

};

export const deleteVariantType = async (
    id: string
) => {

    const variantType =
        await variantTypeRepository.findById(
            id
        );


    if (!variantType) {

        throw new ValidationError(
            "Variant Type not found."
        );

    }


    return await variantTypeRepository.softDelete(
        id
    );

};

export const restoreVariantType = async (
    id: string
) => {

    const variantType =
        await variantTypeRepository.findById(
            id
        );


    if (variantType) {

        throw new ValidationError(
            "Variant Type is already active."
        );

    }


    return await variantTypeRepository.restore(
        id
    );

};