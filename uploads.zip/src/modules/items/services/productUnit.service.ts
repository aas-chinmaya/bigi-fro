import * as productUnitRepository from "../repository/productUnit.repository";
import ValidationError from "../../../common/exceptions/ValidationError";


// CREATE PRODUCT UNIT
export const createProductUnit = async (payload: any) => {

    const {
        productId,
        fromUnitId,
        toUnitId,
        conversionFactor,
        operation,
        isDefaultPurchase = false,
        isDefaultSales = false,
        isInventoryUnit = false,
        status = true,
    } = payload;


    if (!productId) {
        throw new ValidationError("Product is required.");
    }

    if (!fromUnitId) {
        throw new ValidationError("From Unit is required.");
    }

    if (!toUnitId) {
        throw new ValidationError("To Unit is required.");
    }

    if (fromUnitId === toUnitId) {
        throw new ValidationError(
            "From Unit and To Unit cannot be the same."
        );
    }

    if (!conversionFactor || conversionFactor <= 0) {
        throw new ValidationError(
            "Conversion Factor must be greater than 0."
        );
    }

    if (!operation?.trim()) {
        throw new ValidationError("Operation is required.");
    }

    if (operation !== "*" && operation !== "/") {
        throw new ValidationError(
            "Operation must be '*' or '/'."
        );
    }


    // Validate Product
    const product =
        await productUnitRepository.findProduct(productId);

    if (!product) {
        throw new ValidationError("Product not found.");
    }


    // Validate From Unit
    const fromUnit =
        await productUnitRepository.findUnit(fromUnitId);

    if (!fromUnit) {
        throw new ValidationError("From Unit not found.");
    }


    // Validate To Unit
    const toUnit =
        await productUnitRepository.findUnit(toUnitId);

    if (!toUnit) {
        throw new ValidationError("To Unit not found.");
    }


    // Duplicate Validation
    const duplicate =
        await productUnitRepository.findDuplicate(
            productId,
            fromUnitId,
            toUnitId
        );

    if (duplicate) {
        throw new ValidationError(
            "Unit conversion already exists for this product."
        );
    }


    return await productUnitRepository.create({

        conversionFactor,

        operation,

        isDefaultPurchase,

        isDefaultSales,

        isInventoryUnit,

        status,

        product: {
            connect: {
                id: productId,
            },
        },

        fromUnit: {
            connect: {
                id: fromUnitId,
            },
        },

        toUnit: {
            connect: {
                id: toUnitId,
            },
        },

    });

};


// GET ALL PRODUCT UNITS
export const getAllProductUnits = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    page = Number(page);
    limit = Number(limit);

    if (page < 1) page = 1;
    if (limit < 1) limit = 10;

    return await productUnitRepository.getAll(
        page,
        limit,
        search,
        status
    );

};


// GET PRODUCT UNIT BY ID
export const getProductUnitById = async (
    id: string
) => {

    const productUnit =
        await productUnitRepository.findById(id);

    if (!productUnit) {
        throw new ValidationError(
            "Product Unit not found."
        );
    }

    return productUnit;

};


// UPDATE PRODUCT UNIT
export const updateProductUnit = async (
    id: string,
    payload: any
) => {

    const existing =
        await productUnitRepository.findById(id);

    if (!existing) {
        throw new ValidationError(
            "Product Unit not found."
        );
    }


    if (payload.productId) {

        const product =
            await productUnitRepository.findProduct(
                payload.productId
            );

        if (!product) {
            throw new ValidationError(
                "Product not found."
            );
        }

    }


    if (payload.fromUnitId) {

        const fromUnit =
            await productUnitRepository.findUnit(
                payload.fromUnitId
            );

        if (!fromUnit) {
            throw new ValidationError(
                "From Unit not found."
            );
        }

    }


    if (payload.toUnitId) {

        const toUnit =
            await productUnitRepository.findUnit(
                payload.toUnitId
            );

        if (!toUnit) {
            throw new ValidationError(
                "To Unit not found."
            );
        }

    }


    if (
        payload.fromUnitId &&
        payload.toUnitId &&
        payload.fromUnitId === payload.toUnitId
    ) {

        throw new ValidationError(
            "From Unit and To Unit cannot be the same."
        );

    }


    if (
        payload.conversionFactor !== undefined &&
        payload.conversionFactor <= 0
    ) {

        throw new ValidationError(
            "Conversion Factor must be greater than 0."
        );

    }


    return await productUnitRepository.update(id, {

        conversionFactor:
            payload.conversionFactor,

        operation:
            payload.operation,

        isDefaultPurchase:
            payload.isDefaultPurchase,

        isDefaultSales:
            payload.isDefaultSales,

        isInventoryUnit:
            payload.isInventoryUnit,

        status:
            payload.status,

        ...(payload.productId && {
            product: {
                connect: {
                    id: payload.productId,
                },
            },
        }),

        ...(payload.fromUnitId && {
            fromUnit: {
                connect: {
                    id: payload.fromUnitId,
                },
            },
        }),

        ...(payload.toUnitId && {
            toUnit: {
                connect: {
                    id: payload.toUnitId,
                },
            },
        }),

    });

};


// DELETE PRODUCT UNIT
export const deleteProductUnit = async (
    id: string
) => {

    const existing =
        await productUnitRepository.findById(id);

    if (!existing) {
        throw new ValidationError(
            "Product Unit not found."
        );
    }

    return await productUnitRepository.softDelete(id);

};


// RESTORE PRODUCT UNIT
export const restoreProductUnit = async (
    id: string
) => {

    return await productUnitRepository.restore(id);

};