import * as productRepository from "../repository/product.repository";
import ValidationError from "../../../common/exceptions/ValidationError";
import { getFileUrl } from "../../../utils/fileUrl.util";


const formatProduct = <T extends { image?: string | null }>(product: T) => ({
    ...product,
    image: getFileUrl(product.image),
});


// CREATE PRODUCT
export const createProduct = async (payload: any) => {

    const {
        tenantId,
        itemCode,
        barcode,
        itemName,
        description,
        categoryId,
        subCategoryId,
        brandId,
        inventoryUnitId,
        taxId,
        hsnCode,
        minimumStock,
        maximumStock,
        variantTypeId,
        variantValueId,
        image,
        status = true,
    } = payload;


    if (!itemCode?.trim()) {
        throw new ValidationError("Item Code is required.");
    }

    if (!itemName?.trim()) {
        throw new ValidationError("Item Name is required.");
    }

    const codeExists = await productRepository.findByItemCode(
        itemCode.trim()
    );

    if (codeExists) {

        // Existing product is inactive or soft deleted
        if (
            codeExists.status === false ||
            codeExists.deletedAt !== null
        ) {
            return await productRepository.update(
                codeExists.id,
                {
                    description,
                    status: true,
                    deletedAt: null,
                }
            );
        }

        // Existing product is active
        throw new ValidationError(
            "Item Code already exists and is active."
        );
    }


    if (barcode?.trim()) {

        const barcodeExists = await productRepository.findByBarcode(
            barcode.trim()
        );

        if (barcodeExists) {

            // Existing product is inactive or soft deleted
            if (
                barcodeExists.status === false ||
                barcodeExists.deletedAt !== null
            ) {
                return await productRepository.update(
                    barcodeExists.id,
                    {
                        description,
                        status: true,
                        deletedAt: null,
                    }
                );
            }

            // Existing product is active
            throw new ValidationError(
                "Barcode already exists and is active."
            );
        }
    }


    const nameExists = await productRepository.findByItemName(
        itemName.trim()
    );

    if (nameExists) {

        // Existing product is inactive or soft deleted
        if (
            nameExists.status === false ||
            nameExists.deletedAt !== null
        ) {
            return await productRepository.update(
                nameExists.id,
                {
                    description,
                    status: true,
                    deletedAt: null,
                }
            );
        }

        // Existing product is active
        throw new ValidationError(
            "Item Name already exists and is active."
        );
    }


    const category = await productRepository.findCategory(
        categoryId
    );

    if (!category) {
        throw new ValidationError("Category not found.");
    }


    const subCategory =
        await productRepository.findSubCategory(
            subCategoryId
        );

    if (!subCategory) {
        throw new ValidationError("Sub Category not found.");
    }

    if (subCategory.categoryId !== categoryId) {
        throw new ValidationError(
            "Sub Category does not belong to selected Category."
        );
    }
    const brand = await productRepository.findBrand(
        brandId
    );

    if (!brand) {
        throw new ValidationError("Brand not found.");
    }
    const unit = await productRepository.findInventoryUnit(
        inventoryUnitId
    );

    if (!unit) {
        throw new ValidationError("Inventory Unit not found.");
    }
    const tax = await productRepository.findTax(
        taxId
    );

    if (!tax) {
        throw new ValidationError("Tax not found.");
    }
    if (
        minimumStock !== undefined &&
        maximumStock !== undefined &&
        minimumStock > maximumStock
    ) {
        throw new ValidationError(
            "Minimum Stock cannot be greater than Maximum Stock."
        );
    }
    if (variantTypeId && !variantValueId) {
        throw new ValidationError(
            "Variant Value is required when Variant Type is selected."
        );
    }
    if (variantValueId && !variantTypeId) {
        throw new ValidationError(
            "Variant Type is required when Variant Value is selected."
        );
    }
    if (variantTypeId && variantValueId) {
        const variantType =
            await productRepository.findVariantType(
                variantTypeId
            );
            if (!variantType) {
            throw new ValidationError(
                "Variant Type not found."
            );
        }
        const variantValue =
            await productRepository.findVariantValue(
                variantValueId
            );

        if (!variantValue) {
            throw new ValidationError(
                "Variant Value not found."
            );
        }
         if (
            variantValue.variantTypeId !== variantTypeId
        ) {
            throw new ValidationError(
                "Variant Value does not belong to selected Variant Type."
            );
        }
    }
    const product = await productRepository.create({

        tenantId,

        itemCode: itemCode.trim(),

        barcode: barcode?.trim(),

        itemName: itemName.trim(),

        description,

        hsnCode,

        minimumStock,

        maximumStock,

        image,

        status,

        category: {
            connect: {
                id: categoryId,
            },
        },

        subCategory: {
            connect: {
                id: subCategoryId,
            },
        },

        brand: {
            connect: {
                id: brandId,
            },
        },

        inventoryUnit: {
            connect: {
                id: inventoryUnitId,
            },
        },

        tax: {
            connect: {
                id: taxId,
            },
        },

        ...(variantTypeId && {
            variantType: {
                connect: {
                    id: variantTypeId,
                },
            },
        }),

        ...(variantValueId && {
            variantValue: {
                connect: {
                    id: variantValueId,
                },
            },
        }),
    });

    return formatProduct(product);
};


// GET ALL PRODUCTS
export const getAllProducts = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    const result = await productRepository.getAll(
        Number(page),
        Number(limit),
        search,
        status
    );

    return {
        ...result,
        data: result.data.map(formatProduct),
    };

};


// GET PRODUCT BY ID
export const getProductById = async (
    id: string
) => {

    const product = await productRepository.findById(id);

    if (!product) {
        throw new ValidationError("Product not found.");
    }

    return formatProduct(product);

};


// UPDATE PRODUCT
export const updateProduct = async (
    id: string,
    payload: any
) => {

    const product = await productRepository.findById(id);

    if (!product) {
        throw new ValidationError("Product not found.");
    }


    if (
        payload.minimumStock !== undefined &&
        payload.maximumStock !== undefined &&
        payload.minimumStock > payload.maximumStock
    ) {
        throw new ValidationError(
            "Minimum Stock cannot be greater than Maximum Stock."
        );
    }


    const updatedProduct = await productRepository.update(id, {

        tenantId: payload.tenantId?.trim(),

        itemCode: payload.itemCode?.trim(),

        itemName: payload.itemName?.trim(),

        description: payload.description,

        hsnCode: payload.hsnCode,

        minimumStock: payload.minimumStock,

        maximumStock: payload.maximumStock,

        // image: payload.image,
        ...(payload.image !== undefined && {
        image: payload.image,
        }),

        status: payload.status,

        ...(payload.categoryId && {
            category: {
                connect: {
                    id: payload.categoryId,
                },
            },
        }),

        ...(payload.subCategoryId && {
            subCategory: {
                connect: {
                    id: payload.subCategoryId,
                },
            },
        }),

        ...(payload.brandId && {
            brand: {
                connect: {
                    id: payload.brandId,
                },
            },
        }),

        ...(payload.inventoryUnitId && {
            inventoryUnit: {
                connect: {
                    id: payload.inventoryUnitId,
                },
            },
        }),

        ...(payload.taxId && {
            tax: {
                connect: {
                    id: payload.taxId,
                },
            },
        }),

        ...(payload.variantTypeId !== undefined && {
            variantType: {
                connect: {
                    id: payload.variantTypeId,
                },
            },
        }),

        ...(payload.variantValueId !== undefined && {
            variantValue: {
                connect: {
                    id: payload.variantValueId,
                },
            },
        }),

    });

    return formatProduct(updatedProduct);

};


// DELETE PRODUCT
export const deleteProduct = async (
    id: string
) => {

    const product = await productRepository.findById(id);

    if (!product) {
        throw new ValidationError("Product not found.");
    }

    return await productRepository.softDelete(id);

};


// RESTORE PRODUCT
export const restoreProduct = async (
    id: string
) => {

    return await productRepository.restore(id);

};