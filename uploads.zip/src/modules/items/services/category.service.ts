import * as categoryRepository from "../repository/category.repository";
import ValidationError from "../../../common/exceptions/ValidationError";


// CREATE CATEGORY
export const createCategory = async (
    payload: {
        categoryName: string;
        categoryType: "PRODUCT" | "SERVICE";
        description?: string;
        status?: boolean;
    }
) => {

    const {
        categoryName,
        categoryType,
        description,
        status = true,
    } = payload;

    if (!categoryName?.trim()) {
        throw new ValidationError("Category name is required");
    }

    const existingCategory = await categoryRepository.findByName(
        categoryName.trim()
    );

    if (existingCategory) {

        // Category exists but is inactive
        if (existingCategory.status === false) {

            return await categoryRepository.update(
                existingCategory.id,
                {
                    categoryType,
                    description,
                    status: true,
                    deletedAt: null,
                }
            );
        }

        // Category already active
        throw new ValidationError(
            "Category already exists and is active."
        );
    }

    return await categoryRepository.create({
        categoryName: categoryName.trim(),
        categoryType,
        description,
        status,
    });
};


// GET ALL CATEGORIES
export const getAllCategories = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    page = Number(page);
    limit = Number(limit);

    if (page < 1) page = 1;

    if (limit < 1) limit = 10;

    return await categoryRepository.getAll(
        page,
        limit,
        search,
        status
    );
};


// GET CATEGORY BY ID
export const getCategoryById = async (
    id: string
) => {

    const category = await categoryRepository.findById(id);

    if (!category) {
        throw new ValidationError("Category not found");
    }

    return category;
};


// UPDATE CATEGORY
export const updateCategory = async (
    id: string,
    payload: {
        categoryName?: string;
        categoryType?: "PRODUCT" | "SERVICE";
        description?: string;
        status?: boolean;
    }
) => {

    const category = await categoryRepository.findById(id);

    if (!category) {
        throw new ValidationError("Category not found");
    }

    if (payload.categoryName) {

        const existingCategory =
            await categoryRepository.findByName(
                payload.categoryName
            );

        if (
            existingCategory &&
            existingCategory.id !== id
        ) {
            throw new ValidationError(
                "Category already exists"
            );
        }
    }

    return await categoryRepository.update(id, {
        ...payload,
        categoryName: payload.categoryName?.trim(),
    });
};


// DELETE CATEGORY
export const deleteCategory = async (
    id: string
) => {

    const category = await categoryRepository.findById(id);

    if (!category) {
        throw new ValidationError("Category not found");
    }

    return await categoryRepository.softDelete(id);
};


// RESTORE CATEGORY
export const restoreCategory = async (
    id: string
) => {

    const category = await categoryRepository.findById(id);

    if (category) {
        throw new ValidationError(
            "Category is already active"
        );
    }

    return await categoryRepository.restore(id);
};