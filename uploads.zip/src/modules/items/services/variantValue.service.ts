import * as variantValueRepository from "../repository/variantValue.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

// =====================================================
// CREATE
// =====================================================

export const createVariantValue = async (payload: {
    variantTypeId: string;
    value: string;
    shortName?: string;
    displayOrder?: number;
    status?: boolean;
}) => {

    const {
        variantTypeId,
        value,
        shortName,
        displayOrder,
        status = true,
    } = payload;

    if (!variantTypeId) {
        throw new ValidationError("Variant Type is required.");
    }

    if (!value?.trim()) {
        throw new ValidationError("Variant Value is required.");
    }

    // Validate Variant Type
    const variantType =
        await variantValueRepository.findVariantType(
            variantTypeId
        );

    if (!variantType) {
        throw new ValidationError(
            "Variant Type not found."
        );
    }

    // Duplicate Check
    const existing =
        await variantValueRepository.findByValue(
            variantTypeId,
            value.trim()
        );

    if (existing) {

        // Reactivate / Restore inactive or deleted value
        if (
            existing.status === false ||
            existing.deletedAt !== null
        ) {

            return await variantValueRepository.update(
                existing.id,
                {
                    shortName: shortName?.trim(),
                    displayOrder,
                    status: true,
                    deletedAt: null,
                }
            );
        }

        // Already active
        throw new ValidationError(
            "Variant Value already exists for this Variant Type."
        );
    }

    return await variantValueRepository.create({

        value: value.trim(),

        shortName: shortName?.trim(),

        displayOrder,

        status,

        variantType: {
            connect: {
                id: variantTypeId,
            },
        },

    });
};

export const getAllVariantValues = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    page = Number(page);
    limit = Number(limit);

    if (page < 1) {
        page = 1;
    }

    if (limit < 1) {
        limit = 10;
    }

    return await variantValueRepository.getAll(
        page,
        limit,
        search,
        status
    );
};

export const getVariantValueById = async (
    id: string
) => {

    const variantValue =
        await variantValueRepository.findById(id);

    if (!variantValue) {
        throw new ValidationError(
            "Variant Value not found."
        );
    }

    return variantValue;
};

export const updateVariantValue = async (
    id: string,
    payload: {
        variantTypeId?: string;
        value?: string;
        shortName?: string;
        displayOrder?: number;
        status?: boolean;
    }
) => {

    const variantValue =
        await variantValueRepository.findById(id);

    if (!variantValue) {
        throw new ValidationError(
            "Variant Value not found."
        );
    }

    const variantTypeId =
        payload.variantTypeId ??
        variantValue.variantTypeId;

    // Validate new Variant Type
    if (payload.variantTypeId) {

        const variantType =
            await variantValueRepository.findVariantType(
                payload.variantTypeId
            );

        if (!variantType) {
            throw new ValidationError(
                "Variant Type not found."
            );
        }
    }

    // Duplicate value check
    if (payload.value) {

        const existing =
            await variantValueRepository.findByValue(
                variantTypeId,
                payload.value.trim()
            );

        if (
            existing &&
            existing.id !== id
        ) {

            throw new ValidationError(
                "Variant Value already exists."
            );
        }
    }

    return await variantValueRepository.update(
        id,
        {

            ...(payload.value !== undefined && {
                value: payload.value.trim(),
            }),

            ...(payload.shortName !== undefined && {
                shortName: payload.shortName.trim(),
            }),

            ...(payload.displayOrder !== undefined && {
                displayOrder: payload.displayOrder,
            }),

            ...(payload.status !== undefined && {
                status: payload.status,
            }),

            ...(payload.variantTypeId && {
                variantType: {
                    connect: {
                        id: payload.variantTypeId,
                    },
                },
            }),

        }
    );
};

export const deleteVariantValue = async (
    id: string
) => {

    const variantValue =
        await variantValueRepository.findById(id);

    if (!variantValue) {
        throw new ValidationError(
            "Variant Value not found."
        );
    }

    return await variantValueRepository.softDelete(
        id
    );
};

export const restoreVariantValue = async (
    id: string
) => {

    const variantValue =
        await variantValueRepository.findById(id);

    if (variantValue) {
        throw new ValidationError(
            "Variant Value is already active."
        );
    }

    return await variantValueRepository.restore(
        id
    );
};