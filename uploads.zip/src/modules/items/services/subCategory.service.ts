import * as subCategoryRepository from "../repository/subCategory.repository";
import * as categoryRepository from "../repository/category.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

export const createSubCategory = async (payload: {
    categoryId: string;
    subCategoryName: string;
    catgoryType: string;
    description?: string;
    status?: boolean;
}) => {

    const {
        categoryId,
        subCategoryName,
        catgoryType,
        description,
        status = true,
    } = payload;


    if (!categoryId) {
        throw new ValidationError(
            "Category is required."
        );
    }


    if (!subCategoryName?.trim()) {
        throw new ValidationError(
            "Sub Category name is required."
        );
    }

    const category =
        await categoryRepository.findById(
            categoryId
        );


    if (!category) {
        throw new ValidationError(
            "Category not found."
        );
    }


    const existingSubCategory =
        await subCategoryRepository.findByName(
            categoryId,
            subCategoryName.trim()
        );

    if (existingSubCategory) {

        if (
            existingSubCategory.status === false ||
            existingSubCategory.deletedAt !== null
        ) {

            return await subCategoryRepository.update(
                existingSubCategory.id,
                {
                    description,
                    status: true,
                    deletedAt: null,
                }
            );
        }


        throw new ValidationError(
            "Sub Category already exists in this Category."
        );
    }

    return await subCategoryRepository.create({

        subCategoryName:
            subCategoryName.trim(),

        // catgoryType,

        description,

        status,

        category: {
            connect: {
                id: categoryId,
            },
        },

    });
};

export const getAllSubCategories = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    page = Number(page);
    limit = Number(limit);


    if (page < 1) {
        page = 1;
    }


    if (limit < 1) {
        limit = 10;
    }


    return await subCategoryRepository.getAll(
        page,
        limit,
        search,
        status
    );
};


export const getSubCategoryById = async (
    id: string
) => {

    const subCategory =
        await subCategoryRepository.findById(
            id
        );


    if (!subCategory) {
        throw new ValidationError(
            "Sub Category not found."
        );
    }


    return subCategory;
};


export const updateSubCategory = async (
    id: string,
    payload: {
        categoryId?: string;
        subCategoryName?: string;
        catgoryType: string;
        description?: string;
        status?: boolean;
    }
) => {

    const subCategory =
        await subCategoryRepository.findById(
            id
        );


    if (!subCategory) {
        throw new ValidationError(
            "Sub Category not found."
        );
    }

    let categoryId =
        subCategory.categoryId;


    if (payload.categoryId) {

        const category =
            await categoryRepository.findById(
                payload.categoryId
            );


        if (!category) {
            throw new ValidationError(
                "Category not found."
            );
        }


        categoryId =
            payload.categoryId;
    }


    if (payload.subCategoryName) {

        const existing =
            await subCategoryRepository.findByName(
                categoryId,
                payload.subCategoryName.trim()
            );


        if (
            existing &&
            existing.id !== id
        ) {

            throw new ValidationError(
                "Sub Category already exists in this Category."
            );
        }
    }


    return await subCategoryRepository.update(
        id,
        {

            ...(payload.subCategoryName !== undefined && {
                subCategoryName:
                    payload.subCategoryName.trim(),
            }),

            ...(payload.description !== undefined && {
                description:
                    payload.description,
            }),

            ...(payload.status !== undefined && {
                status:
                    payload.status,
            }),

            ...(payload.categoryId && {
                category: {
                    connect: {
                        id: payload.categoryId,
                    },
                },
            }),

        }
    );
};


export const deleteSubCategory = async (
    id: string
) => {

    const subCategory =
        await subCategoryRepository.findById(
            id
        );


    if (!subCategory) {
        throw new ValidationError(
            "Sub Category not found."
        );
    }


    return await subCategoryRepository.softDelete(
        id
    );
};


export const restoreSubCategory = async (
    id: string
) => {

    const subCategory =
        await subCategoryRepository.findById(
            id
        );


    if (subCategory) {

        throw new ValidationError(
            "Sub Category is already active."
        );
    }


    return await subCategoryRepository.restore(
        id
    );
};


export const getByCategory = async (
    categoryId: string
) => {

 
    const category =
        await categoryRepository.findById(
            categoryId
        );


    if (!category) {
        throw new ValidationError(
            "Category not found."
        );
    }

    return await subCategoryRepository.getByCategoryId(
        categoryId
    );
};