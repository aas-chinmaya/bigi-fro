import * as unitRepository from "../repository/unit.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

export const createUnit = async (
    payload: {
        unitName: string;
        shortName: string;
        unitType:
            | "WEIGHT"
            | "LENGTH"
            | "VOLUME"
            | "COUNT"
            | "AREA"
            | "TIME"
            | "PACKAGING"
            | "CUSTOM";
        description?: string;
        status?: boolean;
    }
) => {

    const {
        unitName,
        shortName,
        unitType,
        description,
        status = true,
    } = payload;

    if (!unitName?.trim()) {

        throw new ValidationError(
            "Unit name is required."
        );

    }

    if (!shortName?.trim()) {

        throw new ValidationError(
            "Short name is required."
        );

    }

    if (!unitType) {

        throw new ValidationError(
            "Unit type is required."
        );

    }

    const existingName =
        await unitRepository.findByName(
            unitName.trim()
        );


    if (existingName) {

        // Unit exists but is inactive or soft deleted

        if (
            existingName.status === false ||
            existingName.deletedAt !== null
        ) {

            return await unitRepository.update(

                existingName.id,

                {
                    description,
                    status: true,
                    deletedAt: null,
                }

            );

        }


        // Unit already exists and is active

        throw new ValidationError(
            "Unit name already exists and is active."
        );

    }


    const existingShortName =
        await unitRepository.findByShortName(
            shortName.trim()
        );


    if (existingShortName) {

        // Unit exists but is inactive or soft deleted

        if (
            existingShortName.status === false ||
            existingShortName.deletedAt !== null
        ) {

            return await unitRepository.update(

                existingShortName.id,

                {
                    description,
                    status: true,
                    deletedAt: null,
                }

            );

        }


        // Unit already exists and is active

        throw new ValidationError(
            "Short name already exists and is active."
        );

    }

    return await unitRepository.create({

        unitName:
            unitName.trim(),

        shortName:
            shortName.trim(),

        unitType,

        description,

        status,

    });

};

export const getAllUnits = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    page = Number(page);

    limit = Number(limit);


    if (page < 1) {

        page = 1;

    }


    if (limit < 1) {

        limit = 10;

    }


    return await unitRepository.getAll(

        page,

        limit,

        search,

        status

    );

};


export const getUnitById = async (
    id: string
) => {

    const unit =
        await unitRepository.findById(
            id
        );


    if (!unit) {

        throw new ValidationError(
            "Unit not found."
        );

    }


    return unit;

};

export const updateUnit = async (
    id: string,
    payload: {
        unitName?: string;
        shortName?: string;
        unitType?:
            | "WEIGHT"
            | "LENGTH"
            | "VOLUME"
            | "COUNT"
            | "AREA"
            | "TIME"
            | "PACKAGING"
            | "CUSTOM";
        description?: string;
        status?: boolean;
    }
) => {

    const unit =
        await unitRepository.findById(
            id
        );


    if (!unit) {

        throw new ValidationError(
            "Unit not found."
        );

    }

    if (payload.unitName) {

        const existingName =
            await unitRepository.findByName(
                payload.unitName.trim()
            );


        if (
            existingName &&
            existingName.id !== id
        ) {

            throw new ValidationError(
                "Unit name already exists."
            );

        }

    }


    if (payload.shortName) {

        const existingShortName =
            await unitRepository.findByShortName(
                payload.shortName.trim()
            );


        if (
            existingShortName &&
            existingShortName.id !== id
        ) {

            throw new ValidationError(
                "Short name already exists."
            );

        }

    }

    return await unitRepository.update(

        id,

        {

            ...(payload.unitName !== undefined && {
                unitName:
                    payload.unitName.trim(),
            }),

            ...(payload.shortName !== undefined && {
                shortName:
                    payload.shortName.trim(),
            }),

            ...(payload.unitType !== undefined && {
                unitType:
                    payload.unitType,
            }),

            ...(payload.description !== undefined && {
                description:
                    payload.description,
            }),

            ...(payload.status !== undefined && {
                status:
                    payload.status,
            }),

        }

    );

};

export const deleteUnit = async (
    id: string
) => {

    const unit =
        await unitRepository.findById(
            id
        );


    if (!unit) {

        throw new ValidationError(
            "Unit not found."
        );

    }


    return await unitRepository.softDelete(
        id
    );

};

export const restoreUnit = async (
    id: string
) => {

    const unit =
        await unitRepository.findById(
            id
        );


    if (unit) {

        throw new ValidationError(
            "Unit is already active."
        );

    }
    return await unitRepository.restore(
        id
    );

};