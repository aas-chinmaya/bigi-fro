import * as brandRepository from "../repository/brand.repository";
import ValidationError from "../../../common/exceptions/ValidationError";


export const createBrand = async (
    payload: {
        brandName: string;
        description?: string;
        status?: boolean;
    }
) => {

    const {
        brandName,
        description,
        status = true,
    } = payload;

    if (!brandName?.trim()) {
        throw new ValidationError("Brand name is required.");
    }

    const existingBrand = await brandRepository.findByName(
        brandName.trim()
    );

    // if (existingBrand) {
    //     throw new ValidationError("Brand already exists.");
    // }

    if (existingBrand) {

        // Brand exists but is inactive or soft deleted
        if (
            existingBrand.status === false ||
            existingBrand.deletedAt !== null
        ) {
            return await brandRepository.update(
                existingBrand.id,
                {
                    description,
                    status: true,
                    deletedAt: null,
                }
            );
        }

        // Brand already exists and is active
        throw new ValidationError(
            "Brand already exists and is active."
        );
    }

    return await brandRepository.create({
        brandName: brandName.trim(),
        description,
        status,
    });
};


// GET ALL BRANDS
export const getAllBrands = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    page = Number(page);
    limit = Number(limit);

    if (page < 1) page = 1;
    if (limit < 1) limit = 10;

    return await brandRepository.getAll(
        page,
        limit,
        search,
        status
    );
};


// GET BRAND BY ID
export const getBrandById = async (
    id: string
) => {

    const brand = await brandRepository.findById(id);

    if (!brand) {
        throw new ValidationError("Brand not found.");
    }

    return brand;
};


// UPDATE BRAND
export const updateBrand = async (
    id: string,
    payload: {
        brandName?: string;
        description?: string;
        status?: boolean;
    }
) => {

    const brand = await brandRepository.findById(id);

    if (!brand) {
        throw new ValidationError("Brand not found.");
    }

    if (payload.brandName) {

        const existingBrand = await brandRepository.findByName(
            payload.brandName.trim()
        );

        if (
            existingBrand &&
            existingBrand.id !== id
        ) {
            throw new ValidationError("Brand already exists.");
        }
    }

    return await brandRepository.update(id, {
        brandName: payload.brandName?.trim(),
        description: payload.description,
        status: payload.status,
    });
};


// DELETE BRAND
export const deleteBrand = async (
    id: string
) => {

    const brand = await brandRepository.findById(id);

    if (!brand) {
        throw new ValidationError("Brand not found.");
    }

    return await brandRepository.softDelete(id);
};


// RESTORE BRAND
export const restoreBrand = async (
    id: string
) => {

    const brand = await brandRepository.findById(id);

    if (brand) {
        throw new ValidationError("Brand is already active.");
    }

    return await brandRepository.restore(id);
};
