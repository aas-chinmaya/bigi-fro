import * as taxRepository from "../repository/tax.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

export const createTax = async (payload: {
    hsnCode?: string;
    sacCode?: string;
    gstRate: number;
    cgst?: number;
    sgst?: number;
    igst?: number;
    ugst?: number;
    cess?: number;
    effectiveFrom?: Date;
    effectiveTo?: Date;
    status?: boolean;
}) => {

    const {
        hsnCode,
        sacCode,
        gstRate,
        cgst,
        sgst,
        igst,
        ugst,
        cess,
        effectiveFrom,
        effectiveTo,
        status = true,
    } = payload;

    if (
        !hsnCode?.trim() &&
        !sacCode?.trim()
    ) {

        throw new ValidationError(
            "Either HSN Code or SAC Code is required."
        );

    }
    if (
        gstRate === undefined ||
        gstRate === null
    ) {

        throw new ValidationError(
            "GST Rate is required."
        );

    }
    if (hsnCode) {

        const existingHSN =
            await taxRepository.findByHsnCode(
                hsnCode.trim()
            );


        if (existingHSN) {

            throw new ValidationError(
                "HSN Code already exists."
            );

        }

    }

    if (sacCode) {

        const existingSAC =
            await taxRepository.findBySacCode(
                sacCode.trim()
            );


        if (existingSAC) {

            throw new ValidationError(
                "SAC Code already exists."
            );

        }

    }

    return await taxRepository.create({

        hsnCode:
            hsnCode?.trim(),

        sacCode:
            sacCode?.trim(),

        gstRate,

        cgst,

        sgst,

        igst,

        ugst,

        cess,

        effectiveFrom:
            effectiveFrom
                ? new Date(effectiveFrom)
                : undefined,

        effectiveTo:
            effectiveTo
                ? new Date(effectiveTo)
                : undefined,

        status,

    });

};

export const getAllTaxes = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    page = Number(page);

    limit = Number(limit);

    if (page < 1) {

        page = 1;

    }
    if (limit < 1) {

        limit = 10;

    }
    return await taxRepository.getAll(

        page,
        limit,
        search,
        status

    );

};
export const getTaxById = async (
    id: string
) => {

    const tax =
        await taxRepository.findById(
            id
        );

    if (!tax) {

        throw new ValidationError(
            "Tax record not found."
        );

    }
    return tax;

};

export const updateTax = async (
    id: string,
    payload: {
        hsnCode?: string;
        sacCode?: string;
        gstRate?: number;
        cgst?: number;
        sgst?: number;
        igst?: number;
        ugst?: number;
        cess?: number;
        effectiveFrom?: Date;
        effectiveTo?: Date;
        status?: boolean;
    }
) => {

    const tax =
        await taxRepository.findById(
            id
        );


    if (!tax) {

        throw new ValidationError(
            "Tax record not found."
        );

    }

    if (payload.hsnCode) {

        const existingHSN =
            await taxRepository.findByHsnCode(
                payload.hsnCode.trim()
            );


        if (
            existingHSN &&
            existingHSN.id !== id
        ) {

            throw new ValidationError(
                "HSN Code already exists."
            );

        }

    }

    if (payload.sacCode) {

        const existingSAC =
            await taxRepository.findBySacCode(
                payload.sacCode.trim()
            );


        if (
            existingSAC &&
            existingSAC.id !== id
        ) {

            throw new ValidationError(
                "SAC Code already exists."
            );

        }

    }

    return await taxRepository.update(

        id,

        {

            ...(payload.hsnCode !== undefined && {
                hsnCode:
                    payload.hsnCode.trim(),
            }),

            ...(payload.sacCode !== undefined && {
                sacCode:
                    payload.sacCode.trim(),
            }),

            ...(payload.gstRate !== undefined && {
                gstRate:
                    payload.gstRate,
            }),

            ...(payload.cgst !== undefined && {
                cgst:
                    payload.cgst,
            }),

            ...(payload.sgst !== undefined && {
                sgst:
                    payload.sgst,
            }),

            ...(payload.igst !== undefined && {
                igst:
                    payload.igst,
            }),

            ...(payload.ugst !== undefined && {
                ugst:
                    payload.ugst,
            }),

            ...(payload.cess !== undefined && {
                cess:
                    payload.cess,
            }),

            ...(payload.effectiveFrom !== undefined && {
                effectiveFrom:
                    payload.effectiveFrom
                        ? new Date(
                            payload.effectiveFrom
                        )
                        : undefined,
            }),

            ...(payload.effectiveTo !== undefined && {
                effectiveTo:
                    payload.effectiveTo
                        ? new Date(
                            payload.effectiveTo
                        )
                        : undefined,
            }),

            ...(payload.status !== undefined && {
                status:
                    payload.status,
            }),

        }

    );

};

export const deleteTax = async (
    id: string
) => {

    const tax =
        await taxRepository.findById(
            id
        );
         if (!tax) {
            throw new ValidationError(
            "Tax record not found."
        );
    }
    return await taxRepository.softDelete(
        id
    );

};

export const restoreTax = async (
    id: string
) => {

    const tax =
        await taxRepository.findById(
            id
        );


    if (tax) {

        throw new ValidationError(
            "Tax record is already active."
        );

    }


    return await taxRepository.restore(
        id
    );

};