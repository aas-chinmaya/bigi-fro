import * as serviceRepository from "../repository/service.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

// =====================================================
// CREATE SERVICE
// =====================================================

export const createService = async (payload: {
    serviceCode: string;
    serviceName: string;
    categoryId: string;
    subCategoryId: string;
    taxId: string;
    sacCode?: string;
    description?: string;
    serviceCharge: number;
    gstRate: number;
    status?: boolean;
}) => {

    const {
        serviceCode,
        serviceName,
        categoryId,
        subCategoryId,
        taxId,
        sacCode,
        description,
        serviceCharge,
        gstRate,
        status = true,
    } = payload;


    // Service Code validation
    if (!serviceCode?.trim()) {
        throw new ValidationError(
            "Service Code is required."
        );
    }


    // Service Name validation
    if (!serviceName?.trim()) {
        throw new ValidationError(
            "Service Name is required."
        );
    }


    // Category validation
    if (
        categoryId === undefined ||
        categoryId === null ||
        !categoryId.trim()
    ) {
        throw new ValidationError(
            "Category is required."
        );
    }


    // Sub Category validation
    if (
        subCategoryId === undefined ||
        subCategoryId === null ||
        !subCategoryId.trim()
    ) {
        throw new ValidationError(
            "Sub Category is required."
        );
    }


    // Tax validation
    if (
        taxId === undefined ||
        taxId === null ||
        !taxId.trim()
    ) {
        throw new ValidationError(
            "Tax is required."
        );
    }


    // Service Charge validation
    if (
        serviceCharge === undefined ||
        serviceCharge === null
    ) {
        throw new ValidationError(
            "Service Charge is required."
        );
    }


    if (serviceCharge < 0) {
        throw new ValidationError(
            "Service Charge cannot be negative."
        );
    }


    // GST Rate validation
    if (
        gstRate === undefined ||
        gstRate === null
    ) {
        throw new ValidationError(
            "GST Rate is required."
        );
    }


    if (gstRate < 0 || gstRate > 100) {
        throw new ValidationError(
            "GST Rate must be between 0 and 100."
        );
    }


    // Check duplicate service code
    const existingCode =
        await serviceRepository.findByServiceCode(
            serviceCode.trim()
        );

    if (existingCode) {
        throw new ValidationError(
            "Service Code already exists."
        );
    }


    // Check duplicate service name
    const existingName =
        await serviceRepository.findByServiceName(
            serviceName.trim()
        );

    if (existingName) {
        throw new ValidationError(
            "Service Name already exists."
        );
    }


    // Check duplicate SAC code
    if (sacCode?.trim()) {

        const existingSac =
            await serviceRepository.findBySacCode(
                sacCode.trim()
            );

        if (existingSac) {
            throw new ValidationError(
                "SAC Code already exists."
            );
        }
    }


    // Check category
    const category =
        await serviceRepository.findCategory(
            categoryId
        );

    if (!category) {
        throw new ValidationError(
            "Category not found."
        );
    }


    // Check sub category
    const subCategory =
        await serviceRepository.findSubCategory(
            subCategoryId
        );

    if (!subCategory) {
        throw new ValidationError(
            "Sub Category not found."
        );
    }


    // Check sub category belongs to category
    if (subCategory.categoryId !== categoryId) {
        throw new ValidationError(
            "Sub Category does not belong to selected Category."
        );
    }


    // Check tax
    const tax =
        await serviceRepository.findTax(
            taxId
        );

    if (!tax) {
        throw new ValidationError(
            "Tax not found."
        );
    }


    // Create service
    return await serviceRepository.create({

        serviceCode: serviceCode.trim(),

        serviceName: serviceName.trim(),

        category: {
            connect: {
                id: categoryId,
            },
        },

        subCategory: {
            connect: {
                id: subCategoryId,
            },
        },

        tax: {
            connect: {
                id: taxId,
            },
        },

        sacCode: sacCode?.trim(),

        description,

        serviceCharge,

        gstRate,

        status,
    });
};

export const getAllServices = async (
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
) => {

    return await serviceRepository.getAll(
        Number(page),
        Number(limit),
        search?.trim(),
        status
    );
};

export const getServiceById = async (
    id: string
) => {

    if (!id?.trim()) {
        throw new ValidationError(
            "Service ID is required."
        );
    }


    const service =
        await serviceRepository.findById(id);


    if (!service) {
        throw new ValidationError(
            "Service not found."
        );
    }


    return service;
};

export const updateService = async (
    id: string,
    payload: {
        serviceCode?: string;
        serviceName?: string;
        categoryId?: string;
        subCategoryId?: string;
        taxId?: string;
        sacCode?: string;
        description?: string;
        serviceCharge?: number;
        gstRate?: number;
        status?: boolean;
    }
) => {

    if (!id?.trim()) {
        throw new ValidationError(
            "Service ID is required."
        );
    }


    // Check service exists
    const service =
        await serviceRepository.findById(id);


    if (!service) {
        throw new ValidationError(
            "Service not found."
        );
    }


    // Service Code validation
    if (payload.serviceCode !== undefined) {

        if (!payload.serviceCode.trim()) {
            throw new ValidationError(
                "Service Code cannot be empty."
            );
        }


        const existingCode =
            await serviceRepository.findByServiceCode(
                payload.serviceCode.trim()
            );


        if (
            existingCode &&
            existingCode.id !== id
        ) {
            throw new ValidationError(
                "Service Code already exists."
            );
        }
    }


    // Service Name validation
    if (payload.serviceName !== undefined) {

        if (!payload.serviceName.trim()) {
            throw new ValidationError(
                "Service Name cannot be empty."
            );
        }


        const existingName =
            await serviceRepository.findByServiceName(
                payload.serviceName.trim()
            );


        if (
            existingName &&
            existingName.id !== id
        ) {
            throw new ValidationError(
                "Service Name already exists."
            );
        }
    }


    // SAC Code validation
    if (payload.sacCode?.trim()) {

        const existingSac =
            await serviceRepository.findBySacCode(
                payload.sacCode.trim()
            );


        if (
            existingSac &&
            existingSac.id !== id
        ) {
            throw new ValidationError(
                "SAC Code already exists."
            );
        }
    }


    // Category validation
    if (payload.categoryId !== undefined) {

        if (!payload.categoryId.trim()) {
            throw new ValidationError(
                "Category is required."
            );
        }


        const category =
            await serviceRepository.findCategory(
                payload.categoryId
            );


        if (!category) {
            throw new ValidationError(
                "Category not found."
            );
        }
    }


    // Sub Category validation
    if (payload.subCategoryId !== undefined) {

        if (!payload.subCategoryId.trim()) {
            throw new ValidationError(
                "Sub Category is required."
            );
        }


        const subCategory =
            await serviceRepository.findSubCategory(
                payload.subCategoryId
            );


        if (!subCategory) {
            throw new ValidationError(
                "Sub Category not found."
            );
        }


        if (payload.categoryId !== undefined) {

            if (
                subCategory.categoryId !==
                payload.categoryId
            ) {
                throw new ValidationError(
                    "Sub Category does not belong to selected Category."
                );
            }

        } else {

            if (
                subCategory.categoryId !==
                service.categoryId
            ) {
                throw new ValidationError(
                    "Sub Category does not belong to selected Category."
                );
            }
        }
    }


    // Tax validation
    if (payload.taxId !== undefined) {

        if (!payload.taxId.trim()) {
            throw new ValidationError(
                "Tax is required."
            );
        }


        const tax =
            await serviceRepository.findTax(
                payload.taxId
            );


        if (!tax) {
            throw new ValidationError(
                "Tax not found."
            );
        }
    }


    // Service Charge validation
    if (payload.serviceCharge !== undefined) {

        if (payload.serviceCharge < 0) {
            throw new ValidationError(
                "Service Charge cannot be negative."
            );
        }
    }


    // GST Rate validation
    if (payload.gstRate !== undefined) {

        if (
            payload.gstRate < 0 ||
            payload.gstRate > 100
        ) {
            throw new ValidationError(
                "GST Rate must be between 0 and 100."
            );
        }
    }


    // Update service
    return await serviceRepository.update(
        id,
        {

            ...(payload.serviceCode !== undefined && {
                serviceCode:
                    payload.serviceCode.trim(),
            }),

            ...(payload.serviceName !== undefined && {
                serviceName:
                    payload.serviceName.trim(),
            }),

            ...(payload.sacCode !== undefined && {
                sacCode:
                    payload.sacCode.trim(),
            }),

            ...(payload.description !== undefined && {
                description:
                    payload.description,
            }),

            ...(payload.serviceCharge !== undefined && {
                serviceCharge:
                    payload.serviceCharge,
            }),

            ...(payload.gstRate !== undefined && {
                gstRate:
                    payload.gstRate,
            }),

            ...(payload.status !== undefined && {
                status:
                    payload.status,
            }),

            ...(payload.categoryId !== undefined && {
                category: {
                    connect: {
                        id: payload.categoryId,
                    },
                },
            }),

            ...(payload.subCategoryId !== undefined && {
                subCategory: {
                    connect: {
                        id: payload.subCategoryId,
                    },
                },
            }),

            ...(payload.taxId !== undefined && {
                tax: {
                    connect: {
                        id: payload.taxId,
                    },
                },
            }),
        }
    );
};

export const deleteService = async (
    id: string
) => {

    if (!id?.trim()) {
        throw new ValidationError(
            "Service ID is required."
        );
    }


    const service =
        await serviceRepository.findById(id);


    if (!service) {
        throw new ValidationError(
            "Service not found."
        );
    }


    return await serviceRepository.softDelete(id);
};

export const restoreService = async (
    id: string
) => {

    if (!id?.trim()) {
        throw new ValidationError(
            "Service ID is required."
        );
    }


    const service =
        await serviceRepository.findById(id);


    if (!service) {

        const restored =
            await serviceRepository.restore(id);


        if (!restored) {
            throw new ValidationError(
                "Service not found."
            );
        }


        return restored;
    }


    throw new ValidationError(
        "Service is already active."
    );
};