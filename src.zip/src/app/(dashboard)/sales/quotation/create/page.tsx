"use client";

import { useRouter } from "next/navigation";

import QuotationForm from "@/modules/sales/quotation/components/quotation-form";

// Import your actual create mutation/API here.
import {
  useCreateQuotationMutation,
} from "@/modules/sales/quotation/api/quotation.api";

export default function CreateQuotationPage() {
  const router = useRouter();

  const [
    createQuotation,
    { isLoading },
  ] = useCreateQuotationMutation();

  const handleSubmit = async (values: any) => {
    try {
      await createQuotation(values).unwrap();

      router.push("/sales/quotation");
    } catch (error) {
      console.error(
        "Failed to create quotation:",
        error,
      );
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          Create Quotation
        </h1>

        <p className="text-sm text-muted-foreground">
          Create a new quotation for your customer.
        </p>
      </div>

      <QuotationForm
        mode="create"
        loading={isLoading}
        onSubmit={handleSubmit}
      />
    </div>
  );
}