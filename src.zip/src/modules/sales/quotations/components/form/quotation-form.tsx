"use client";

import { useEffect, useMemo } from "react";
import { useForm, FormProvider, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { notify } from "@/lib/toast";

import { quotationCreateSchema } from "../../schemas/quotation.schema";
import {
  useCreateQuotationMutation,
  useUpdateQuotationMutation,
} from "../../api/quotation.api";

import type {
  QuotationFormProps,
  QuotationFormValues,
} from "../../types/quotation-form.types";
import {
  getDefaultQuotationValues,
  mapQuotationToFormValues,
  getSessionFormDefaults,
  sanitizeCreatePayload,
  sanitizeUpdatePayload,
  applyTotalsToValues,
  resolveTaxType,
  resolveFinancialYear,
} from "../../utils/quotation-form.utils";

import { useCurrentSession } from "@/modules/sales/shared/hooks/use-current-session";

import { QuotationCustomerFields } from "./quotation-customer-fields";
import { QuotationIssuerFields } from "./quotation-issuer-fields";
import { QuotationItemsSection } from "./quotation-items-section";
import { QuotationSummary } from "./quotation-summary";
import { QuotationFormActions } from "./quotation-form-actions";

export function QuotationForm({
  mode,
  quotation,
  onSuccess,
}: QuotationFormProps) {
  const [createQuotation, { isLoading: isCreating }] =
    useCreateQuotationMutation();
  const [updateQuotation, { isLoading: isUpdating }] =
    useUpdateQuotationMutation();

  const { data: session } = useCurrentSession();
  const isSubmitting = isCreating || isUpdating;

  const isFinalized =
    mode === "edit" &&
    (quotation?.quotationStatus === "FINALIZED" ||
      quotation?.quotationStatus === "ACCEPTED" ||
      quotation?.quotationStatus === "CANCELLED");


  const sessionDefaults = useMemo(
    () => getSessionFormDefaults(session),
    [session],
  );

  const form = useForm<QuotationFormValues>({
    resolver: zodResolver(quotationCreateSchema),
    defaultValues:
      mode === "edit" && quotation
        ? mapQuotationToFormValues(
            quotation,
            session?.business?.id,
            session?.user?.id,
          )
        : {
            ...getDefaultQuotationValues(
              session?.business?.id ?? "",
              session?.user?.id ?? "",
            ),
            ...sessionDefaults,
          },
    mode: "onChange",
  });

  const { reset, setValue, control } = form;

  const businessStateCode = useWatch({ control, name: "businessStateCode" });
  const placeOfSupplyCode = useWatch({ control, name: "placeOfSupplyCode" });
  const items = useWatch({ control, name: "items" });
  const quotationDate = useWatch({ control, name: "quotationDate" });

  // Deep snapshot so nested qty/price/discount always trigger
  const itemsKey = useMemo(() => JSON.stringify(items ?? []), [items]);

  useEffect(() => {
    const taxType = resolveTaxType(businessStateCode, placeOfSupplyCode);
    setValue("taxType", taxType, { shouldDirty: false });
  }, [businessStateCode, placeOfSupplyCode, setValue]);

  useEffect(() => {
    setValue(
      "financialYear",
      resolveFinancialYear(quotationDate),
      { shouldDirty: false },
    );
  }, [quotationDate, setValue]);

  // Instant totals — any line change / tax type change
  useEffect(() => {
    const current = form.getValues();
    const withTotals = applyTotalsToValues(current);

    setValue("totalItems", withTotals.totalItems, { shouldDirty: false });
    setValue("totalQuantity", withTotals.totalQuantity, { shouldDirty: false });
    setValue("taxableAmount", withTotals.taxableAmount, { shouldDirty: false });
    setValue("discountAmount", withTotals.discountAmount, {
      shouldDirty: false,
    });
    setValue("cgstAmount", withTotals.cgstAmount, { shouldDirty: false });
    setValue("sgstAmount", withTotals.sgstAmount, { shouldDirty: false });
    setValue("igstAmount", withTotals.igstAmount, { shouldDirty: false });
    setValue("cessAmount", withTotals.cessAmount, { shouldDirty: false });
    setValue("roundOffAmount", withTotals.roundOffAmount, {
      shouldDirty: false,
    });
    setValue("grandTotal", withTotals.grandTotal, { shouldDirty: false });

    withTotals.items.forEach((line, i) => {
      setValue(`items.${i}.taxAmount`, line.taxAmount, { shouldDirty: false });
      setValue(`items.${i}.amount`, line.amount, { shouldDirty: false });
      setValue(`items.${i}.total`, line.total, { shouldDirty: false });
      setValue(`items.${i}.cgstRate`, line.cgstRate, { shouldDirty: false });
      setValue(`items.${i}.cgstAmount`, line.cgstAmount, {
        shouldDirty: false,
      });
      setValue(`items.${i}.sgstRate`, line.sgstRate, { shouldDirty: false });
      setValue(`items.${i}.sgstAmount`, line.sgstAmount, {
        shouldDirty: false,
      });
      setValue(`items.${i}.igstRate`, line.igstRate, { shouldDirty: false });
      setValue(`items.${i}.igstAmount`, line.igstAmount, {
        shouldDirty: false,
      });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsKey, businessStateCode, placeOfSupplyCode, setValue]);

  useEffect(() => {
    if (mode === "edit" && quotation) {
      reset(
        mapQuotationToFormValues(
          quotation,
          session?.business?.id,
          session?.user?.id,
        ),
      );
    }
  }, [mode, quotation, reset, session?.business?.id, session?.user?.id]);

  useEffect(() => {
    if (mode !== "create" || !session) return;
    const current = form.getValues();
    if (!current.businessName && session.business?.name) {
      reset({
        ...getDefaultQuotationValues(
          session.business?.id ?? "",
          session.user?.id ?? "",
        ),
        ...getSessionFormDefaults(session),
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, session?.business?.id, session?.user?.id]);

  const submitWithStatus = async (status: "DRAFT" | "FINALIZED") => {
    const values = form.getValues();
    // validate first
    const valid = await form.trigger();
    if (!valid) {
      notify.error("Please fix the highlighted fields");
      return;
    }

    if (status === "FINALIZED") {
      const terms = (values.termsAndConditions || "").replace(/<[^>]+>/g, "").trim();
      const sig = values.signature;
      if (!terms) {
        notify.error("Terms & conditions are required to finalize");
        return;
      }
      if (!sig) {
        notify.error("Signature is required to finalize");
        return;
      }
    }

    try {
      const currentUserId = session?.user?.id ?? values.createdBy ?? "";
      const withStatus = {
        ...values,
        status,
        financialYear: resolveFinancialYear(values.quotationDate),
      };

      if (mode === "create") {
        const payload = sanitizeCreatePayload({
          ...withStatus,
          tenantId: values.tenantId || session?.business?.id || "",
          createdBy: values.createdBy || currentUserId,
        });
        const res = await createQuotation(payload as any).unwrap();
        notify.success(
          res.message ||
            (status === "FINALIZED"
              ? "Quotation finalized"
              : "Draft saved"),
        );
        onSuccess?.(res.data);
      } else if (mode === "edit" && quotation?.id) {
        if (isFinalized) {
          notify.error("Finalized quotations cannot be edited");
          return;
        }
        const payload = sanitizeUpdatePayload(withStatus as any, currentUserId);
        const res = await updateQuotation({
          id: quotation.id,
          data: { ...payload, status } as any,
        }).unwrap();
        notify.success(
          res.message ||
            (status === "FINALIZED"
              ? "Quotation finalized"
              : "Draft updated"),
        );
        onSuccess?.(res.data);
      }
    } catch (err: any) {
      const apiMessage =
        err?.data?.message ||
        err?.error ||
        (typeof err?.data === "string" ? err.data : null) ||
        err?.message ||
        "Something went wrong";
      notify.error(
        typeof apiMessage === "string"
          ? apiMessage
          : JSON.stringify(apiMessage),
      );
    }
  };

  return (
    <FormProvider {...form}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
        }}
        className="w-full space-y-4 pb-10"
        noValidate
      >
      {isFinalized && (
        <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800">
          This quotation is finalized — editing is disabled.
        </div>
      )}
      <fieldset disabled={!!isFinalized} className="min-w-0 space-y-4">
        {/* Same row: Customer | Issuer */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <section className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5">
            <h2 className="mb-4 text-sm font-semibold text-slate-800">
              Customer information
            </h2>
            <QuotationCustomerFields />
          </section>

          <section className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5">
            <h2 className="mb-4 text-sm font-semibold text-slate-800">
              Issuer details
            </h2>
            <QuotationIssuerFields />
          </section>
        </div>

        {/* Items + payment + notes + summary + signature */}
        <section className="space-y-6 rounded-xl border border-slate-200 bg-white p-4 sm:p-5">
          <QuotationItemsSection />
          <div className="border-t border-slate-100 pt-5">
            <QuotationSummary />
          </div>
        </section>

        </fieldset>
        <QuotationFormActions
          mode={mode}
          isSubmitting={isSubmitting}
          readOnly={!!isFinalized}
          onSubmitIntent={submitWithStatus}
        />
      </form>
    </FormProvider>
  );
}

export default QuotationForm;
