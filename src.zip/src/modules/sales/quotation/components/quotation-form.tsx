"use client";

import { useEffect, useMemo } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  ArrowLeft,
  Plus,
  Trash2,
} from "lucide-react";
import { useRouter } from "next/navigation";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

import {
  quotationSchema,
  type QuotationFormValues,
} from "../schema/quotation.schema";

export interface QuotationFormItem {
  productId: string;
  productName: string;
  description?: string | null;
  quantity: number | string;
  rate: number | string;
  discount: number | string;
  tax: number | string;
}

export interface QuotationFormData {
  id?: string;

  customerId?: string | null;
  customerName?: string | null;

  quotationNumber?: string | null;
  quotationDate?: string | null;
  validUntil?: string | null;

  items?: QuotationFormItem[];

  notes?: string | null;
  termsAndConditions?: string | null;
}

interface QuotationFormProps {
  mode: "create" | "edit";

  quotation?: QuotationFormData | null;

  loading?: boolean;

  onSubmit: (
    values: QuotationFormValues,
  ) => Promise<void>;

  onCancel?: () => void;
}

const createDefaultValues: QuotationFormValues = {
  customerId: "",
  customerName: "",
  quotationNumber: "",
  quotationDate: new Date()
    .toISOString()
    .slice(0, 10),
  validUntil: "",
  items: [
    {
      productId: "",
      productName: "",
      description: "",
      quantity: 1,
      rate: 0,
      discount: 0,
      tax: 0,
    },
  ],
  notes: "",
  termsAndConditions: "",
};

function formatNumber(value: number) {
  return value.toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export default function QuotationForm({
  mode,
  quotation,
  loading = false,
  onSubmit,
  onCancel,
}: QuotationFormProps) {
  const router = useRouter();

  const isEdit = mode === "edit";

  const form = useForm<QuotationFormValues>({
    resolver: zodResolver(quotationSchema),
    defaultValues: createDefaultValues,
  });

  const {
    fields,
    append,
    remove,
  } = useFieldArray({
    control: form.control,
    name: "items",
  });

  /*
   * Populate existing quotation when editing.
   */
  useEffect(() => {
    if (!isEdit || !quotation) {
      return;
    }

    form.reset({
      customerId: quotation.customerId ?? "",

      customerName:
        quotation.customerName ?? "",

      quotationNumber:
        quotation.quotationNumber ?? "",

      quotationDate:
        quotation.quotationDate
          ? quotation.quotationDate.slice(0, 10)
          : new Date()
              .toISOString()
              .slice(0, 10),

      validUntil:
        quotation.validUntil
          ? quotation.validUntil.slice(0, 10)
          : "",

      items:
        quotation.items?.length
          ? quotation.items.map((item) => ({
              productId: item.productId,
              productName: item.productName,
              description:
                item.description ?? "",
              quantity: Number(item.quantity),
              rate: Number(item.rate),
              discount: Number(item.discount),
              tax: Number(item.tax),
            }))
          : createDefaultValues.items,

      notes: quotation.notes ?? "",

      termsAndConditions:
        quotation.termsAndConditions ?? "",
    });
  }, [isEdit, quotation, form]);

  const watchedItems = form.watch("items");

  const totals = useMemo(() => {
    let subtotal = 0;
    let discount = 0;
    let tax = 0;

    watchedItems.forEach((item) => {
      const quantity = Number(item.quantity) || 0;
      const rate = Number(item.rate) || 0;
      const itemDiscount =
        Number(item.discount) || 0;
      const itemTax = Number(item.tax) || 0;

      subtotal += quantity * rate;
      discount += itemDiscount;
      tax += itemTax;
    });

    const total = subtotal - discount + tax;

    return {
      subtotal,
      discount,
      tax,
      total,
    };
  }, [watchedItems]);

  const handleCancel = () => {
    if (onCancel) {
      onCancel();
      return;
    }

    router.back();
  };

  const submit = async (
    values: QuotationFormValues,
  ) => {
    await onSubmit(values);
  };

  return (
    <form
      onSubmit={form.handleSubmit(submit)}
      className="space-y-6"
    >
      {/* ================================================== */}
      {/* CUSTOMER */}
      {/* ================================================== */}

      <section className="rounded-xl border bg-background">
        <div className="border-b px-5 py-4">
          <h2 className="font-semibold">
            Customer
          </h2>

          <p className="mt-1 text-sm text-muted-foreground">
            Select the customer for this quotation.
          </p>
        </div>

        <div className="grid gap-5 p-5 md:grid-cols-2">
          <div className="space-y-2">
            <label
              htmlFor="customerName"
              className="text-sm font-medium"
            >
              Customer
              <span className="ml-1 text-destructive">
                *
              </span>
            </label>

            <Input
              id="customerName"
              placeholder="Customer name"
              {...form.register("customerName")}
            />

            {form.formState.errors.customerName && (
              <p className="text-xs text-destructive">
                {
                  form.formState.errors.customerName
                    .message
                }
              </p>
            )}
          </div>

          <div className="space-y-2">
            <label
              htmlFor="customerId"
              className="text-sm font-medium"
            >
              Customer ID
              <span className="ml-1 text-destructive">
                *
              </span>
            </label>

            <Input
              id="customerId"
              placeholder="Customer ID"
              {...form.register("customerId")}
            />

            {form.formState.errors.customerId && (
              <p className="text-xs text-destructive">
                {
                  form.formState.errors.customerId
                    .message
                }
              </p>
            )}
          </div>
        </div>
      </section>

      {/* ================================================== */}
      {/* QUOTATION DETAILS */}
      {/* ================================================== */}

      <section className="rounded-xl border bg-background">
        <div className="border-b px-5 py-4">
          <h2 className="font-semibold">
            Quotation Details
          </h2>

          <p className="mt-1 text-sm text-muted-foreground">
            Basic information about the quotation.
          </p>
        </div>

        <div className="grid gap-5 p-5 md:grid-cols-3">
          <div className="space-y-2">
            <label
              htmlFor="quotationNumber"
              className="text-sm font-medium"
            >
              Quotation Number
            </label>

            <Input
              id="quotationNumber"
              placeholder="Auto generated"
              disabled
              {...form.register("quotationNumber")}
            />
          </div>

          <div className="space-y-2">
            <label
              htmlFor="quotationDate"
              className="text-sm font-medium"
            >
              Quotation Date
              <span className="ml-1 text-destructive">
                *
              </span>
            </label>

            <Input
              id="quotationDate"
              type="date"
              {...form.register("quotationDate")}
            />

            {form.formState.errors.quotationDate && (
              <p className="text-xs text-destructive">
                {
                  form.formState.errors.quotationDate
                    .message
                }
              </p>
            )}
          </div>

          <div className="space-y-2">
            <label
              htmlFor="validUntil"
              className="text-sm font-medium"
            >
              Valid Until
            </label>

            <Input
              id="validUntil"
              type="date"
              {...form.register("validUntil")}
            />
          </div>
        </div>
      </section>

      {/* ================================================== */}
      {/* ITEMS */}
      {/* ================================================== */}

      <section className="rounded-xl border bg-background">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <div>
            <h2 className="font-semibold">
              Items
            </h2>

            <p className="mt-1 text-sm text-muted-foreground">
              Add products or services to the quotation.
            </p>
          </div>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() =>
              append({
                productId: "",
                productName: "",
                description: "",
                quantity: 1,
                rate: 0,
                discount: 0,
                tax: 0,
              })
            }
          >
            <Plus className="mr-2 size-4" />
            Add Item
          </Button>
        </div>

        <div className="p-5">
          <div className="space-y-4">
            {fields.map((field, index) => {
              const itemErrors =
                form.formState.errors.items?.[index];

              return (
                <div
                  key={field.id}
                  className="rounded-xl border bg-muted/20 p-4"
                >
                  <div className="mb-4 flex items-center justify-between">
                    <div className="text-sm font-medium">
                      Item {index + 1}
                    </div>

                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      disabled={
                        fields.length === 1
                      }
                      onClick={() =>
                        remove(index)
                      }
                      aria-label={`Remove item ${
                        index + 1
                      }`}
                    >
                      <Trash2 className="size-4 text-destructive" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    {/* Product ID */}

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Product ID
                        <span className="ml-1 text-destructive">
                          *
                        </span>
                      </label>

                      <Input
                        placeholder="Product ID"
                        {...form.register(
                          `items.${index}.productId`,
                        )}
                      />

                      {itemErrors?.productId && (
                        <p className="text-xs text-destructive">
                          {
                            itemErrors.productId
                              .message
                          }
                        </p>
                      )}
                    </div>

                    {/* Product */}

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Product
                        <span className="ml-1 text-destructive">
                          *
                        </span>
                      </label>

                      <Input
                        placeholder="Product name"
                        {...form.register(
                          `items.${index}.productName`,
                        )}
                      />

                      {itemErrors?.productName && (
                        <p className="text-xs text-destructive">
                          {
                            itemErrors.productName
                              .message
                          }
                        </p>
                      )}
                    </div>

                    {/* Description */}

                    <div className="space-y-2 md:col-span-2">
                      <label className="text-sm font-medium">
                        Description
                      </label>

                      <Input
                        placeholder="Optional description"
                        {...form.register(
                          `items.${index}.description`,
                        )}
                      />
                    </div>

                    {/* Quantity */}

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Quantity
                      </label>

                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        {...form.register(
                          `items.${index}.quantity`,
                          {
                            valueAsNumber: true,
                          },
                        )}
                      />

                      {itemErrors?.quantity && (
                        <p className="text-xs text-destructive">
                          {
                            itemErrors.quantity
                              .message
                          }
                        </p>
                      )}
                    </div>

                    {/* Rate */}

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Rate
                      </label>

                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        {...form.register(
                          `items.${index}.rate`,
                          {
                            valueAsNumber: true,
                          },
                        )}
                      />

                      {itemErrors?.rate && (
                        <p className="text-xs text-destructive">
                          {
                            itemErrors.rate.message
                          }
                        </p>
                      )}
                    </div>

                    {/* Discount */}

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Discount
                      </label>

                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        {...form.register(
                          `items.${index}.discount`,
                          {
                            valueAsNumber: true,
                          },
                        )}
                      />
                    </div>

                    {/* Tax */}

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Tax
                      </label>

                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        {...form.register(
                          `items.${index}.tax`,
                          {
                            valueAsNumber: true,
                          },
                        )}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {form.formState.errors.items?.root
            ?.message && (
            <p className="mt-3 text-sm text-destructive">
              {
                form.formState.errors.items.root
                  .message
              }
            </p>
          )}
        </div>
      </section>

      {/* ================================================== */}
      {/* NOTES */}
      {/* ================================================== */}

      <section className="rounded-xl border bg-background">
        <div className="border-b px-5 py-4">
          <h2 className="font-semibold">
            Additional Information
          </h2>
        </div>

        <div className="grid gap-5 p-5 md:grid-cols-2">
          <div className="space-y-2">
            <label
              htmlFor="notes"
              className="text-sm font-medium"
            >
              Notes
            </label>

            <Textarea
              id="notes"
              rows={4}
              placeholder="Add notes for the customer..."
              {...form.register("notes")}
            />
          </div>

          <div className="space-y-2">
            <label
              htmlFor="termsAndConditions"
              className="text-sm font-medium"
            >
              Terms & Conditions
            </label>

            <Textarea
              id="termsAndConditions"
              rows={4}
              placeholder="Add quotation terms and conditions..."
              {...form.register(
                "termsAndConditions",
              )}
            />
          </div>
        </div>
      </section>

      {/* ================================================== */}
      {/* SUMMARY */}
      {/* ================================================== */}

      <section className="flex justify-end">
        <div className="w-full max-w-sm rounded-xl border bg-background p-5">
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">
                Subtotal
              </span>

              <span>
                ₹{" "}
                {formatNumber(
                  totals.subtotal,
                )}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-muted-foreground">
                Discount
              </span>

              <span>
                ₹{" "}
                {formatNumber(
                  totals.discount,
                )}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-muted-foreground">
                Tax
              </span>

              <span>
                ₹{" "}
                {formatNumber(totals.tax)}
              </span>
            </div>

            <div className="border-t pt-3">
              <div className="flex justify-between text-base font-semibold">
                <span>Grand Total</span>

                <span>
                  ₹{" "}
                  {formatNumber(
                    totals.total,
                  )}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================================================== */}
      {/* ACTIONS */}
      {/* ================================================== */}

      <div className="flex items-center justify-between border-t pt-5">
        <Button
          type="button"
          variant="ghost"
          onClick={handleCancel}
          disabled={loading}
        >
          <ArrowLeft className="mr-2 size-4" />
          Cancel
        </Button>

        <Button
          type="submit"
          disabled={loading}
          className="min-w-[150px]"
        >
          {loading
            ? "Saving..."
            : isEdit
              ? "Save Changes"
              : "Create Quotation"}
        </Button>
      </div>
    </form>
  );
}