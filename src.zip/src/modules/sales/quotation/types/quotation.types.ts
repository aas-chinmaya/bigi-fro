// ============================================================
// QUOTATION ENUMS
// ============================================================

export type QuotationStatus =
  | "DRAFT"
  | "SENT"
  | "ACCEPTED"
  | "REJECTED"
  | "EXPIRED"
  | "CANCELLED";

export type QuotationSource =
  | "MANUAL"
  | "ONLINE"
  | "POS"
  | "OTHER";

export type PaymentTerms =
  | "DUE_ON_RECEIPT"
  | "NET_7"
  | "NET_15"
  | "NET_30"
  | "NET_45"
  | "NET_60";

export type DiscountType =
  | "PERCENTAGE"
  | "FIXED";


// ============================================================
// CUSTOMER
// ============================================================

export interface QuotationCustomer {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  gstin?: string;
}


// ============================================================
// QUOTATION ITEM
// ============================================================

export interface QuotationItem {
  id?: string;

  productId?: string;
  productName?: string;
  description?: string;

  quantity: number;
  unit?: string;

  rate: number;

  discount?: number;
  discountType?: DiscountType;

  taxRate?: number;
  taxAmount?: number;

  amount?: number;
}


// ============================================================
// QUOTATION
// ============================================================

export interface Quotation {
  id: string;

  businessId?: string;
  branchId?: string;

  quotationNumber?: string;
  quotationDate: string;
  validUntil?: string;

  financialYear?: string;

  status: QuotationStatus;
  source?: QuotationSource;

  customerId: string;

  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
  customerGSTIN?: string;

  customer?: QuotationCustomer;

  items?: QuotationItem[];

  subtotal?: number;
  discount?: number;
  taxableAmount?: number;
  taxAmount?: number;
  roundOff?: number;

  totalAmount: number;

  paymentTerms?: PaymentTerms;

  notes?: string;
  termsAndConditions?: string;
  remarks?: string;

  createdAt?: string;
  updatedAt?: string;

  createdBy?: string;
  updatedBy?: string;
}


// ============================================================
// LIST QUERY PARAMETERS
// ============================================================

export interface QuotationListParams {
  page?: number;
  limit?: number;

  search?: string;

  status?: QuotationStatus;
  source?: QuotationSource;

  customerId?: string;
  branchId?: string;

  financialYear?: string;

  fromDate?: string;
  toDate?: string;

  sortBy?: string;
  sortOrder?: "asc" | "desc";
}


// ============================================================
// PAGINATION
// ============================================================

export interface QuotationPagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}


// ============================================================
// API RESPONSES
// ============================================================

export interface QuotationListResponse {
  success: boolean;
  message: string;
  data: Quotation[];
  pagination?: QuotationPagination;
}

export interface QuotationResponse {
  success: boolean;
  message: string;
  data: Quotation;
}


// ============================================================
// CREATE QUOTATION
// ============================================================

export interface QuotationCreatePayload {
  businessId?: string;
  branchId?: string;

  quotationDate: string;
  validUntil?: string;

  customerId: string;

  source?: QuotationSource;

  items: QuotationItem[];

  paymentTerms?: PaymentTerms;

  notes?: string;
  termsAndConditions?: string;
  remarks?: string;
}


// ============================================================
// UPDATE QUOTATION
// ============================================================

export interface QuotationUpdatePayload {
  quotationDate?: string;
  validUntil?: string;

  customerId?: string;

  source?: QuotationSource;

  items?: QuotationItem[];

  paymentTerms?: PaymentTerms;

  notes?: string;
  termsAndConditions?: string;
  remarks?: string;
}


// ============================================================
// UPDATE STATUS
// ============================================================

export interface QuotationStatusPayload {
  status: QuotationStatus;
  remarks?: string;
}


// ============================================================
// CANCEL QUOTATION
// ============================================================

export interface QuotationCancelPayload {
  reason?: string;
}


// ============================================================
// SEND QUOTATION
// ============================================================

export interface QuotationSendPayload {
  email?: string;
  phone?: string;
  message?: string;
}


// ============================================================
// DUPLICATE QUOTATION
// ============================================================

export interface QuotationDuplicatePayload {
  quotationDate?: string;
  validUntil?: string;
  customerId?: string;
}


// ============================================================
// CONVERT QUOTATION TO INVOICE
// ============================================================

export interface QuotationConvertToInvoicePayload {
  invoiceDate?: string;
  dueDate?: string;
  notes?: string;
}