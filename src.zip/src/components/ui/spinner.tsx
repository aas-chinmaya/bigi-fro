export function Spinner() {
  return (
    <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary/60 border-t-transparent" />
  );
}