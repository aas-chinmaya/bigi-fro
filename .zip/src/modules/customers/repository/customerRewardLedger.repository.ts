import { Prisma } from "@prisma/client";

export const createRewardLedger = async (
  tx: Prisma.TransactionClient,
  data: Prisma.CustomerRewardLedgerCreateInput
) => tx.customerRewardLedger.create({ data });