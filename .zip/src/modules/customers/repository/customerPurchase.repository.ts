import prisma from "../../../config/db";

export const findPurchaseHistory = async (
  customerId: string,
  page: number,
  limit: number,
  fromDate?: Date,
  toDate?: Date,
  status?: any,
  invoiceType?: any,
  search?: string
) => {
  const where: any = {
    customerId,
    ...(status && { invoiceStatus: status }),
    ...(invoiceType && { invoiceType }),
    ...(search && {
      invoiceNumber: { contains: search, mode: "insensitive" },
    }),
    ...((fromDate || toDate) && {
      invoiceDate: {
        ...(fromDate && { gte: fromDate }),
        ...(toDate && { lte: toDate }),
      },
    }),
  };

  return prisma.salesInvoice.findMany({
    where,
    skip: (page - 1) * limit,
    take: limit,
    orderBy: { invoiceDate: "desc" },
    select: {
      id: true,
      invoiceNumber: true,
      invoiceDate: true,
      invoiceType: true,
      invoiceStatus: true,
      totalItems: true,
      totalQuantity: true,
      taxableAmount: true,
      discountAmount: true,
      grandTotal: true,
      paidAmount: true,
      pendingAmount: true,
      items: {
        orderBy: { lineNumber: "asc" },
        select: {
          id: true,
          lineNumber: true,
          productId: true,
          itemCode: true,
          itemName: true,
          description: true,
          unit: true,
          quantity: true,
          freeQuantity: true,
          unitPrice: true,
          discountAmount: true,
          taxableAmount: true,
          gstRate: true,
          cgstAmount: true,
          sgstAmount: true,
          igstAmount: true,
          cessAmount: true,
          lineTotal: true,
        },
      },
    },
  });
};

export const countPurchaseHistory = async (
  customerId: string,
  fromDate?: Date,
  toDate?: Date,
  status?: any,
  invoiceType?: any,
  search?: string
) => {
  const where: any = {
    customerId,
    ...(status && { invoiceStatus: status }),
    ...(invoiceType && { invoiceType }),
    ...(search && {
      invoiceNumber: { contains: search, mode: "insensitive" },
    }),
    ...((fromDate || toDate) && {
      invoiceDate: {
        ...(fromDate && { gte: fromDate }),
        ...(toDate && { lte: toDate }),
      },
    }),
  };

  return prisma.salesInvoice.count({ where });
};

export const getPurchaseSummary = async (
  customerId: string,
  fromDate?: Date,
  toDate?: Date,
  status?: any,
  invoiceType?: any,
  search?: string
) => {
  const where: any = {
    customerId,
    ...(status && { invoiceStatus: status }),
    ...(invoiceType && { invoiceType }),
    ...(search && {
      invoiceNumber: { contains: search, mode: "insensitive" },
    }),
    ...((fromDate || toDate) && {
      invoiceDate: {
        ...(fromDate && { gte: fromDate }),
        ...(toDate && { lte: toDate }),
      },
    }),
  };

  const result = await prisma.salesInvoice.aggregate({
    where,
    _count: { id: true },
    _sum: { grandTotal: true, paidAmount: true, pendingAmount: true },
  });

  return {
    totalInvoices: result._count.id,
    totalPurchaseAmount: Number(result._sum.grandTotal ?? 0),
    totalPaidAmount: Number(result._sum.paidAmount ?? 0),
    totalOutstanding: Number(result._sum.pendingAmount ?? 0),
  };
};