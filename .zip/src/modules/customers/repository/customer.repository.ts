import { Prisma, Customer, CustomerAddress } from "@prisma/client";
import prisma from "../../../config/db";

// Create Customer
export const create = async (tx: Prisma.TransactionClient, data: Prisma.CustomerCreateInput): Promise<Customer> => {
    return tx.customer.create({ data });
};

// Find By Id
export const findById = async (id: string): Promise<Customer | null> => {
    return prisma.customer.findFirst({
        where: { id, deletedAt: null },
        include: { addresses: true }
    });
};

// Find By Id within transaction
export const findByIdTx = async (tx: Prisma.TransactionClient, id: string): Promise<Customer | null> => {
    return tx.customer.findFirst({
        where: { id, deletedAt: null },
        include: { addresses: true }
    });
};

// Find By Mobile
export const findByMobile = async (businessId: string, mobile: string): Promise<Customer | null> => {
    return prisma.customer.findFirst({
        where: { businessId, mobile, deletedAt: null }
    });
};

// Find By GSTIN
export const findByGSTIN = async (businessId: string, gstin: string): Promise<Customer | null> => {
    return prisma.customer.findFirst({
        where: { businessId, gstin, deletedAt: null }
    });
};

// List Customers
export const findMany = async (businessId: string, page: number, limit: number): Promise<Customer[]> => {

    const skip = (page - 1) * limit;

    return prisma.customer.findMany({
        where: { businessId, deletedAt: null },
        include: { addresses: true },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit
    });

};

// Count
export const count = async (businessId: string): Promise<number> => {
    return prisma.customer.count({
        where: { businessId, deletedAt: null }
    });
};

// Update Customer
export const update = async (tx: Prisma.TransactionClient, id: string, data: Prisma.CustomerUpdateInput): Promise<Customer> => {
    return tx.customer.update({
        where: { id },
        data
    });
};

// Soft Delete Customer
export const remove = async (tx: Prisma.TransactionClient, id: string): Promise<Customer> => {
    return tx.customer.update({
        where: { id },
        data: {
            deletedAt: new Date(),
            isActive: false
        }
    });
};

/**
 * ---------------------------------------------------------
 * Address Operations
 * ---------------------------------------------------------
*/
// Create Address
export const createAddress = async (tx: Prisma.TransactionClient, data: Prisma.CustomerAddressUncheckedCreateInput): Promise<CustomerAddress> => {
    return tx.customerAddress.create({ data });
};

// Update Address
export const updateAddress = async (tx: Prisma.TransactionClient, id: string, data: Prisma.CustomerAddressUpdateInput): Promise<CustomerAddress> => {
    return tx.customerAddress.update({
        where: { id },
        data
    });
};

// Delete Address
export const deleteAddress = async (tx: Prisma.TransactionClient, id: string): Promise<CustomerAddress> => {
    return tx.customerAddress.delete({
        where: { id }
    });
};

// Get Customer Addresses
export const getAddresses = async (customerId: string): Promise<CustomerAddress[]> => {
    return prisma.customerAddress.findMany({
        where: { customerId },
        orderBy: { createdAt: "asc" }
    });
};