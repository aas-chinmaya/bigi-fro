// import prisma from "../../../config/db";

// export const getDashboardData = async (customerId: string) => {
//   const [customer, purchaseSummary, recentPurchases, recentTransactions] =
//     await Promise.all([
//       prisma.customer.findUnique({
//         where: { id: customerId },
//         select: {
//           id: true,
//           customerCode: true,
//           customerType: true,
//           name: true,
//           mobile: true,
//           email: true,
//           gstin: true,
//           pan: true,
//           companyName: true,
//           creditLimit: true,
//           creditDays: true,
//           openingBalance: true,
//           outstandingBalance: true,
//           rewardPoints: true,
//           isActive: true,
//         },
//       }),
//       prisma.salesInvoice.aggregate({
//         where: { customerId, invoiceStatus: { not: "CANCELLED" } },
//         _count: { id: true },
//         _sum: { grandTotal: true, paidAmount: true, pendingAmount: true },
//       }),
//       prisma.salesInvoice.findMany({
//         where: { customerId, invoiceStatus: { not: "CANCELLED" } },
//         orderBy: { invoiceDate: "desc" },
//         take: 5,
//         select: {
//           id: true,
//           invoiceNumber: true,
//           invoiceDate: true,
//           invoiceStatus: true,
//           invoiceType: true,
//           grandTotal: true,
//           paidAmount: true,
//           pendingAmount: true,
//         },
//       }),
//       prisma.customerLedger.findMany({
//         where: { customerId },
//         orderBy: { transactionDate: "desc" },
//         take: 5,
//         select: {
//           id: true,
//           transactionDate: true,
//           documentType: true,
//           documentId: true,
//           documentNumber: true,
//           debit: true,
//           credit: true,
//           balance: true,
//           remarks: true,
//         },
//       }),
//     ]);

//   if (!customer) return null;

//   const totalInvoices = purchaseSummary._count.id;
//   const totalPurchaseAmount = Number(purchaseSummary._sum.grandTotal ?? 0);
//   const totalPaidAmount = Number(purchaseSummary._sum.paidAmount ?? 0);
//   const totalOutstanding = Number(purchaseSummary._sum.pendingAmount ?? 0);

//   return {
//     customer,
//     summary: {
//       totalInvoices,
//       totalPurchaseAmount,
//       totalPaidAmount,
//       totalOutstanding,
//       averageInvoiceValue: totalInvoices
//         ? Number((totalPurchaseAmount / totalInvoices).toFixed(2))
//         : 0,
//       lastPurchaseDate: recentPurchases[0]?.invoiceDate ?? null,
//     },
//     recentPurchases,
//     recentTransactions,
//   };
// };


import prisma from "../../../config/db";

export const getDashboardData = async (customerId: string) => {
  const [customer, purchaseSummary, quantitySummary, recentPurchases, recentTransactions, purchasesForAnalytics, topProducts, outstandingInvoices] = await Promise.all([
    prisma.customer.findUnique({
      where: { id: customerId },
      select: {
        id: true, customerCode: true, customerType: true, name: true, mobile: true,
        email: true, gstin: true, pan: true, companyName: true, creditLimit: true,
        creditDays: true, openingBalance: true, outstandingBalance: true,
        rewardPoints: true, isActive: true
      }
    }),
    prisma.salesInvoice.aggregate({
      where: { customerId, invoiceStatus: { not: "CANCELLED" } },
      _count: { id: true },
      _sum: { grandTotal: true, paidAmount: true, pendingAmount: true }
    }),
    prisma.salesInvoiceItem.aggregate({
      where: { salesInvoice: { customerId, invoiceStatus: { not: "CANCELLED" } } },
      _sum: { quantity: true }
    }),
    prisma.salesInvoice.findMany({
      where: { customerId, invoiceStatus: { not: "CANCELLED" } },
      orderBy: { invoiceDate: "desc" },
      take: 5,
      select: {
        id: true, invoiceNumber: true, invoiceDate: true, invoiceStatus: true,
        invoiceType: true, grandTotal: true, paidAmount: true, pendingAmount: true
      }
    }),
    prisma.customerLedger.findMany({
      where: { customerId },
      orderBy: { transactionDate: "desc" },
      take: 5,
      select: {
        id: true, transactionDate: true, documentType: true, documentId: true,
        documentNumber: true, debit: true, credit: true, balance: true, remarks: true
      }
    }),
    prisma.salesInvoice.findMany({
      where: { customerId, invoiceStatus: { not: "CANCELLED" } },
      orderBy: { invoiceDate: "asc" },
      select: { invoiceDate: true, grandTotal: true }
    }),
    prisma.salesInvoiceItem.groupBy({
      by: ["productId", "itemName"],
      where: { salesInvoice: { customerId, invoiceStatus: { not: "CANCELLED" } } },
      _sum: { quantity: true, lineTotal: true },
      orderBy: { _sum: { quantity: "desc" } },
      take: 10
    }),
    prisma.salesInvoice.findMany({
      where: {
        customerId,
        invoiceStatus: { in: ["ISSUED", "PARTIALLY_PAID"] },
        pendingAmount: { gt: 0 }
      },
      orderBy: { invoiceDate: "asc" },
      select: {
        id: true,
        invoiceNumber: true,
        invoiceDate: true,
        grandTotal: true,
        paidAmount: true,
        pendingAmount: true
      }
    })
  ]);

  if (!customer) return null;

  const totalInvoices = purchaseSummary._count.id;
  const totalPurchaseAmount = Number(purchaseSummary._sum.grandTotal ?? 0);
  const totalPaidAmount = Number(purchaseSummary._sum.paidAmount ?? 0);
  const totalOutstanding = Number(purchaseSummary._sum.pendingAmount ?? 0);
  const totalQuantityPurchased = Number(quantitySummary._sum.quantity ?? 0);

  // ================================
  // Monthly Purchase Analytics
  // ================================

  const monthlyMap: Record<string, { month: string; invoices: number; amount: number }> = {};

  purchasesForAnalytics.forEach(invoice => {
    if (!invoice.invoiceDate) return;

    const date = new Date(invoice.invoiceDate);
    const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;

    if (!monthlyMap[month])
      monthlyMap[month] = { month, invoices: 0, amount: 0 };

    monthlyMap[month].invoices += 1;
    monthlyMap[month].amount += Number(invoice.grandTotal ?? 0);
  });

  const monthlyPurchases = Object.values(monthlyMap).map(item => ({
    month: item.month,
    invoices: item.invoices,
    amount: Number(item.amount.toFixed(2))
  }));

  // ================================
  // Purchase Frequency
  // ================================

  const firstPurchaseDate = purchasesForAnalytics[0]?.invoiceDate ?? null;
  const lastPurchaseDate = recentPurchases[0]?.invoiceDate ?? null;

  let purchaseFrequency = 0;
  let averageDaysBetweenPurchases = 0;

  if (purchasesForAnalytics.length > 1 && firstPurchaseDate && lastPurchaseDate) {
    const days = Math.max(
      1,
      Math.ceil(
        (new Date(lastPurchaseDate).getTime() - new Date(firstPurchaseDate).getTime()) /
        86400000
      )
    );

    purchaseFrequency = Number((purchasesForAnalytics.length / days).toFixed(4));
    averageDaysBetweenPurchases = Number(
      (days / (purchasesForAnalytics.length - 1)).toFixed(2)
    );
  }

  // ================================
  // Customer Aging
  // ================================

  const aging = {
    current: 0,
    days1To30: 0,
    days31To60: 0,
    days61To90: 0,
    days90Plus: 0
  };

  const overdueInvoices = outstandingInvoices.map(invoice => {
    // const invoiceDate = new Date(invoice.invoiceDate);
    // const dueDate = new Date(invoiceDate);

    if (!invoice.invoiceDate) return { ...invoice, overdueDays: 0, dueDate: null };

    const invoiceDate = new Date(invoice.invoiceDate);
    const dueDate = new Date(invoiceDate);

    dueDate.setDate(dueDate.getDate() + customer.creditDays);

    const today = new Date();

    const overdueDays = Math.max(
      0,
      Math.floor((today.getTime() - dueDate.getTime()) / 86400000)
    );

    const pendingAmount = Number(invoice.pendingAmount ?? 0);

    if (overdueDays === 0) {
      aging.current += pendingAmount;
    } else if (overdueDays <= 30) {
      aging.days1To30 += pendingAmount;
    } else if (overdueDays <= 60) {
      aging.days31To60 += pendingAmount;
    } else if (overdueDays <= 90) {
      aging.days61To90 += pendingAmount;
    } else {
      aging.days90Plus += pendingAmount;
    }

    return {
      ...invoice,
      overdueDays,
      dueDate
    };
  });

  Object.keys(aging).forEach(key => {
    const agingKey = key as keyof typeof aging;
    aging[agingKey] = Number(aging[agingKey].toFixed(2));
  });

  const totalOverdue = Number(
    (
      aging.days1To30 +
      aging.days31To60 +
      aging.days61To90 +
      aging.days90Plus
    ).toFixed(2)
  );

  const overdueInvoiceCount = overdueInvoices.filter(
    invoice => invoice.overdueDays > 0
  ).length;

  // ================================
  // Credit Analytics
  // ================================

  const creditLimit = Number(customer.creditLimit ?? 0);

  const availableCredit = Math.max(
    0,
    creditLimit - totalOutstanding
  );

  const creditUtilization = creditLimit
    ? Number(((totalOutstanding / creditLimit) * 100).toFixed(2))
    : 0;

  // ================================
  // Return Dashboard
  // ================================

  return {
    customer,

    summary: {
      totalInvoices,
      totalPurchaseAmount,
      totalPaidAmount,
      totalOutstanding,
      totalQuantityPurchased,
      averageInvoiceValue: totalInvoices
        ? Number((totalPurchaseAmount / totalInvoices).toFixed(2))
        : 0,
      firstPurchaseDate,
      lastPurchaseDate
    },

    analytics: {
      purchaseFrequency,
      averageDaysBetweenPurchases,
      monthlyPurchases,

      topProducts: topProducts.map(item => ({
        productId: item.productId,
        itemName: item.itemName,
        quantity: Number(item._sum.quantity ?? 0),
        amount: Number(item._sum.lineTotal ?? 0)
      })),

      aging: {
        ...aging,
        totalOverdue,
        overdueInvoiceCount,
        overdueInvoices
      },

      credit: {
        creditLimit,
        availableCredit,
        creditUtilization
      }
    },

    recentPurchases,
    recentTransactions
  };
};