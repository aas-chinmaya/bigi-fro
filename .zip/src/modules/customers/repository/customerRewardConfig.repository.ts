import prisma from "../../../config/db";

export const findConfig = async (businessId: string, branchId?: string) =>
  prisma.customerRewardConfig.findFirst({ where: { businessId, branchId: branchId ?? null } });

export const createConfig = async (data: any) =>
  prisma.customerRewardConfig.create({ data });

export const updateConfig = async (businessId: string, branchId: string | undefined, data: any) =>
  prisma.customerRewardConfig.updateMany({
    where: { businessId, branchId: branchId ?? null },
    data
  });

export const deleteConfig = async (businessId: string, branchId?: string) =>
  prisma.customerRewardConfig.deleteMany({
    where: { businessId, branchId: branchId ?? null }
  });