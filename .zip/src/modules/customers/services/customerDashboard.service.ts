import NotFoundError from "../../../common/exceptions/NotFoundError";
import * as customerDashboardRepository from "../repository/customerDashboard.repository";

export const getCustomerDashboard = async (customerId: string) => {
    const dashboard = await customerDashboardRepository.getDashboardData(customerId);

    if (!dashboard)
        throw new NotFoundError("Customer not found.");

    return dashboard;
};