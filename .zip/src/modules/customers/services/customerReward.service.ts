import { Prisma } from "@prisma/client";
import prisma from "../../../config/db";
import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";
export const getRewardConfig = async (
  businessId: string,
  branchId: string
) => {
  const config = await prisma.customerRewardConfig.findUnique({
    where: {
      businessId_branchId: { businessId, branchId }
    }
  });

  if (!config)
    throw new NotFoundError("Reward configuration not found.");

  return config;
};

export const calculateEarnedPoints = async (
  businessId: string,
  branchId: string,
  invoiceAmount: number
) => {
  const config = await getRewardConfig(businessId, branchId);

  if (!config.isEnabled || invoiceAmount < Number(config.minimumInvoiceAmount))
    return { points: 0, config };

  const points = Math.floor(
    (invoiceAmount / Number(config.currencyPerPoint)) *
      Number(config.pointsPerCurrency)
  );

  return { points, config };
};

// EARNED REWARD
export const postEarnedReward = async ({
  tx,
  businessId,
  branchId,
  customerId,
  invoiceId,
  invoiceNumber,
  invoiceAmount,
  createdBy
}: {
  tx: Prisma.TransactionClient;
  businessId: string;
  branchId: string;
  customerId: string;
  invoiceId: string;
  invoiceNumber: string;
  invoiceAmount: number;
  createdBy: string;
}) => {
  const config = await tx.customerRewardConfig.findUnique({
    where: {
      businessId_branchId: { businessId, branchId }
    }
  });

  if (!config || !config.isEnabled)
    return null;

  if (invoiceAmount < Number(config.minimumInvoiceAmount))
    return null;

  const points = Math.floor(
    (invoiceAmount / Number(config.currencyPerPoint)) *
      Number(config.pointsPerCurrency)
  );

  if (points <= 0)
    return null;

  const customer = await tx.customer.findUnique({
    where: { id: customerId },
    select: { rewardPoints: true }
  });

  if (!customer)
    throw new NotFoundError("Customer not found.");

  const balanceBefore = customer.rewardPoints;
  const balanceAfter = balanceBefore + points;

  const expiresAt = config.expiryEnabled && config.expiryDays
    ? new Date(Date.now() + config.expiryDays * 86400000)
    : null;

  await tx.customer.update({
    where: { id: customerId },
    data: { rewardPoints: balanceAfter }
  });

  return tx.customerRewardLedger.create({
    data: {
      businessId,
      branchId,
      customerId,
      type: "EARNED",
      points,
      balanceBefore,
      balanceAfter,
      remainingPoints: points,
      expiresAt,
      referenceType: "SALES_INVOICE",
      referenceId: invoiceId,
      referenceNumber: invoiceNumber,
      description: `Reward points earned on invoice ${invoiceNumber}`,
      createdBy
    }
  });
};

//REWARD HOSTORY FUNCTION
export const getRewardHistory = async (
  customerId: string,
  options: {
    branchId?: string;
    type?: string;
    page?: number;
    limit?: number;
  } = {}
) => {
  const page = Math.max(1, options.page ?? 1);
  const limit = Math.min(100, Math.max(1, options.limit ?? 20));
  const skip = (page - 1) * limit;

  const where: any = {
    customerId,
    ...(options.branchId && { branchId: options.branchId }),
    ...(options.type && { type: options.type })
  };

  const [history, total] = await Promise.all([
    prisma.customerRewardLedger.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip,
      take: limit,
      select: {
        id: true,
        businessId: true,
        branchId: true,
        customerId: true,
        type: true,
        points: true,
        balanceBefore: true,
        balanceAfter: true,
        remainingPoints: true,
        expiresAt: true,
        referenceType: true,
        referenceId: true,
        referenceNumber: true,
        description: true,
        createdBy: true,
        createdAt: true
      }
    }),
    prisma.customerRewardLedger.count({ where })
  ]);

  return {
    history,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    }
  };
};

//REDEMPTION FUNCTION
export const redeemRewardPoints = async ({tx,businessId,branchId,customerId,points,invoiceId,invoiceNumber,createdBy}: {
  tx: Prisma.TransactionClient;
  businessId: string;
  branchId: string;
  customerId: string;
  points: number;
  invoiceId?: string;
  invoiceNumber?: string;
  createdBy: string;
}) => {
    const config = await tx.customerRewardConfig.findUnique({
        where: { businessId_branchId: { businessId, branchId } }
    });

    if (!config || !config.redemptionEnabled)
        throw new ConflictError("Reward redemption is disabled.");

    if (points < config.minimumRedeemPoints)
        throw new ConflictError(`Minimum redemption is ${config.minimumRedeemPoints} points.`);

    if (config.maximumRedeemPoints !== null &&points > config.maximumRedeemPoints)
        throw new ConflictError(`Maximum redemption is ${config.maximumRedeemPoints} points.`);

    const customer = await tx.customer.findUnique({
        where: { id: customerId },
        select: { rewardPoints: true }
    });

    if (!customer)
        throw new NotFoundError("Customer not found.");

    if (points > customer.rewardPoints)
        throw new ConflictError("Insufficient reward points.");

    const balanceBefore = customer.rewardPoints;
    const balanceAfter = balanceBefore - points;

    let remaining = points;

    const rewardEntries = await tx.customerRewardLedger.findMany({
        where: {
        customerId,
        businessId,
        branchId,
        type: "EARNED",
        remainingPoints: { gt: 0 },
        OR: [
            { expiresAt: null },
            { expiresAt: { gt: new Date() } }
        ]
        },
        orderBy: { createdAt: "asc" }
    });

    for (const entry of rewardEntries) {
        if (remaining <= 0) break;

        const available = entry.remainingPoints ?? 0;
        const consumed = Math.min(available, remaining);

        await tx.customerRewardLedger.update({
        where: { id: entry.id },
        data: {
            remainingPoints: available - consumed
        }
        });

        remaining -= consumed;
    }

    if (remaining > 0)
        throw new ConflictError("Unable to allocate reward points.");

    await tx.customer.update({
        where: { id: customerId },
        data: { rewardPoints: balanceAfter }
    });

    const redemption = await tx.customerRewardLedger.create({
        data: {
        businessId,
        branchId,
        customerId,
        type: "REDEEMED",
        points: -points,
        balanceBefore,
        balanceAfter,
        remainingPoints: 0,
        referenceType: invoiceId ? "SALES_INVOICE" : "REWARD_REDEMPTION",
        referenceId: invoiceId,
        referenceNumber: invoiceNumber,
        description: `Redeemed ${points} reward points.`,
        createdBy
        }
    });

    return {
        pointsRedeemed: points,
        pointValue: Number(config.pointValue),
        redemptionValue: Number(
        (points * Number(config.pointValue)).toFixed(2)
        ),
        balanceBefore,
        balanceAfter,
        redemption
    };
};

export const calculateRewardRedemption = async ({
    tx,
    businessId,
    branchId,
    customerId,
    points,
    invoiceAmount
}: {
    tx: Prisma.TransactionClient;
    businessId: string;
    branchId: string;
    customerId: string;
    points: number;
    invoiceAmount: number;
}): Promise<{
    points: number;
    value: number;
}> => {

    if (!points || points <= 0) {
        return {
            points: 0,
            value: 0
        };
    }

    const config =
        await tx.customerRewardConfig.findUnique({
            where: {
                businessId_branchId: {
                    businessId,
                    branchId
                }
            }
        });

    if (!config)
        throw new NotFoundError(
            "Customer reward configuration not found."
        );

    if (!config.redemptionEnabled)
        throw new ConflictError(
            "Reward redemption is disabled."
        );

    if (points < config.minimumRedeemPoints)
        throw new ConflictError(
            `Minimum redemption is ${config.minimumRedeemPoints} points.`
        );

    if (
        config.maximumRedeemPoints !== null &&
        points > config.maximumRedeemPoints
    ) {
        throw new ConflictError(
            `Maximum redemption is ${config.maximumRedeemPoints} points.`
        );
    }

    const customer =
        await tx.customer.findUnique({
            where: {
                id: customerId
            },
            select: {
                rewardPoints: true
            }
        });

    if (!customer)
        throw new NotFoundError("Customer not found.");

    if (points > customer.rewardPoints)
        throw new ConflictError("Insufficient reward points.");

    const pointValue = Number(config.pointValue);

    const value = Number((points * pointValue).toFixed(2));

    const maxValue =Number((invoiceAmount *(Number(config.maximumRedeemPercentage) / 100)).toFixed(2));

    if (value > maxValue)
        throw new ConflictError(`Reward redemption cannot exceed ${config.maximumRedeemPercentage}% of invoice value.`);

    return {
        points,
        value
    };
};

export const consumeRewardPoints = async ({tx,businessId,branchId,customerId,points,invoiceId,invoiceNumber,createdBy
}: {
  tx: Prisma.TransactionClient;
  businessId: string;
  branchId: string;
  customerId: string;
  points: number;
  invoiceId: string;
  invoiceNumber: string;
  createdBy: string;
}) => {
  if (!points || points <= 0)
    return null;

  const customer = await tx.customer.findUnique({
    where: { id: customerId },
    select: { rewardPoints: true }
  });

  if (!customer)
    throw new NotFoundError("Customer not found.");

  if (customer.rewardPoints < points)
    throw new ConflictError("Insufficient reward points.");

  const balanceBefore = customer.rewardPoints;
  const balanceAfter = balanceBefore - points;

  let remaining = points;

  const entries = await tx.customerRewardLedger.findMany({
    where: {
      businessId,
      branchId,
      customerId,
      type: "EARNED",
      remainingPoints: { gt: 0 },
      OR: [
        { expiresAt: null },
        { expiresAt: { gt: new Date() } }
      ]
    },
    orderBy: { createdAt: "asc" }
  });

  for (const entry of entries) {

    if (remaining <= 0)
      break;

    const available = entry.remainingPoints ?? 0;
    const consumed = Math.min(available, remaining);

    await tx.customerRewardLedger.update({
      where: { id: entry.id },
      data: {
        remainingPoints: available - consumed
      }
    });

    remaining -= consumed;
  }

  if (remaining > 0)
    throw new ConflictError("Unable to allocate reward points.");

  await tx.customer.update({
    where: { id: customerId },
    data: { rewardPoints: balanceAfter }
  });

  return tx.customerRewardLedger.create({
    data: {
      businessId,
      branchId,
      customerId,
      type: "REDEEMED",
      points: -points,
      balanceBefore,
      balanceAfter,
      remainingPoints: 0,
      referenceType: "SALES_INVOICE",
      referenceId: invoiceId,
      referenceNumber: invoiceNumber,
      description: `Redeemed ${points} points on invoice ${invoiceNumber}`,
      createdBy
    }
  });
};