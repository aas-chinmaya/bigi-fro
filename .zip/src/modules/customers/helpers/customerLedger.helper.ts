import { Prisma, LedgerDocumentType, LedgerEntryType } from "@prisma/client";
import * as customerLedgerRepository from "../repository/customerLedger.repository";

type PostCustomerLedgerParams = {
    tx: Prisma.TransactionClient;
    businessId: string;
    branchId?: string;
    customerId: string;
    transactionDate?: Date;
    documentType: LedgerDocumentType;
    documentId?: string;
    documentNumber: string;
    debit?: number;
    credit?: number;
    remarks?: string;
    createdBy: string;
};

export const postCustomerLedger = async ({
    tx,
    businessId,
    branchId,
    customerId,
    transactionDate = new Date(),
    documentType,
    documentId,
    documentNumber,
    debit = 0,
    credit = 0,
    remarks,
    createdBy
}: PostCustomerLedgerParams) => {

    const lastBalance = await customerLedgerRepository.findLastBalance(customerId);

    const balance = lastBalance + debit - credit;

    return customerLedgerRepository.create(tx, {
        businessId,
        branchId,
        transactionDate,
        documentType,
        documentId,
        documentNumber,
        entryType: debit > 0 ? LedgerEntryType.DEBIT : LedgerEntryType.CREDIT,
        debit,
        credit,
        balance,
        remarks,
        createdBy,
        customer: {
            connect: {
                id: customerId
            }
        }
    });
};