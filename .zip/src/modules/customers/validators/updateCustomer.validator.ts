import { z } from "zod";
import { AddressType, CustomerType } from "@prisma/client";

const addressSchema = z.object({
    id: z.string().cuid().optional(),
    type: z.nativeEnum(AddressType),
    label: z.string().trim().optional(),
    contactPerson: z.string().trim().optional(),
    contactNumber: z.string().trim().optional(),
    addressLine1: z.string().trim().min(1),
    addressLine2: z.string().trim().optional(),
    landmark: z.string().trim().optional(),
    city: z.string().trim().min(1),
    district: z.string().trim().optional(),
    state: z.string().trim().min(1),
    stateCode: z.string().trim().optional(),
    country: z.string().trim().default("India"),
    pincode: z.string().trim().min(6).max(6),
    isDefault: z.boolean().default(false),
    isActive: z.boolean().default(true)

});

export const updateCustomerSchema = z.object({
    updatedBy: z.string().cuid(),
    customerType: z.nativeEnum(CustomerType).optional(),
    name: z.string().trim().min(1).optional(),
    mobile: z.string().trim().regex(/^[6-9]\d{9}$/).optional(),
    alternateMobile: z.string().trim().optional(),
    email: z.string().trim().email().optional(),
    gstin: z.string().trim().optional(),
    pan: z.string().trim().optional(),
    companyName: z.string().trim().optional(),
    creditLimit: z.coerce.number().optional(),
    creditDays: z.coerce.number().optional(),
    openingBalance: z.coerce.number().optional(),
    outstandingBalance: z.coerce.number().optional(),
    rewardPoints: z.coerce.number().optional(),
    isActive: z.boolean().optional(),
    notes: z.string().trim().optional(),
    addresses: z.array(addressSchema).optional()

});

export type UpdateCustomerRequest = z.infer<typeof updateCustomerSchema>;