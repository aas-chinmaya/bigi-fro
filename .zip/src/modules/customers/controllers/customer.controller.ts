import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as customerService from "../services/customer.service";

export const createCustomer = asyncHandler(async (req: Request, res: Response) => {
    const customer = await customerService.createCustomer(req.body);

    return res.status(201).json({
        success: true,
        message: "Customer created successfully.",
        data: customer
    });
});

export const getCustomerById = asyncHandler(async (req: Request, res: Response) => {

    const id  = req.params.id as string;
    const customer = await customerService.getCustomerById(id);

    return res.status(200).json({
        success: true,
        data: customer
    });
});

export const getCustomers = asyncHandler(async (req: Request, res: Response) => {

    const businessId = req.query.businessId as string;
    const page = Number(req.query.page) || 1;
    const limit = Number(req.query.limit) || 20;

    const customers = await customerService.getCustomers(
        businessId,
        page,
        limit
    );

    return res.status(200).json({
        success: true,
        ...customers
    });
});

export const updateCustomer = asyncHandler(async (req: Request, res: Response) => {

    const id  = req.params.id as string;
    const customer = await customerService.updateCustomer(
        id,
        req.body
    );

    return res.status(200).json({
        success: true,
        message: "Customer updated successfully.",
        data: customer
    });
});

export const deleteCustomer = asyncHandler(async (req: Request, res: Response) => {

    const id  = req.params.id as string;
    await customerService.deleteCustomer(id);

    return res.status(200).json({
        success: true,
        message: "Customer deleted successfully."
    });
});