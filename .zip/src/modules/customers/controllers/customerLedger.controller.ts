import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as customerLedgerService from "../services/customerLedger.service";
import { ValidationError } from "../../../common/exceptions/ValidationError";

export const getCustomerLedger = asyncHandler(async (req: Request, res: Response) => {
    const customerId = req.params.customerId as string;
    const page = Number(req.query.page) || 1;
    const limit = Number(req.query.limit) || 20;
    const result = await customerLedgerService.getCustomerLedgers(customerId, page, limit);
    return res.status(200).json({ success: true, ...result });
});

export const getCustomerOutstanding = asyncHandler(async (req: Request, res: Response) => {
    const customerId = req.params.customerId as string;
    const result = await customerLedgerService.getCustomerOutstanding(customerId);
    return res.status(200).json({ success: true, data: result });
});

export const getCustomerStatement = asyncHandler(async (req: Request, res: Response) => {
    const customerId = req.params.customerId as string;
    const fromDate = new Date(req.query.fromDate as string);
    const toDate = new Date(req.query.toDate as string);

    if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime()))
        throw new ValidationError("Valid fromDate and toDate are required.");

    if (fromDate > toDate)
        throw new ValidationError("fromDate cannot be greater than toDate.");

    const statement = await customerLedgerService.getCustomerStatement(customerId, fromDate, toDate);
    return res.status(200).json({ success: true, data: statement });
});