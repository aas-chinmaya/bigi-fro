import { DocumentType, Prisma } from "@prisma/client";
import { DOCUMENT_PREFIX } from "../constants/documentPrefix";

export const generateDocumentNumber = async (
    tx: Prisma.TransactionClient,
    businessId: string,
    branchId: string,
    documentType: DocumentType
): Promise<string> => {

    let documentSequence = await tx.documentSequence.findUnique({
        where: {
            businessId_branchId_documentType: {
                businessId,
                branchId,
                documentType
            }
        }
    });

    if (!documentSequence) {
        documentSequence = await tx.documentSequence.create({
            data: {
                businessId,
                branchId,
                documentType,
                sequence: 1
            }
        });
    } else {
        documentSequence = await tx.documentSequence.update({
            where: {
                id: documentSequence.id
            },
            data: {
                sequence: {
                    increment: 1
                }
            }
        });
    }
    const prefix = DOCUMENT_PREFIX[documentType];
    return `${prefix}${documentSequence.sequence
        .toString()
        .padStart(6, "0")}`;
};