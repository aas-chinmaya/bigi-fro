import { Prisma } from "@prisma/client";
type Tx = Prisma.TransactionClient;

export const generatePaymentNumber = async (
    tx: Tx,
    businessId: string,
    branchId: string
): Promise<string> => {

    if (!businessId)
        throw new Error("Business ID is required.");

    if (!branchId)
        throw new Error("Branch ID is required.");

    const sequence = await tx.paymentSequence.upsert({

        where: {
            businessId_branchId: {
                businessId,
                branchId,
            },
        },

        create: {
            businessId,
            branchId,
            currentNumber: 1,
        },

        update: {
            currentNumber: {
                increment: 1,
            },
        },

        select: {
            currentNumber: true,
        },
    });

    return `PAY-${String(sequence.currentNumber).padStart(6, "0")}`;
};