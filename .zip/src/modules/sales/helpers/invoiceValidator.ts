import { ValidationError } from "../../../common/exceptions/ValidationError";

export const validateInvoice = (
    invoice: any,
    items: any[]
): void => {

    if (!invoice) {
        throw new ValidationError("Sales Invoice draft not found.");
    }

    // =====================================================
    // Customer
    // =====================================================

    if (!invoice.customerId)
        throw new ValidationError("Customer is required.");

    if (!invoice.buyerName?.trim())
        throw new ValidationError("Buyer name is required.");

    if (!invoice.buyerType)
        throw new ValidationError("Buyer type is required.");

    // =====================================================
    // Billing Address
    // =====================================================

    if (!invoice.billingAddressLine1?.trim())
        throw new ValidationError("Billing address is required.");

    if (!invoice.billingCity?.trim())
        throw new ValidationError("Billing city is required.");

    if (!invoice.billingState?.trim())
        throw new ValidationError("Billing state is required.");

    if (!invoice.billingStateCode?.trim())
        throw new ValidationError("Billing state code is required.");

    if (!invoice.billingPincode?.trim())
        throw new ValidationError("Billing pincode is required.");

    // =====================================================
    // Invoice
    // =====================================================

    if (!invoice.invoiceDate)
        throw new ValidationError("Invoice date is required.");

    if (!invoice.invoiceType)
        throw new ValidationError("Invoice type is required.");

    // if (!invoice.taxType)
    //     throw new ValidationError("Tax type is required.");

    if (!invoice.placeOfSupply)
        throw new ValidationError("Place of supply is required.");

    if (!invoice.placeOfSupplyCode)
        throw new ValidationError("Place of supply code is required.");

    // =====================================================
    // Items
    // =====================================================

    if (!items.length)
        throw new ValidationError("At least one item is required.");

    items.forEach((item, index) => {

        if (!item.productId)
            throw new ValidationError(`Product missing in row ${index + 1}.`);

        if (!item.itemName?.trim())
            throw new ValidationError(`Item name missing in row ${index + 1}.`);

        if (!item.hsnSacCode?.trim())
            throw new ValidationError(`HSN/SAC missing in row ${index + 1}.`);

        if (!item.unit?.trim())
            throw new ValidationError(`Unit missing in row ${index + 1}.`);

        if (!item.quantity || Number(item.quantity) <= 0)
            throw new ValidationError(`Invalid quantity in row ${index + 1}.`);

        if (!item.unitPrice || Number(item.unitPrice) <= 0)
            throw new ValidationError(`Invalid unit price in row ${index + 1}.`);

        if (item.gstRate === null || item.gstRate === undefined)
            throw new ValidationError(`GST Rate missing in row ${index + 1}.`);

    });

};