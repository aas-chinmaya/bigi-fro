import { Prisma, InvoiceStatus, DocumentType, PaymentMethod, PaymentStatus, PaymentDocumentType, LedgerDocumentType, InvoiceType, InvoiceSource } from "@prisma/client";
import prisma from "../../../config/db";
import * as salesInvoiceRepository from "../repository/salesInvoice.repository";
import { generateFinancialYear } from "../../../common/helpers/generateFinancialYear";
import { CreateDraftRequest } from "../validators/createDraft.validator";
import { validateInvoice } from "../helpers/invoiceValidator";
import { calculateInvoice } from "../helpers/invoiceCalculator";
import { validateCalculatedInvoice } from "../helpers/invoiceCalculationValidator";
import { generateDocumentNumber } from "../helpers/documentNumberGenerator";
import * as salesInvoiceItemRepository from "../repository/salesInvoiceItem.repository";
import NotFoundError  from "../../../common/exceptions/NotFoundError";
import ConflictError  from "../../../common/exceptions/ConflictError";
import ValidationError from "../../../common/exceptions/ValidationError";
import { postCustomerLedger } from "../../customers/helpers/customerLedger.helper";
import {postEarnedReward, calculateRewardRedemption, consumeRewardPoints} from "../../customers/services/customerReward.service";

export const createDraft = async (payload: Record<string, any>) => {
    // 1. Strip out non-Prisma top-level UI fields so Prisma doesn't crash on "Unknown argument"
    const {
        items,
        customer,
        buyerContactPerson,
        sameAsBilling,
        subtotal,
        paymentStatus,
        paymentMethod,
        ...validInvoiceFields
    } = payload;

    // Validate top-level mandatory fields required by Prisma schema
    if (!validInvoiceFields.businessId) {
        throw new Error("Missing required field: 'businessId'");
    }
    if (!validInvoiceFields.createdBy) {
        throw new Error("Missing required field: 'createdBy'");
    }
    if (!validInvoiceFields.invoiceType) {
        throw new Error("Missing required field: 'invoiceType'");
    }

    const financialYear = generateFinancialYear();

    // 2. Process items and strip out non-Prisma item fields
    const sanitizedItems: Prisma.SalesInvoiceItemUncheckedCreateWithoutSalesInvoiceInput[] = 
        Array.isArray(items)
            ? items.map((item: Record<string, any>, index: number) => {
                  const {
                      itemId,   // Non-Prisma UI field
                      product,  // Non-Prisma UI field
                      ...validItemFields
                  } = item;

                  const missingFields: string[] = [];
                  if (!validItemFields.productId) missingFields.push("productId");
                  if (!validItemFields.itemCode) missingFields.push("itemCode");
                  if (!validItemFields.itemName) missingFields.push("itemName");
                  if (!validItemFields.hsnSacCode) missingFields.push("hsnSacCode");
                  if (!validItemFields.classification) missingFields.push("classification");
                  if (!validItemFields.unit) missingFields.push("unit");
                  if (validItemFields.quantity === undefined || validItemFields.quantity === null) missingFields.push("quantity");
                  if (validItemFields.unitPrice === undefined || validItemFields.unitPrice === null) missingFields.push("unitPrice");
                  if (validItemFields.taxableAmount === undefined || validItemFields.taxableAmount === null) missingFields.push("taxableAmount");
                  if (validItemFields.gstRate === undefined || validItemFields.gstRate === null) missingFields.push("gstRate");
                  if (validItemFields.lineTotal === undefined || validItemFields.lineTotal === null) missingFields.push("lineTotal");

                  if (missingFields.length > 0) {
                      throw new Error(
                          `Item at index ${index} is missing required fields: ${missingFields.join(", ")}`
                      );
                  }

                  return {
                      ...validItemFields,
                      lineNumber: validItemFields.lineNumber ?? index + 1,

                      // Convert numeric fields to String for Prisma Decimal compatibility
                      quantity: validItemFields.quantity.toString(),
                      unitPrice: validItemFields.unitPrice.toString(),
                      taxableAmount: validItemFields.taxableAmount.toString(),
                      gstRate: validItemFields.gstRate.toString(),
                      lineTotal: validItemFields.lineTotal.toString(),

                      ...(validItemFields.mrp !== undefined && validItemFields.mrp !== null && { mrp: validItemFields.mrp.toString() }),
                      ...(validItemFields.sellingPrice !== undefined && validItemFields.sellingPrice !== null && { sellingPrice: validItemFields.sellingPrice.toString() }),
                      ...(validItemFields.freeQuantity !== undefined && { freeQuantity: validItemFields.freeQuantity.toString() }),
                      ...(validItemFields.discountValue !== undefined && { discountValue: validItemFields.discountValue.toString() }),
                      ...(validItemFields.discountAmount !== undefined && { discountAmount: validItemFields.discountAmount.toString() }),
                      ...(validItemFields.cgstRate !== undefined && { cgstRate: validItemFields.cgstRate.toString() }),
                      ...(validItemFields.cgstAmount !== undefined && { cgstAmount: validItemFields.cgstAmount.toString() }),
                      ...(validItemFields.sgstRate !== undefined && { sgstRate: validItemFields.sgstRate.toString() }),
                      ...(validItemFields.sgstAmount !== undefined && { sgstAmount: validItemFields.sgstAmount.toString() }),
                      ...(validItemFields.igstRate !== undefined && { igstRate: validItemFields.igstRate.toString() }),
                      ...(validItemFields.igstAmount !== undefined && { igstAmount: validItemFields.igstAmount.toString() }),
                      ...(validItemFields.cessRate !== undefined && { cessRate: validItemFields.cessRate.toString() }),
                      ...(validItemFields.cessAmount !== undefined && { cessAmount: validItemFields.cessAmount.toString() }),

                      ...(validItemFields.expiryDate && { expiryDate: new Date(validItemFields.expiryDate) })
                  };
              })
            : [];

    const draft = await prisma.$transaction(async (tx) => {
        const invoiceData: Prisma.SalesInvoiceUncheckedCreateInput = {
            ...validInvoiceFields,

            businessId: validInvoiceFields.businessId,
            createdBy: validInvoiceFields.createdBy,
            invoiceType: validInvoiceFields.invoiceType as InvoiceType,
            financialYear,
            invoiceStatus: InvoiceStatus.DRAFT,
            invoiceSource: (validInvoiceFields.invoiceSource as InvoiceSource) ?? ("POS" as InvoiceSource),

            // Handle customer ID safely
            ...(validInvoiceFields.customerId && typeof validInvoiceFields.customerId === "string" && validInvoiceFields.customerId.trim() !== "" && { 
                customerId: validInvoiceFields.customerId 
            }),

            // Convert Decimal values to strings
            ...(validInvoiceFields.exchangeRate !== undefined && { exchangeRate: validInvoiceFields.exchangeRate.toString() }),
            ...(validInvoiceFields.totalQuantity !== undefined && { totalQuantity: validInvoiceFields.totalQuantity.toString() }),
            ...(validInvoiceFields.taxableAmount !== undefined && { taxableAmount: validInvoiceFields.taxableAmount.toString() }),
            ...(validInvoiceFields.discountAmount !== undefined && { discountAmount: validInvoiceFields.discountAmount.toString() }),
            ...(validInvoiceFields.cgstAmount !== undefined && { cgstAmount: validInvoiceFields.cgstAmount.toString() }),
            ...(validInvoiceFields.sgstAmount !== undefined && { sgstAmount: validInvoiceFields.sgstAmount.toString() }),
            ...(validInvoiceFields.igstAmount !== undefined && { igstAmount: validInvoiceFields.igstAmount.toString() }),
            ...(validInvoiceFields.cessAmount !== undefined && { cessAmount: validInvoiceFields.cessAmount.toString() }),
            ...(validInvoiceFields.roundOffAmount !== undefined && { roundOffAmount: validInvoiceFields.roundOffAmount.toString() }),
            ...(validInvoiceFields.grandTotal !== undefined && { grandTotal: validInvoiceFields.grandTotal.toString() }),
            ...(validInvoiceFields.paidAmount !== undefined && { paidAmount: validInvoiceFields.paidAmount.toString() }),
            ...(validInvoiceFields.pendingAmount !== undefined && { pendingAmount: validInvoiceFields.pendingAmount.toString() }),
            ...(validInvoiceFields.rewardDiscountAmount !== undefined && { rewardDiscountAmount: validInvoiceFields.rewardDiscountAmount.toString() }),

            ...(validInvoiceFields.invoiceDate && { invoiceDate: new Date(validInvoiceFields.invoiceDate) }),
            ...(validInvoiceFields.acknowledgementDate && { acknowledgementDate: new Date(validInvoiceFields.acknowledgementDate) }),

            ...(sanitizedItems.length > 0 && {
                items: {
                    create: sanitizedItems
                }
            })
        };

        return await salesInvoiceRepository.create(tx, invoiceData);
    });

    return draft;
};
export const getDraftById = async (id: string) => {

    const draft = await salesInvoiceRepository.findById(id);
    if (!draft) {
        throw new NotFoundError(
            "Sales Invoice Draft not found."
        );
    }
    return draft;
};


export const getDrafts = async ( businessId: string, page: number, limit: number) => {

    const drafts = await salesInvoiceRepository.findMany( businessId, page, limit);

    const total = await salesInvoiceRepository.count( businessId );
    return {
        data: drafts,
        pagination: {
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit)
        }
    };
};



export const updateDraft = async ( id: string, payload: Prisma.SalesInvoiceUpdateInput) => {
    const existingDraft = await salesInvoiceRepository.findById(id);

    if (!existingDraft) {
        throw new NotFoundError(
            "Sales Invoice Draft not found."
        );
    }

    if ( existingDraft.invoiceStatus !== InvoiceStatus.DRAFT) {
        throw new ConflictError(
            "Only Draft invoices can be updated."
        );
    }

    const draft =
        await prisma.$transaction(async (tx) => {
            return salesInvoiceRepository.update(
                tx,
                id,
                payload
            );
        });
    return draft;
};


export const deleteDraft = async (id: string) => {

    const existingDraft = await salesInvoiceRepository.findById(id);

    if (!existingDraft) {
        throw new NotFoundError("Sales Invoice Draft not found.");
    }

    if ( existingDraft.invoiceStatus !== InvoiceStatus.DRAFT) {
        throw new ConflictError(
            "Only Draft invoices can be deleted."
        );
    }

    return prisma.$transaction(async (tx) => {
        return salesInvoiceRepository.remove(
            tx,
            id
        );
    });
};


export const finalizeDraft = async (id: string, payload: any) => {

    return prisma.$transaction(async (tx) => {

        const draft = await salesInvoiceRepository.checkDraft(tx, id);

        if (!draft)
            throw new NotFoundError("Sales Invoice Draft not found.");

        validateInvoice(payload, payload.items);

        const calculatedInvoice = calculateInvoice(payload, payload.items);

        validateCalculatedInvoice(payload, calculatedInvoice);

        const invoiceNumber = await generateDocumentNumber(
            tx,
            draft.businessId,
            draft.branchId ?? "",
            "SALES_INVOICE"
        );

        const paidAmount = Number(payload.paidAmount ?? 0);
        const pendingAmount = calculatedInvoice.summary.grandTotal - paidAmount;

        await salesInvoiceItemRepository.replaceItems(
            tx,
            draft.id,
            payload.items.map((item: any, index: number) => ({
                salesInvoiceId: draft.id,
                lineNumber: index + 1,
                productId: item.productId,
                itemCode: item.itemCode,
                itemName: item.itemName,
                description: item.description,
                hsnSacCode: item.hsnSacCode,
                classification: item.classification,
                unit: item.unit,
                quantity: item.quantity,
                freeQuantity: item.freeQuantity ?? 0,
                mrp: item.mrp,
                sellingPrice: item.sellingPrice,
                unitPrice: item.unitPrice,
                discountType: item.discountType,
                discountValue: item.discountValue,
                discountAmount: item.discountAmount,
                taxableAmount: item.taxableAmount,
                gstRate: item.gstRate,
                cgstRate: item.cgstRate,
                cgstAmount: item.cgstAmount,
                sgstRate: item.sgstRate,
                sgstAmount: item.sgstAmount,
                igstRate: item.igstRate,
                igstAmount: item.igstAmount,
                cessRate: item.cessRate,
                cessAmount: item.cessAmount,
                lineTotal: item.lineTotal,
                batchNumber: item.batchNumber,
                serialNumber: item.serialNumber,
                expiryDate: item.expiryDate,
                isTaxInclusive: item.isTaxInclusive,
                remarks: item.remarks
            }))
        );

        const invoice = await salesInvoiceRepository.finalize(tx, draft.id, {

            customerId: payload.customerId,
            buyerName: payload.buyerName,
            buyerCompanyName: payload.buyerCompanyName,
            buyerGSTIN: payload.buyerGSTIN,
            buyerPAN: payload.buyerPAN,
            buyerPhone: payload.buyerPhone,
            buyerEmail: payload.buyerEmail,
            buyerType: payload.buyerType,

            billingAddressLine1: payload.billingAddressLine1,
            billingAddressLine2: payload.billingAddressLine2,
            billingCity: payload.billingCity,
            billingState: payload.billingState,
            billingStateCode: payload.billingStateCode,
            billingPincode: payload.billingPincode,
            billingCountry: payload.billingCountry,

            shippingAddressLine1: payload.shippingAddressLine1,
            shippingAddressLine2: payload.shippingAddressLine2,
            shippingCity: payload.shippingCity,
            shippingState: payload.shippingState,
            shippingStateCode: payload.shippingStateCode,
            shippingPincode: payload.shippingPincode,
            shippingCountry: payload.shippingCountry,

            invoiceDate: new Date(payload.invoiceDate),
            invoiceType: payload.invoiceType,
            placeOfSupply: payload.placeOfSupply,
            placeOfSupplyCode: payload.placeOfSupplyCode,
            reverseCharge: payload.reverseCharge,
            isExport: payload.isExport,
            isSEZ: payload.isSEZ,
            currency: payload.currency,
            exchangeRate: payload.exchangeRate,

            invoiceNumber,
            taxType: calculatedInvoice.taxType,

            totalItems: calculatedInvoice.summary.totalItems,
            totalQuantity: calculatedInvoice.summary.totalQuantity,
            taxableAmount: calculatedInvoice.summary.taxableAmount,
            discountAmount: calculatedInvoice.summary.discountAmount,
            cgstAmount: calculatedInvoice.summary.cgstAmount,
            sgstAmount: calculatedInvoice.summary.sgstAmount,
            igstAmount: calculatedInvoice.summary.igstAmount,
            cessAmount: calculatedInvoice.summary.cessAmount,
            roundOffAmount: calculatedInvoice.summary.roundOffAmount,
            grandTotal: calculatedInvoice.summary.grandTotal,

            paidAmount,
            pendingAmount,

            notes: payload.notes,
            termsAndConditions: payload.termsAndConditions,

            invoiceStatus: InvoiceStatus.ISSUED,
            updatedBy: payload.updatedBy

        } as Prisma.SalesInvoiceUpdateInput);

        // Payment creation will be added later.

        return invoice;

    });
};

//Save or generate invoice directly without draft
export const saveInvoice = async (payload: any) => {

    validateInvoice(payload, payload.items);

    const calculatedInvoice = calculateInvoice(payload, payload.items);

    validateCalculatedInvoice(payload, calculatedInvoice);

    const redeemRewardPoints = Number(payload.redeemRewardPoints ?? 0);

    return prisma.$transaction(async (tx) => {

        const invoiceNumber = await generateDocumentNumber(
            tx,
            payload.businessId,
            payload.branchId ?? "",
            DocumentType.SALES_INVOICE
        );       
        // ---------------------------------------------
        // Reward Redemption
        // ---------------------------------------------
        let rewardRedemption = {
            points: 0,
            value: 0,
            // pointValue: 0
        };

        if (redeemRewardPoints > 0) {

            if (!payload.customerId)
                throw new ConflictError(
                    "Customer is required for reward redemption."
                );

            rewardRedemption =
                await calculateRewardRedemption({
                    tx,
                    businessId: payload.businessId,
                    branchId: payload.branchId,
                    customerId: payload.customerId,
                    points: redeemRewardPoints,
                    invoiceAmount:
                        calculatedInvoice.summary.grandTotal
                });
        }

        // const paidAmount = Number(payload.paidAmount ?? 0);
        // const pendingAmount = calculatedInvoice.summary.grandTotal - paidAmount;

        // ---------------------------------------------
        // Final Invoice Amount
        // ---------------------------------------------
        const finalGrandTotal = Number(
            (
                calculatedInvoice.summary.grandTotal -
                rewardRedemption.value
            ).toFixed(2)
        );

        if (finalGrandTotal < 0)
            throw new ConflictError(
                "Reward discount cannot exceed invoice amount."
            );

        const paidAmount =
            Number(payload.paidAmount ?? 0);

        if (paidAmount > finalGrandTotal)
            throw new ConflictError(
                "Paid amount cannot exceed invoice total."
            );

        const pendingAmount = Number(
            (finalGrandTotal - paidAmount).toFixed(2)
        );
        // ---------------------------------------------
        // Invoice Status
        // ---------------------------------------------
        let invoiceStatus: InvoiceStatus = InvoiceStatus.ISSUED;

        if (paidAmount >= finalGrandTotal)
            invoiceStatus = InvoiceStatus.PAID;
        else if (paidAmount > 0)
            invoiceStatus = InvoiceStatus.PARTIALLY_PAID;
        
        // ---------------------------------------------
        // Create Invoice
        // ---------------------------------------------
        const invoice = await salesInvoiceRepository.create(tx, {

            businessId: payload.businessId,
            branchId: payload.branchId,

            createdBy: payload.createdBy,
            updatedBy: payload.updatedBy,

            invoiceNumber,
            financialYear: generateFinancialYear(),
            invoiceStatus: invoiceStatus,

            invoiceDate: new Date(payload.invoiceDate),
            invoiceType: payload.invoiceType,
            invoiceSource: payload.invoiceSource,

            sellerLegalName: payload.sellerLegalName,
            sellerTradeName: payload.sellerTradeName,
            sellerGSTIN: payload.sellerGSTIN,
            sellerPAN: payload.sellerPAN,
            sellerPhone: payload.sellerPhone,
            sellerEmail: payload.sellerEmail,
            sellerAddressLine1: payload.sellerAddressLine1,
            sellerAddressLine2: payload.sellerAddressLine2,
            sellerCity: payload.sellerCity,
            sellerState: payload.sellerState,
            sellerStateCode: payload.sellerStateCode,
            sellerPincode: payload.sellerPincode,
            sellerCountry: payload.sellerCountry,

            customerId: payload.customerId,
            buyerName: payload.buyerName,
            buyerCompanyName: payload.buyerCompanyName,
            buyerGSTIN: payload.buyerGSTIN,
            buyerPAN: payload.buyerPAN,
            buyerPhone: payload.buyerPhone,
            buyerEmail: payload.buyerEmail,
            buyerType: payload.buyerType,

            billingAddressLine1: payload.billingAddressLine1,
            billingAddressLine2: payload.billingAddressLine2,
            billingCity: payload.billingCity,
            billingState: payload.billingState,
            billingStateCode: payload.billingStateCode,
            billingPincode: payload.billingPincode,
            billingCountry: payload.billingCountry,

            shippingAddressLine1: payload.shippingAddressLine1,
            shippingAddressLine2: payload.shippingAddressLine2,
            shippingCity: payload.shippingCity,
            shippingState: payload.shippingState,
            shippingStateCode: payload.shippingStateCode,
            shippingPincode: payload.shippingPincode,
            shippingCountry: payload.shippingCountry,

            placeOfSupply: payload.placeOfSupply,
            placeOfSupplyCode: payload.placeOfSupplyCode,

            reverseCharge: payload.reverseCharge,
            isExport: payload.isExport,
            isSEZ: payload.isSEZ,

            currency: payload.currency,
            exchangeRate: payload.exchangeRate,

            taxType: calculatedInvoice.taxType,

            totalItems: calculatedInvoice.summary.totalItems,
            totalQuantity: calculatedInvoice.summary.totalQuantity,
            taxableAmount: calculatedInvoice.summary.taxableAmount,
            discountAmount: calculatedInvoice.summary.discountAmount,
            cgstAmount: calculatedInvoice.summary.cgstAmount,
            sgstAmount: calculatedInvoice.summary.sgstAmount,
            igstAmount: calculatedInvoice.summary.igstAmount,
            cessAmount: calculatedInvoice.summary.cessAmount,
            roundOffAmount: calculatedInvoice.summary.roundOffAmount,
            rewardPointsRedeemed:rewardRedemption.points,
            rewardDiscountAmount: rewardRedemption.value,
            grandTotal: finalGrandTotal,

            paidAmount,
            pendingAmount,

            notes: payload.notes,
            termsAndConditions: payload.termsAndConditions

        } as Prisma.SalesInvoiceCreateInput);

        await salesInvoiceItemRepository.bulkCreate(
            tx,
            invoice.id,
            payload.items
        );

        // Payment
        // Inventory
        // Ledger
        // E-Invoice
        // will be integrated later.

        // ---------------------------------------------
        // Customer Ledger
        // ---------------------------------------------
        if (!invoice.customerId)
            throw new ValidationError("Customer not found.");

        await postCustomerLedger({
            tx,
            businessId: invoice.businessId,
            branchId: invoice.branchId ?? undefined,
            customerId: invoice.customerId,
            documentType: LedgerDocumentType.SALES_INVOICE,
            documentId: invoice.id,
            documentNumber: invoice.invoiceNumber!,
            debit: Number(invoice.grandTotal),
            credit: 0,
            transactionDate: invoice.invoiceDate ?? new Date(),
            remarks: `Sales Invoice ${invoice.invoiceNumber}`,
            createdBy: invoice.createdBy
        });
        // ---------------------------------------------
        // Earn Reward Points
        // Based on actual amount spent
        // ---------------------------------------------
        await postEarnedReward({
            tx,
            businessId: invoice.businessId,
            branchId: invoice.branchId!,
            customerId: invoice.customerId!,
            invoiceId: invoice.id,
            invoiceNumber: invoice.invoiceNumber!,
            invoiceAmount: Number(invoice.grandTotal),
            createdBy: invoice.createdBy
        });

        return invoice;
    });
};

export const getInvoiceById = async (id: string) => {

    const invoice = await salesInvoiceRepository.findIssuedById(id);
    if (!invoice)
        throw new NotFoundError("Sales Invoice not found.");

    return invoice;
};

export const getInvoices = async (businessId: string,page: number,limit: number,search?: string,status?: InvoiceStatus) => {
    
    const invoices = await salesInvoiceRepository.findInvoices( businessId, page, limit, search, status );
    const total = await salesInvoiceRepository.countInvoices( businessId, search,status);

    return {
        data: invoices,
        pagination: {
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit)
        }
    };
};

//cancel Invoice
export const cancelInvoice = async (id: string,updatedBy: string) => {

    const invoice = await salesInvoiceRepository.findIssuedById(id);

    if (!invoice)
        throw new NotFoundError("Sales Invoice not found.");

    if (invoice.invoiceStatus === InvoiceStatus.CANCELLED)
        throw new ConflictError("Invoice already cancelled.");

    if (invoice.invoiceStatus === InvoiceStatus.PAID)
        throw new ConflictError("Paid invoice cannot be cancelled.");

    return prisma.$transaction(async (tx) => {

        const cancelledInvoice = await salesInvoiceRepository.cancel(
            tx,
            id,
            updatedBy
        );

        // TODO Restore Inventory

        // TODO Reverse Ledger

        // TODO Reverse Loyalty

        // return salesInvoiceRepository.cancel(
        //     tx,
        //     id,
        //     updatedBy
        // );

        if (cancelledInvoice.customerId) {
            await postCustomerLedger({
                tx,
                businessId: cancelledInvoice.businessId,
                branchId: cancelledInvoice.branchId ?? undefined,
                customerId: cancelledInvoice.customerId,
                documentType: LedgerDocumentType.SALES_INVOICE,
                documentId: cancelledInvoice.id,
                documentNumber: cancelledInvoice.invoiceNumber!,
                debit: 0,
                credit: Number(cancelledInvoice.grandTotal),
                transactionDate: new Date(),
                remarks: `Cancellation of Sales Invoice ${cancelledInvoice.invoiceNumber}`,
                createdBy: updatedBy
            });
        }
        // TODO Reverse Loyalty
        return cancelledInvoice;
    });    
};