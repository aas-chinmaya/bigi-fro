import {
    InvoiceStatus,
    LedgerDocumentType,
    PaymentStatus,
    PaymentDocumentType,
    Prisma
} from "@prisma/client";

import prisma from "../../../config/db";
import * as paymentRepository from "../repository/payment.repository";
import * as salesInvoiceRepository from "../../sales/repository/salesInvoice.repository";

import NotFoundError from "../../../common/exceptions/NotFoundError";
import ConflictError from "../../../common/exceptions/ConflictError";
import ValidationError from "../../../common/exceptions/ValidationError";

import { generatePaymentNumber } from "../helpers/paymentNumber.helper";
import { postCustomerLedger } from "../../customers/helpers/customerLedger.helper";
import { createPaymentValidator } from "../validators/createPayment.validator";



// ============================================================
// CREATE PAYMENT
// ============================================================

export const createPayment = async (payload: any) => {

    const validatedPayload = createPaymentValidator.parse(payload);
    const {
        businessId,
        branchId,
        invoiceId,
        customerId,
        amount,
        paymentMethod,
        paymentDate,
        transactionReference,
        remarks,
        createdBy
    } = validatedPayload;

    const paymentAmount = Number(amount);

    if (!paymentAmount || paymentAmount <= 0) {
        throw new ValidationError(
            "Payment amount must be greater than zero."
        );
    }

    return prisma.$transaction(async (tx) => {

        // =====================================================
        // FIND INVOICE
        // =====================================================
        if(!invoiceId) {
            throw new ValidationError("Invoice ID is required.");
        }
        const invoice =
            await salesInvoiceRepository.findIssuedById(invoiceId);

        if (!invoice) {
            throw new NotFoundError("Sales Invoice not found.");
        }

        // =====================================================
        // BUSINESS VALIDATION
        // =====================================================
        if (invoice.businessId !== businessId) {
            throw new ValidationError("Invoice does not belong to this business." );
        }

        if (invoice.invoiceStatus === InvoiceStatus.CANCELLED) {
            throw new ConflictError("Payment cannot be recorded against a cancelled invoice.");
        }

        // =====================================================
        // CUSTOMER VALIDATION
        // =====================================================
        if (!invoice.customerId) {
            throw new ValidationError("Invoice does not have a customer.");
        }

        if (customerId &&customerId !== invoice.customerId) {
            throw new ValidationError("Payment customer does not match invoice customer.");
        }

        // =====================================================
        // CALCULATE CURRENT SUCCESSFUL PAYMENTS
        // =====================================================
        const successfulPaidAmount =
            await paymentRepository.getSuccessfulPaymentTotalByInvoiceId(tx, invoiceId );

        const invoiceTotal = Number(invoice.grandTotal);

        const pendingAmount = Number( (invoiceTotal - successfulPaidAmount).toFixed(2) );

        // =====================================================
        // PREVENT OVER PAYMENT
        // =====================================================
        if (paymentAmount > pendingAmount) {
            throw new ConflictError( `Payment amount cannot exceed pending amount of ${pendingAmount}.` );
        }

        // =====================================================
        // GENERATE PAYMENT NUMBER
        // =====================================================
        const paymentNumber =
            await generatePaymentNumber(
                tx,
                businessId,
                branchId ?? ""
            );

        // =====================================================
        // CREATE PAYMENT
        // =====================================================

        const payment = await paymentRepository.create(tx, {
            businessId: payload.businessId,
            branchId: payload.branchId,
            customer: {
                connect: {
                    id: payload.customerId
                }
            },
            paymentNumber,
            amount: payload.amount,
            paymentMethod: payload.paymentMethod,
            paymentStatus: PaymentStatus.SUCCESS,
            paymentDate: new Date(payload.paymentDate),
            documentType: PaymentDocumentType.SALES_INVOICE,
            documentNumber: payload.documentNumber,
            transactionReference: payload.transactionReference,
            remarks: payload.remarks,
            createdBy: payload.createdBy
        } as Prisma.PaymentCreateInput);

        // =====================================================
        // CALCULATE NEW INVOICE PAYMENT SUMMARY
        // =====================================================

        const newPaidAmount = Number( ( successfulPaidAmount + paymentAmount ).toFixed(2) );

        const newPendingAmount = Number( ( invoiceTotal - newPaidAmount ).toFixed(2) );

        // =====================================================
        // DETERMINE INVOICE STATUS
        // =====================================================
        let invoiceStatus: InvoiceStatus = InvoiceStatus.ISSUED;

        if (newPaidAmount >= invoiceTotal) {
            invoiceStatus = InvoiceStatus.PAID;
        } else if (newPaidAmount > 0) {
            invoiceStatus = InvoiceStatus.PARTIALLY_PAID;
        }

        // =====================================================
        // UPDATE INVOICE PAYMENT SUMMARY
        // =====================================================
        await salesInvoiceRepository.update(
            tx,
            invoiceId,
            {
                paidAmount: newPaidAmount,
                pendingAmount: newPendingAmount,
                invoiceStatus
            } as Prisma.SalesInvoiceUpdateInput
        );

        // =====================================================
        // CUSTOMER LEDGER
        // =====================================================

        await postCustomerLedger({
            tx,
            businessId,
            branchId: branchId ?? undefined,
            customerId: invoice.customerId,
            documentType: LedgerDocumentType.PAYMENT_RECEIPT,
            documentId: payment.id,
            documentNumber: payment.paymentNumber,
            debit: 0,
            credit: paymentAmount,
            transactionDate: payment.paymentDate,
            remarks: `Payment received against Sales Invoice ${invoice.invoiceNumber}`,
            createdBy
        });
        return payment;
    });
};


// ============================================================
// GET PAYMENT BY ID
// ============================================================

export const getPaymentById = async (id: string) => {
    const payment =
        await prisma.$transaction(async (tx) => {
            return paymentRepository.findById( tx, id);
        });

    if (!payment) {
        throw new NotFoundError( "Payment not found.");
    }
    return payment;
};


// ============================================================
// GET PAYMENT WITH INVOICE
// ============================================================

export const getPaymentWithInvoice = async (
    id: string
) => {

    const payment =
        await prisma.$transaction(async (tx) => {

            return paymentRepository.findByIdWithInvoice(
                tx,
                id
            );
        });

    if (!payment) {
        throw new NotFoundError(
            "Payment not found."
        );
    }

    return payment;
};


// ============================================================
// GET PAYMENTS FOR INVOICE
// ============================================================

export const getInvoicePayments = async (
    invoiceId: string
) => {

    return prisma.$transaction(async (tx) => {

        return paymentRepository.findByInvoiceId(
            tx,
            invoiceId
        );
    });
};


// ============================================================
// GET ALL PAYMENT HISTORY FOR INVOICE
// ============================================================

export const getInvoicePaymentHistory = async (
    invoiceId: string
) => {

    return prisma.$transaction(async (tx) => {

        return paymentRepository.findAllByInvoiceId(
            tx,
            invoiceId
        );
    });
};


// ============================================================
// GET CUSTOMER PAYMENTS
// ============================================================

export const getCustomerPayments = async (
    businessId: string,
    customerId: string,
    page: number,
    limit: number
) => {

    return prisma.$transaction(async (tx) => {

        const payments =
            await paymentRepository.findByCustomerId(
                tx,
                businessId,
                customerId,
                page,
                limit
            );

        const total =
            await paymentRepository.countByCustomerId(
                tx,
                businessId,
                customerId
            );

        return {
            data: payments,

            pagination: {
                page,
                limit,
                total,
                totalPages:
                    Math.ceil(total / limit)
            }
        };
    });
};