import prisma from "../../../config/db";
import { PaymentDocumentType, PaymentMethod, PaymentStatus, PaymentGateway, InvoiceStatus, Prisma, } from "@prisma/client";
import NotFoundError from "../../../common/exceptions/NotFoundError";
import ValidationError from "../../../common/exceptions/ValidationError";
import ConflictError from "../../../common/exceptions/ConflictError";
import * as paymentRepository from "../repository/payment.repository";
import { generatePaymentNumber } from "../helpers/paymentNumber.helper";
import razorpay from "../../../config/razorpay";

// ============================================================
// Types
// ============================================================
interface CreatePaymentPayload {
    businessId: string;
    branchId: string;
    customerId: string;
    invoiceNumber: string;
    amount: number;
    paymentMethod: PaymentMethod;
    paymentDate?: string;
    transactionReference?: string;
    remarks?: string;
    createdBy: string;
}

// ============================================================
// Main Payment Entry Point
// ============================================================
export const createPayment = async (payload: CreatePaymentPayload) => {
    validatePaymentPayload(payload);

    return prisma.$transaction(async (tx) => {
        const invoice = await findAndValidateInvoice(tx, payload);

        const grandTotal = Number(invoice.grandTotal);
        const alreadyPaid = Number(invoice.paidAmount ?? 0);
        const pendingAmount = grandTotal - alreadyPaid;

        if (pendingAmount <= 0) {
            throw new ConflictError("No outstanding amount exists for this invoice.");
        }

        if (payload.amount > pendingAmount) {
            throw new ConflictError(
                `Payment amount cannot exceed pending amount of ${pendingAmount}.`
            );
        }

        switch (payload.paymentMethod) {
            case PaymentMethod.CASH:
            case PaymentMethod.CARD:
                return processManualPayment(tx, invoice, payload);

            case PaymentMethod.UPI:
                return processUpiPayment(tx, invoice, payload);

            default:
                throw new ValidationError("Unsupported payment method.");
        }
    });
};

// ============================================================
// Validate Payment Payload
// ============================================================
const validatePaymentPayload = (payload: CreatePaymentPayload) => {
    if (!payload.businessId) {
        throw new ValidationError("Business ID is required.");
    }

    if (!payload.branchId) {
        throw new ValidationError("Branch ID is required.");
    }

    if (!payload.customerId) {
        throw new ValidationError("Customer ID is required.");
    }

    if (!payload.invoiceNumber) {
        throw new ValidationError("Invoice number is required.");
    }

    if (!payload.amount || payload.amount <= 0) {
        throw new ValidationError("Payment amount must be greater than zero.");
    }

    if (!payload.paymentMethod) {
        throw new ValidationError("Payment method is required.");
    }
};

// ============================================================
// Find & Validate Invoice
// ============================================================
const findAndValidateInvoice = async (
    tx: Prisma.TransactionClient,
    payload: CreatePaymentPayload
) => {
    const invoice = await tx.salesInvoice.findFirst({
        where: {
            businessId: payload.businessId,
            branchId: payload.branchId,
            invoiceNumber: payload.invoiceNumber,
        },
    });

    if (!invoice) {
        throw new NotFoundError("Sales Invoice not found.");
    }

    if (invoice.invoiceStatus === InvoiceStatus.CANCELLED) {
        throw new ConflictError( "Payment cannot be made against a cancelled invoice.");
    }

    if (invoice.invoiceStatus === InvoiceStatus.PAID) {
        throw new ConflictError("Invoice is already fully paid.");
    }

    if (!invoice.customerId) {
        throw new ConflictError("Customer is not associated with this invoice.");
    }

    if (invoice.customerId !== payload.customerId) {
        throw new ConflictError("Payment customer does not match invoice customer.");
    }

    return invoice;
};

// ============================================================
// CASH / CARD
// ============================================================
const processManualPayment = async (
    tx: Prisma.TransactionClient,
    invoice: any,
    payload: CreatePaymentPayload
) => {
    const paymentNumber = await generatePaymentNumber(
        tx,
        payload.businessId,
        payload.branchId
    );

    // --------------------------------------------------------
    // Create successful payment
    // --------------------------------------------------------
    const payment = await paymentRepository.create(tx, {
        businessId: payload.businessId,
        branchId: payload.branchId,
        customer: {
            connect: {
                id: payload.customerId,
            },
        },
        paymentNumber,
        amount: payload.amount,
        paymentMethod: payload.paymentMethod,
        paymentStatus: PaymentStatus.SUCCESS,
        paymentDate: payload.paymentDate
            ? new Date(payload.paymentDate)
            : new Date(),
        documentType: PaymentDocumentType.SALES_INVOICE,
        documentNumber: invoice.invoiceNumber!,
        transactionReference: payload.transactionReference,
        remarks: payload.remarks,
        createdBy: payload.createdBy,
    });

    // --------------------------------------------------------
    // Update Invoice
    // --------------------------------------------------------
    return updateInvoiceAfterSuccessfulPayment(
        tx,
        invoice,
        payload.amount,
        payment
    );
};


// ============================================================
// UPI / Razorpay
// ============================================================
const processUpiPayment = async (
    tx: Prisma.TransactionClient,
    invoice: any,
    payload: CreatePaymentPayload
) => {
    const paymentNumber = await generatePaymentNumber(
        tx,
        payload.businessId,
        payload.branchId
    );

    // --------------------------------------------------------
    // Razorpay expects paise
    // --------------------------------------------------------
    const amountInPaise = Math.round(payload.amount * 100);

    // --------------------------------------------------------
    // Create Razorpay order
    // --------------------------------------------------------
    const razorpayOrder = await razorpay.orders.create({
        amount: amountInPaise,
        currency: "INR",
        receipt: paymentNumber,
        notes: {
            businessId: payload.businessId,
            branchId: payload.branchId,
            customerId: payload.customerId,
            invoiceNumber: invoice.invoiceNumber!,
            paymentNumber,
        },
    });

    // --------------------------------------------------------
    // Create local payment as PENDING
    // --------------------------------------------------------
    const payment = await paymentRepository.create(tx, {
        businessId: payload.businessId,
        branchId: payload.branchId,
        customer: {
            connect: {
                id: payload.customerId,
            },
        },
        paymentNumber,
        amount: payload.amount,
        paymentMethod: PaymentMethod.UPI,
        paymentStatus: PaymentStatus.PENDING,
        paymentDate: new Date(),
        documentType: PaymentDocumentType.SALES_INVOICE,
        documentNumber: invoice.invoiceNumber!,
        paymentGateway: PaymentGateway.RAZORPAY,
        gatewayOrderId: razorpayOrder.id,
        createdBy: payload.createdBy,
    });

    // --------------------------------------------------------
    // IMPORTANT:
    // Invoice is NOT updated here.
    // Payment is still PENDING.
    // Razorpay verification/webhook will handle SUCCESS.
    // --------------------------------------------------------
    return {
        payment,
        razorpay: {
            orderId: razorpayOrder.id,
            amount: razorpayOrder.amount,
            currency: razorpayOrder.currency,
        },
        invoice: {
            id: invoice.id,
            invoiceNumber: invoice.invoiceNumber,
            grandTotal: Number(invoice.grandTotal),
            alreadyPaid: Number(invoice.paidAmount ?? 0),
            pendingAmount:
                Number(invoice.grandTotal) -
                Number(invoice.paidAmount ?? 0),
        },
    };
};


// ============================================================
// Update Invoice After Successful Payment
// ============================================================
const updateInvoiceAfterSuccessfulPayment = async (
    tx: Prisma.TransactionClient,
    invoice: any,
    paymentAmount: number,
    payment: any
) => {
    const grandTotal = Number(invoice.grandTotal);
    const alreadyPaid = Number(invoice.paidAmount ?? 0);
    const newPaidAmount = alreadyPaid + paymentAmount;
    const newPendingAmount = Math.max(0, grandTotal - newPaidAmount);

    let invoiceStatus: InvoiceStatus = invoice.invoiceStatus;

    if (newPaidAmount >= grandTotal) {
        invoiceStatus = InvoiceStatus.PAID;
    } else if (newPaidAmount > 0) {
        invoiceStatus = InvoiceStatus.PARTIALLY_PAID;
    }

    const updatedInvoice = await tx.salesInvoice.update({
        where: {
            id: invoice.id,
        },
        data: {
            paidAmount: newPaidAmount,
            pendingAmount: newPendingAmount,
            invoiceStatus,
            updatedBy: payment.createdBy,
        },
    });

    return {
        payment,
        invoice: {
            id: updatedInvoice.id,
            invoiceNumber: updatedInvoice.invoiceNumber,
            grandTotal,
            previousPaidAmount: alreadyPaid,
            paidAmount: newPaidAmount,
            pendingAmount: newPendingAmount,
            invoiceStatus,
        },
    };
};