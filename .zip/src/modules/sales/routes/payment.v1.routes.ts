import express from "express";
const router = express.Router();
import * as paymentController from "../controllers/payment.controller";

router.post("/record-payment", paymentController.createPayment);
router.get("/:id", paymentController.getPaymentById);
router.get("/:id/invoice", paymentController.getPaymentWithInvoice);
router.get("/invoice/:invoiceId", paymentController.getInvoicePayments);
router.get("/invoice/:invoiceId/history", paymentController.getInvoicePaymentHistory);
router.get("/customer/:customerId", paymentController.getCustomerPayments);

export default router; 