import { Prisma, SalesInvoice, InvoiceStatus } from "@prisma/client";
import prisma from "../../../config/db";

//Create Sales Invoice Draft
export const create = async (
    tx: Prisma.TransactionClient,
    data: Prisma.SalesInvoiceUncheckedCreateInput
): Promise<SalesInvoice> => {
    return tx.salesInvoice.create({
        data,
        include: {
            items: true
        }
    });
};


//Find Draft By Id
export const findById = async (id: string): Promise<SalesInvoice | null> => {
    return prisma.salesInvoice.findFirst({
        where: {
            id,
            deletedAt: null
        },
        include: {
            items: true,
            customer: true
        }
    });
};


//Find Draft By Business + Invoice Number
export const findByInvoiceNumber = async (businessId: string, financialYear: string, invoiceNumber: string): Promise<SalesInvoice | null> => {
    return prisma.salesInvoice.findFirst({
        where: {
            businessId,
            financialYear,
            invoiceNumber,
            deletedAt: null
        }
    });
};


//List Drafts
export const findMany = async (businessId: string,page: number,limit: number): Promise<SalesInvoice[]> => {

    const skip = (page - 1) * limit;
    return prisma.salesInvoice.findMany({
        where: {
            businessId,
            invoiceStatus: InvoiceStatus.DRAFT,
            deletedAt: null
        },

        include: {
            customer: true,
            items: true
        },

        orderBy: {
            createdAt: "desc"
        },
        skip,
        take: limit
    });
};


// Update Draft
export const update = async (tx: Prisma.TransactionClient,id: string,data: Prisma.SalesInvoiceUpdateInput): Promise<SalesInvoice> => {
    return tx.salesInvoice.update({
        where: {id},
        data
    });
};


//Soft Delete Draft
export const remove = async (tx: Prisma.TransactionClient,id: string): Promise<SalesInvoice> => {
    return tx.salesInvoice.update({
        where: {id},
        data: {
            deletedAt: new Date()
        }
    });
};

// Count Drafts
export const count = async ( businessId: string): Promise<number> => {
    return prisma.salesInvoice.count({
        where: {
            businessId,
            invoiceStatus: InvoiceStatus.DRAFT,
            deletedAt: null
        }
    });
};

export const findByIdTx = async (tx: Prisma.TransactionClient, id: string): Promise<SalesInvoice | null> => {
    return tx.salesInvoice.findFirst({
        where: { id, deletedAt: null },
        include: { customer: true, items: true }
    });
};

export const finalize = async (tx: Prisma.TransactionClient, id: string, data: Prisma.SalesInvoiceUpdateInput): Promise<SalesInvoice> => {
    return tx.salesInvoice.update({
        where: { id },
        data,
        include: { customer: true, items: true }
    });
};

export const findGeneratedInvoice = async (businessId: string, invoiceNumber: string): Promise<SalesInvoice | null> => {
    return prisma.salesInvoice.findFirst({
        where: { businessId, invoiceNumber, deletedAt: null }
    });
};

export const checkDraft = async (tx: Prisma.TransactionClient, id: string): Promise<SalesInvoice | null> => {
    return tx.salesInvoice.findFirst({
        where: { id, invoiceStatus: InvoiceStatus.DRAFT, deletedAt: null },
        include: { customer: true, items: true }
    });
};

export const findIssuedById = async (id: string): Promise<SalesInvoice | null> => {
    return prisma.salesInvoice.findFirst({
        where: { id, deletedAt: null, invoiceStatus: { not: InvoiceStatus.DRAFT } },
        include: { customer: true, items: true }
    });
};

export const findInvoices = async (businessId: string,page: number,limit: number,search?: string,status?: InvoiceStatus): Promise<SalesInvoice[]> => {

    const skip = (page - 1) * limit;
    return prisma.salesInvoice.findMany({
        where: {
            businessId,
            deletedAt: null,
            invoiceStatus: status,
            OR: search ? [
                { invoiceNumber: { contains: search, mode: "insensitive" } },
                { buyerName: { contains: search, mode: "insensitive" } },
                { buyerPhone: { contains: search, mode: "insensitive" } }
            ] : undefined
        },
        include: { customer: true },
        orderBy: { invoiceDate: "desc" },
        skip,
        take: limit
    });
};

export const countInvoices = async (businessId: string,search?: string,status?: InvoiceStatus): Promise<number> => {
    return prisma.salesInvoice.count({
        where: {
            businessId,
            deletedAt: null,
            invoiceStatus: status,
            OR: search ? [
                { invoiceNumber: { contains: search, mode: "insensitive" } },
                { buyerName: { contains: search, mode: "insensitive" } },
                { buyerPhone: { contains: search, mode: "insensitive" } }
            ] : undefined
        }
    });
};

//cancel invoice 
export const cancel = async ( tx: Prisma.TransactionClient, id: string, updatedBy: string): Promise<SalesInvoice> => {
    return tx.salesInvoice.update({
        where: { id },
        data: {
            invoiceStatus: InvoiceStatus.CANCELLED,
            updatedBy
        }
    });
};