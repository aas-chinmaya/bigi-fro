import { Prisma } from "@prisma/client";


// ============================================================
// CREATE
// ============================================================

export const create = async (
    tx: Prisma.TransactionClient,
    data: Prisma.PaymentCreateInput
) => {
    return tx.payment.create({
        data
    });
};


// ============================================================
// FIND BY ID
// ============================================================

export const findById = async (
    tx: Prisma.TransactionClient,
    id: string
) => {
    return tx.payment.findUnique({
        where: {
            id
        }
    });
};


// ============================================================
// FIND BY PAYMENT NUMBER
// ============================================================

export const findByPaymentNumber = async (
    tx: Prisma.TransactionClient,
    businessId: string,
    paymentNumber: string
) => {
    return tx.payment.findFirst({
        where: {
            businessId,
            paymentNumber
        }
    });
};


// ============================================================
// FIND PAYMENT BY ID WITH INVOICE
// ============================================================

export const findByIdWithInvoice = async (
    tx: Prisma.TransactionClient,
    id: string
) => {
    return tx.payment.findUnique({
        where: {
            id
        },
        include: {
            invoice: true
        }
    });
};


// ============================================================
// FIND PAYMENTS FOR INVOICE
// ============================================================

export const findByInvoiceId = async (
    tx: Prisma.TransactionClient,
    invoiceId: string
) => {
    return tx.payment.findMany({
        where: {
            invoiceId,
            paymentStatus: "SUCCESS",
            deletedAt: null
        },
        orderBy: {
            paymentDate: "asc"
        }
    });
};


// ============================================================
// FIND ALL PAYMENTS FOR INVOICE
// ============================================================
//
// This includes PENDING / FAILED / CANCELLED payments.
// Useful for payment history/audit screens.
//

export const findAllByInvoiceId = async (
    tx: Prisma.TransactionClient,
    invoiceId: string
) => {
    return tx.payment.findMany({
        where: {
            invoiceId,
            deletedAt: null
        },
        orderBy: {
            paymentDate: "desc"
        }
    });
};


// ============================================================
// FIND CUSTOMER PAYMENTS
// ============================================================

export const findByCustomerId = async (
    tx: Prisma.TransactionClient,
    businessId: string,
    customerId: string,
    page: number,
    limit: number
) => {
    const skip = (page - 1) * limit;

    return tx.payment.findMany({
        where: {
            businessId,
            customerId,
            deletedAt: null
        },
        orderBy: {
            paymentDate: "desc"
        },
        skip,
        take: limit
    });
};


// ============================================================
// COUNT CUSTOMER PAYMENTS
// ============================================================

export const countByCustomerId = async (
    tx: Prisma.TransactionClient,
    businessId: string,
    customerId: string
) => {
    return tx.payment.count({
        where: {
            businessId,
            customerId,
            deletedAt: null
        }
    });
};


// ============================================================
// UPDATE PAYMENT STATUS
// ============================================================

export const updateStatus = async (
    tx: Prisma.TransactionClient,
    id: string,
    paymentStatus: Prisma.PaymentUpdateInput["paymentStatus"],
    updatedBy: string
) => {
    return tx.payment.update({
        where: {
            id
        },
        data: {
            paymentStatus,
            updatedBy
        }
    });
};


// ============================================================
// UPDATE PAYMENT
// ============================================================

export const update = async (
    tx: Prisma.TransactionClient,
    id: string,
    data: Prisma.PaymentUpdateInput
) => {
    return tx.payment.update({
        where: {
            id
        },
        data
    });
};


// ============================================================
// FIND SUCCESSFUL PAYMENT TOTAL FOR INVOICE
// ============================================================
//
// This is important.
//
// Invoice.paidAmount should represent SUCCESSFUL
// payments only.
//

export const getSuccessfulPaymentTotalByInvoiceId = async (
    tx: Prisma.TransactionClient,
    invoiceId: string
) => {
    const result = await tx.payment.aggregate({
        where: {
            invoiceId,
            paymentStatus: "SUCCESS",
            deletedAt: null
        },
        _sum: {
            amount: true
        }
    });

    return Number(result._sum.amount ?? 0);
};