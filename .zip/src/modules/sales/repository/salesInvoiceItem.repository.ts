import { Prisma, SalesInvoiceItem } from "@prisma/client";

/**
 * ----------------------------------------------------------------
 * Replace Invoice Items
 * ----------------------------------------------------------------
 */
export const replaceItems = async (
    tx: Prisma.TransactionClient,
    salesInvoiceId: string,
    items: Prisma.SalesInvoiceItemCreateManyInput[]
): Promise<void> => {

    await tx.salesInvoiceItem.deleteMany({
        where: {
            salesInvoiceId
        }
    });

    if (!items.length) return;

    await tx.salesInvoiceItem.createMany({
        data: items
    });

};

/**
 * ----------------------------------------------------------------
 * Create Invoice Items
 * ----------------------------------------------------------------
 */
export const createMany = async (
    tx: Prisma.TransactionClient,
    items: Prisma.SalesInvoiceItemCreateManyInput[]
): Promise<void> => {

    if (!items.length) return;

    await tx.salesInvoiceItem.createMany({
        data: items
    });

};

/**
 * ----------------------------------------------------------------
 * Find Invoice Items
 * ----------------------------------------------------------------
 */
export const findByInvoiceId = async (
    tx: Prisma.TransactionClient,
    salesInvoiceId: string
): Promise<SalesInvoiceItem[]> => {

    return tx.salesInvoiceItem.findMany({

        where: {
            salesInvoiceId
        },

        orderBy: {
            lineNumber: "asc"
        }

    });

};

/**
 * ----------------------------------------------------------------
 * Delete Invoice Items
 * ----------------------------------------------------------------
 */
export const deleteMany = async (
    tx: Prisma.TransactionClient,
    salesInvoiceId: string
): Promise<void> => {

    await tx.salesInvoiceItem.deleteMany({

        where: {
            salesInvoiceId
        }

    });

};


export const bulkCreate = async (tx: Prisma.TransactionClient,salesInvoiceId: string,items: any[]) => {

    await tx.salesInvoiceItem.createMany({

        data: items.map((item: any, index: number) => ({

            salesInvoiceId,

            lineNumber: index + 1,

            productId: item.productId,
            itemCode: item.itemCode,
            itemName: item.itemName,
            description: item.description,
            hsnSacCode: item.hsnSacCode,
            classification: item.classification,

            unit: item.unit,
            quantity: item.quantity,
            freeQuantity: item.freeQuantity ?? 0,

            mrp: item.mrp,
            sellingPrice: item.sellingPrice,
            unitPrice: item.unitPrice,

            discountType: item.discountType,
            discountValue: item.discountValue,
            discountAmount: item.discountAmount,

            taxableAmount: item.taxableAmount,

            gstRate: item.gstRate,
            cgstRate: item.cgstRate,
            cgstAmount: item.cgstAmount,
            sgstRate: item.sgstRate,
            sgstAmount: item.sgstAmount,
            igstRate: item.igstRate,
            igstAmount: item.igstAmount,
            cessRate: item.cessRate,
            cessAmount: item.cessAmount,

            lineTotal: item.lineTotal,

            batchNumber: item.batchNumber,
            serialNumber: item.serialNumber,
            expiryDate: item.expiryDate,

            isTaxInclusive: item.isTaxInclusive,
            remarks: item.remarks
        }))
    });
};