import { DocumentType } from "@prisma/client";

export const DOCUMENT_PREFIX: Record<DocumentType, string> = {

    SALES_QUOTATION: "SQ",

    SALES_ORDER: "SO",

    SALES_INVOICE: "INV",

    DELIVERY_CHALLAN: "DC",

    SALES_RETURN: "SR",

    CREDIT_NOTE: "CN",

    DEBIT_NOTE: "DN",

    ADVANCE_RECEIPT: "AR",

    PAYMENT_RECEIPT: "RC",

    PAYMENT_VOUCHER: "PV",

    RECEIPT_VOUCHER: "RV",

};