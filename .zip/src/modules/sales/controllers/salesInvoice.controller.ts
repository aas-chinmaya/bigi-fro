import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import { InvoiceStatus } from "@prisma/client";
import * as salesInvoiceService from "../services/salesInvoice.service";

/**
 * ----------------------------------------------------------------
 * Create Draft
 * POST /sales-invoices/drafts
 * ----------------------------------------------------------------
 */
export const createDraft = asyncHandler(async (req: Request, res: Response) => {
    // Destructure mandatory top-level fields and collect all extra data into restData
    const { businessId, branchId, createdBy, invoiceType, invoiceSource, ...restData } = req.body;

    // Validate only strictly required schema fields (branchId is optional in Prisma)
    if (!businessId || !createdBy || !invoiceType || !invoiceSource) {
        return res.status(400).json({
            success: false,
            message: "Missing required fields: businessId, createdBy, invoiceType, and invoiceSource are mandatory."
        });
    }

    // Forward full payload to service
    const draft = await salesInvoiceService.createDraft({
        businessId,
        branchId,
        createdBy,
        invoiceType,
        invoiceSource,
        ...restData
    });

    return res.status(201).json({
        success: true,
        message: "Sales Invoice draft created successfully.",
        data: draft
    });
});

/**
 * ----------------------------------------------------------------
 * Get Draft By Id
 * GET /sales-invoices/drafts/:id
 * ----------------------------------------------------------------
 */
export const getDraftById = asyncHandler(async (req: Request, res: Response) => {
    const id  = req.params.id as string;

    const draft = await salesInvoiceService.getDraftById(id);

    return res.status(200).json({
        success: true,
        data: draft
    });
});

/**
 * ----------------------------------------------------------------
 * Get Draft List
 * GET /sales-invoices/drafts
 * ----------------------------------------------------------------
 */
export const getDrafts = asyncHandler(async (req: Request, res: Response) => {
    const businessId = req.query.businessId as string;
    const page = Number(req.query.page) || 1;
    const limit = Number(req.query.limit) || 20;

    const drafts = await salesInvoiceService.getDrafts(
        businessId,
        page,
        limit
    );

    return res.status(200).json({
        success: true,
        ...drafts
    });
});

/**
 * ----------------------------------------------------------------
 * Update Draft
 * PATCH /sales-invoices/drafts/:id
 * ----------------------------------------------------------------
 */
export const updateDraft = asyncHandler(async (req: Request, res: Response) => {
    const id  = req.params.id as string;

    const draft = await salesInvoiceService.updateDraft(id, req.body);

    return res.status(200).json({
        success: true,
        message: "Sales Invoice draft updated successfully.",
        data: draft
    });
});

/**
 * ----------------------------------------------------------------
 * Delete Draft
 * DELETE /sales-invoices/drafts/:id
 * ----------------------------------------------------------------
 */
export const deleteDraft = asyncHandler(async (req: Request, res: Response) => {
    const id = req.params.id as string;

    await salesInvoiceService.deleteDraft(id);

    return res.status(200).json({
        success: true,
        message: "Sales Invoice draft deleted successfully."
    });
});

/**
 * ----------------------------------------------------------------
 * Finalize Draft
 * POST /api/v1/sales-invoices/drafts/:id/finalize
 * ----------------------------------------------------------------
 */
export const finalizeDraft = asyncHandler(async (req: Request, res: Response) => {
    const draftId = req.params.id as string;

    const invoice = await salesInvoiceService.finalizeDraft(
        draftId,
        req.body
    );

    return res.status(200).json({
        success: true,
        message: "Sales Invoice finalized successfully.",
        data: invoice
    });
});

/**
 * ----------------------------------------------------------------
 * Save Invoice 
 * POST /api/v1/sales-invoices
 * ----------------------------------------------------------------
 */
export const saveInvoice = asyncHandler(async (req: Request, res: Response) => {

    const invoice = await salesInvoiceService.saveInvoice(req.body);

    return res.status(201).json({
        success: true,
        message: "Sales Invoice created successfully.",
        data: invoice
    });

});

/**
 * ----------------------------------------------------------------
 * Get Sales-Invoice By Id
 * GET /api/v1/sales-invoices/invoices/:id
 * ----------------------------------------------------------------
*/
export const getInvoiceById = asyncHandler(async (req: Request, res: Response) => {

    const id  = req.params.id as string;
    const invoice = await salesInvoiceService.getInvoiceById(id);

    return res.status(200).json({
        success: true,
        data: invoice
    });

});

/**
 * ----------------------------------------------------------------
 * Get Sales-Invoice List
 * POST /api/v1/sales-invoices/invoices
 * ----------------------------------------------------------------
*/
export const getInvoices = asyncHandler(async (req: Request, res: Response) => {

    const businessId = req.query.businessId as string;
    const page = Number(req.query.page) || 1;
    const limit = Number(req.query.limit) || 20;
    const search = req.query.search as string | undefined;
    const status = req.query.status as InvoiceStatus | undefined;

    const invoices = await salesInvoiceService.getInvoices(
        businessId,
        page,
        limit,
        search,
        status
    );

    return res.status(200).json({
        success: true,
        ...invoices
    });

});

/**
 * ----------------------------------------------------------------
 * Cancel Sales-Invoice
 * POST /api/v1/sales-invoices/invoices/:id/cancel
 * ----------------------------------------------------------------
*/
export const cancelInvoice = asyncHandler(async (req: Request, res: Response) => {

    const id = req.params.id as string;
    const invoice = await salesInvoiceService.cancelInvoice(
        id,
        req.body.updatedBy
    );

    return res.status(200).json({
        success: true,
        message: "Sales Invoice cancelled successfully.",
        data: invoice
    });
});