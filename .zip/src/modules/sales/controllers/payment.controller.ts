// import { Request, Response } from "express";
// import * as paymentService from "../services/payment2.service";

// export const createPayment = async (req: Request,res: Response) => {

//     const result = await paymentService.createPayment(req.body);

//     return res.status(201).json({
//         success: true,
//         message:
//             result.payment.paymentStatus === "PENDING"
//                 ? "Payment initiated successfully."
//                 : "Payment completed successfully.",
//         data: result,
//     });
// };


import { Request, Response } from "express";
import * as paymentService from "../services/payment.service";

export const createPayment = async (req: Request, res: Response) => {
    const result = await paymentService.createPayment(req.body);
    return res.status(201).json({
        success: true,
        message: result.paymentStatus === "PENDING" ? "Payment initiated successfully." : "Payment completed successfully.",
        data: result
    });
};

export const getPaymentById = async (req: Request, res: Response) => {
    const id = req.params.id as string; 
    const payment = await paymentService.getPaymentById(id);
    return res.status(200).json({ success: true, data: payment });
};

export const getPaymentWithInvoice = async (req: Request, res: Response) => {
    const id = req.params.id as string;
    const payment = await paymentService.getPaymentWithInvoice(id);
    return res.status(200).json({ success: true, data: payment });
};

export const getInvoicePayments = async (req: Request, res: Response) => {
    const id = req.params.invoiceId as string;
    const payments = await paymentService.getInvoicePayments(id);
    return res.status(200).json({ success: true, data: payments });
};

export const getInvoicePaymentHistory = async (req: Request, res: Response) => {
    const id = req.params.invoiceId as string;
    const payments = await paymentService.getInvoicePaymentHistory(id);
    return res.status(200).json({ success: true, data: payments });
};

export const getCustomerPayments = async (req: Request, res: Response) => {
    const customerId = req.params.customerId as string;
    const businessId = req.params.businessId as string;
    const page = Number(req.query.page ?? 1);
    const limit = Number(req.query.limit ?? 10);
    const result = await paymentService.getCustomerPayments(businessId, customerId, page, limit);
    return res.status(200).json({ success: true, ...result });
};