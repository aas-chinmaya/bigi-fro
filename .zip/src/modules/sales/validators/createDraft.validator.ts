import { z } from "zod";

export const createDraftValidator = z.object({
    body: z.looseObject({
        businessId: z
            .string({ message: "Business Id is required." })
            .trim()
            .min(1, "Business Id is required."),

        createdBy: z
            .string({ message: "Created By is required." })
            .trim()
            .min(1, "Created By is required."),

        invoiceType: z
            .string({ message: "Invoice Type is required." })
            .trim()
            .min(1, "Invoice Type is required."),

        items: z.array(z.record(z.string(), z.any())).optional()
    }),
    params: z.object({}),
    query: z.object({})
});

export type CreateDraftRequest = z.infer<typeof createDraftValidator>["body"];