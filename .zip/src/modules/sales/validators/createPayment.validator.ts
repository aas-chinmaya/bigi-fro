import { z } from "zod";
import { PaymentMethod, PaymentDocumentType } from "@prisma/client";

export const createPaymentValidator = z.object({
    businessId: z.string().min(1, "Business ID is required."),
    branchId: z.string().optional().nullable(),
    invoiceId: z.string().optional().nullable(),
    customerId: z.string().min(1, "Customer ID is required."),
    amount: z.coerce.number().positive("Payment amount must be greater than zero."),
    paymentMethod: z.nativeEnum(PaymentMethod),
    paymentDate: z.coerce.date(),
    documentType: z.nativeEnum(PaymentDocumentType),
    documentNumber: z.string().min(1, "Document number is required."),
    transactionReference: z.string().optional().nullable(),
    remarks: z.string().optional().nullable(),
    createdBy: z.string().min(1, "Created by is required.")
});

export type CreatePaymentRequest = z.infer<typeof createPaymentValidator>;