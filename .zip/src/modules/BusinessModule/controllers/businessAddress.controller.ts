import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as service from "../services/businessAddress.service";

export const createAddress = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createAddressService(req.body);

  return res.status(201).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getAddresses = asyncHandler(async (req: Request, res: Response) => {
  const tenantId = String(req.params.tenantId);
  const result = await service.getAddressesService(tenantId);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getAddressById = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  const result = await service.getAddressByIdService(id);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const updateAddress = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  const result = await service.updateAddressService(id, req.body);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const deleteAddress = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  await service.deleteAddressService(id);

  return res.status(200).json({
    success: true,
    message: "Business address deleted successfully",
  });
});