import { Router } from "express";
import * as controller from "../controllers/businessBank.controller";

const router = Router();


router.post("/", controller.createBank);


router.get(
  "/business/:businessId",
  controller.getBanks
);

router.get("/:id", controller.getBankById);


router.put("/:id", controller.updateBank);


router.delete("/:id", controller.deleteBank);

export default router;