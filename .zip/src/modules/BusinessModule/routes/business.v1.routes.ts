import { Router } from "express";
import * as controller from "../controllers/business.controller";


import  uploadFactory  from "../../../middleware/multer.middleware";
import  { compressorMiddleware } from "../../../middleware/compressor.middleware";
import { isAuthenticated  } from "../../../middleware/auth.middleware";

const router = Router();
const upload = uploadFactory("business");
// Create Business

router.post("/createBusiness", isAuthenticated, upload.fields([{ name: "logo", maxCount: 1 }]), compressorMiddleware, controller.createBusiness);

// Get All Businesses
// router.get("/getAllBusinesses", controller.getBusinesses);
router.get("/getAllBusinesses", controller.getBusinesses);

router.get("/getBusinessesByUser", isAuthenticated, controller.getBusinessesByUser);

// Get Business By Id
router.get("/getBusinessById/:id", controller.getBusinessById);

// Update Business
router.put("/updateBusiness/:id", isAuthenticated, upload.fields([{ name: "logo", maxCount: 1 }]), compressorMiddleware, controller.updateBusiness);

// Delete Business
router.delete("/deleteBusiness/:id", isAuthenticated, controller.deleteBusiness);

export default router;