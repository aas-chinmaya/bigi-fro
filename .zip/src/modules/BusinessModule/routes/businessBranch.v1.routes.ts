import { Router } from "express";

import {
  createBusinessBranch,
  getBusinessBranchById,
  getBusinessBranches,
  getAllBusinessBranches,
  updateBusinessBranch,
  deleteBusinessBranch,
} from "../controllers/businessBranch.controller";

const router = Router();

// Create
router.post(
  "/createBranch",
  createBusinessBranch
);

// Get all
router.get(
  "/allBranches",
  getAllBusinessBranches
);

// Get by business
router.get(
  "/business/:businessId",
  getBusinessBranches
);

// Get by ID
router.get(
  "/getBranchById/:id",
  getBusinessBranchById
);

// Update
router.put(
  "/updateBranch/:id",
  updateBusinessBranch
);

// Soft delete
router.delete(
  "/deleteBranch/:id",
  deleteBusinessBranch
);

export default router;