import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";
import ValidationError from "../../../common/exceptions/ValidationError";
import * as repository from "../repository/business.repository";
import prisma from "../../../config/db";
import { generateTenantId } from "../../../utils/tenant.util";
import { getFileUrl } from "../../../utils/fileUrl.util";



export const createBusinessService = async (body: any) => {
  const {
    businessType,
    gstin,
    pan,
    legalName,
    tradeName,
    displayName,
    email,
    phone,
    websiteLink,
    businessCategoryId,
    businessSubCategoryId,
    industryId,
    registrationTypeId,
    registrationNumber,
    licenseTypeId,
    tan,
    msme,
    currencyId,
    timezone,
    financialYear,
    description,
    logo,
    createdBy
  } = body;

  // ===============================
  // Required Field Validation
  // ===============================

  if (!createdBy) {
    throw new ValidationError("Created by user is required.");
  }

  if (!legalName?.trim()) {
    throw new ValidationError("Legal name is required.");
  }

  if (!displayName?.trim()) {
    throw new ValidationError("Display name is required.");
  }

  if (!businessCategoryId) {
    throw new ValidationError("Business Category is required.");
  }

  if (!businessSubCategoryId) {
    throw new ValidationError("Business Sub-Category is required.");
  }

  if (!industryId) {
    throw new ValidationError("Industry is required.");
  }

  if (!currencyId) {
    throw new ValidationError("Currency is required.");
  }

  if (!licenseTypeId) {
    throw new ValidationError("License Type is required.");
  }

  // ===============================
  // Duplicate Legal Name
  // ===============================

  const existingBusiness =
    await repository.businessExists(legalName);

  if (existingBusiness) {
    if (!existingBusiness.deletedAt) {
      throw new ConflictError("Business already exists.");
    }

    const restored = await repository.restoreBusiness(
      existingBusiness.id,
      body
    );

    return {
      status: 200,
      message: "Business restored successfully.",
      data: restored,
    };
  }

  // ===============================
  // GST Validation
  // ===============================

  if (gstin) {
    const gstExists =
      await repository.findByGSTIN(gstin);

    if (gstExists && !gstExists.deletedAt) {
      throw new ConflictError("GSTIN already exists.");
    }
  }

  // ===============================
  // PAN Validation
  // ===============================

  if (pan) {
    const panExists =
      await repository.findByPAN(pan);

    if (panExists && !panExists.deletedAt) {
      throw new ConflictError("PAN already exists.");
    }
  }

  // ===============================
  // Category Validation
  // ===============================

  const category =
    await prisma.category.findFirst({
      where: {
        id: businessCategoryId,
        isDeleted: false,
      },
    });

  if (!category) {
    throw new NotFoundError(
      "Business Category not found."
    );
  }

  const subCategory =
    await prisma.subCategory.findFirst({
      where: {
        id: businessSubCategoryId,
        isDeleted: false,
      },
    });

  if (!subCategory) {
    throw new NotFoundError(
      "Business Sub-Category not found."
    );
  }

  // ===============================
  // Industry Validation
  // ===============================

  const industry =
    await prisma.industry.findFirst({
      where: {
        id: industryId,
        isDeleted: false,
      },
    });

  if (!industry) {
    throw new NotFoundError(
      "Industry not found."
    );
  }

  // ===============================
  // Currency Validation
  // ===============================

  const currency =
    await prisma.currency.findFirst({
      where: {
        id: currencyId,
        isDeleted: false,
      },
    });

  if (!currency) {
    throw new NotFoundError(
      "Currency not found."
    );
  }

  // ===============================
  // Registration Type Validation
  // ===============================

  if (registrationTypeId) {
    const registration =
      await prisma.registrationType.findFirst({
        where: {
          id: registrationTypeId,
          isDeleted: false,
        },
      });

    if (!registration) {
      throw new NotFoundError(
        "Registration Type not found."
      );
    }
  }

  // ===============================
  // Generate Tenant ID
  // ===============================

  let tenantId: string;

  try {
    tenantId = await generateTenantId(legalName);
  } catch (error) {
    throw new ValidationError(
      error instanceof Error
        ? error.message
        : "Unable to generate Tenant ID."
    );
  }

  // ===============================
  // Create Business
  // ===============================

  const business =
    await repository.createBusiness({
      tenantId,
      businessType,
      gstin,
      pan,
      legalName,
      tradeName,
      displayName,
      email,
      phone,
      websiteLink,
      businessCategoryId,
      businessSubCategoryId,
      industryId,
      registrationTypeId,
      registrationNumber,
      licenseTypeId,
      tan,
      msme,
      currencyId,
      timezone,
      financialYear,
      description,
      logo,
      createdBy
    });

  return {
    status: 201,
    message: "Business created successfully.",
    data: business,
  };
};



export const getBusinessesService = async () => {
  const businesses =
    await repository.getAllBusinesses();

     console.log(
    "Business logo from DB:",
    businesses.map((business) => ({
      id: business.id,
      tenantId: business.tenantId,
      logo: business.logo,
    }))
  );

  const formattedBusinesses =
    businesses.map((business) => ({
      ...business,

      logo: getFileUrl(business.logo),

      documents: business.documents.map(
        (document) => ({
          ...document,

          fileUrl: getFileUrl(
            document.fileUrl
          ),
        })
      ),

      // ==================================================
      // BRANCHES
      // ==================================================

      branches: business.branches.map(
        (branch) => ({
          ...branch,

          // ==============================================
          // BRANCH DOCUMENTS
          // ==============================================

          documents:
            branch.documents.map(
              (document) => ({
                ...document,

                fileUrl: getFileUrl(
                  document.fileUrl
                ),
              })
            ),
        })
      ),
    }));

  return {
    status: 200,
    message: "Businesses fetched successfully.",
    data: formattedBusinesses,
  };
};





export const getBusinessByIdService = async (
  id: string
) => {
  if (!id) {
    throw new ValidationError("Business ID is required.");
  }

  const business = await repository.findById(id);

  if (!business) {
    throw new NotFoundError("Business not found.");
  }

  const formattedBusiness = {
    ...business,

    // ==========================
    // BUSINESS LOGO
    // ==========================
    logo: getFileUrl(business.logo),

    // ==========================
    // BUSINESS DOCUMENTS
    // ==========================
    documents: business.documents.map((document) => ({
      ...document,

      fileUrl: getFileUrl(document.fileUrl),
    })),

    // ==========================
    // BRANCHES
    // ==========================
    branches: business.branches.map((branch) => ({
      ...branch,

      // ==========================
      // BRANCH DOCUMENTS
      // ==========================
      documents: branch.documents.map((document) => ({
        ...document,

        fileUrl: getFileUrl(document.fileUrl),
      })),
    })),
  };

  return {
    status: 200,
    message: "Business fetched successfully.",
    data: formattedBusiness,
  };
};


export const updateBusinessService = async (
  id: string,
  body: any
) => {
  
  const business = await repository.findById(id);

  if (!business) {
    return {
      status: 404,
      message: "Business not found.",
    };
  }

  const {
    gstin,
    pan,
    legalName,
    businessCategoryId,
    businessSubCategoryId,
    industryId,
    registrationTypeId,
    licenseTypeId,
    registrationNumber,
    tan,
    msme,
    currencyId,
    compressedFile,
  } = body;


  if (legalName) {
    const existingBusiness =
      await repository.businessExists(legalName);

    if (existingBusiness && existingBusiness.id !== id && !existingBusiness.deletedAt) {
      throw new ConflictError("Business name already exists.");
    }
  }


  if (gstin) {
    const gstExists =
      await repository.findByGSTIN(gstin);

    if (gstExists && gstExists.id !== id && !gstExists.deletedAt) {
      throw new ConflictError("GSTIN already exists.");
    }
  }


  if (pan) {
    const panExists =
      await repository.findByPAN(pan);

    if (panExists && panExists.id !== id && !panExists.deletedAt) {
      throw new ConflictError("PAN already exists.");
    }
  }

  // ==========================================================
  // CATEGORY VALIDATION
  // ==========================================================

  if (businessCategoryId) {
    const category =
      await prisma.category.findFirst({
        where: {
          id: businessCategoryId,
          isDeleted: false,
        },
      });

    if (!category) {
      throw new NotFoundError("Business Category not found.");
    }
  }

  if (businessSubCategoryId) {
    const subCategory =
      await prisma.subCategory.findFirst({
        where: {
          id: businessSubCategoryId,
          isDeleted: false,
        },
      });

    if (!subCategory) {
      throw new NotFoundError("Business Sub-Category not found.");
    }
  }

  // ==========================================================
  // INDUSTRY VALIDATION
  // ==========================================================

  if (industryId) {
    const industry =
      await prisma.industry.findFirst({
        where: {
          id: industryId,
          isDeleted: false,
        },
      });

    if (!industry) {
      throw new NotFoundError("Industry not found.");
    }
  }

  // ==========================================================
  // CURRENCY VALIDATION
  // ==========================================================

  if (currencyId) {
    const currency =
      await prisma.currency.findFirst({
        where: {
          id: currencyId,
          isDeleted: false,
        },
      });

    if (!currency) {
      throw new NotFoundError("Currency not found.");
    }
  }

  // ==========================================================
  // REGISTRATION TYPE VALIDATION
  // ==========================================================

  if (registrationTypeId) {
    const registration =
      await prisma.registrationType.findFirst({
        where: {
          id: registrationTypeId,
          isDeleted: false,
        },
      });

    if (!registration) {
      return {
        status: 404,
        message: "Registration Type not found.",
      };
    }
  }

  if (!licenseTypeId) {
    throw new ValidationError("License Type is required.");
  }

  // ==========================================================
  // PREPARE UPDATE DATA
  // ==========================================================

  const updateData: any = {
    businessType: body.businessType,
    gstin: body.gstin,
    pan: body.pan,
    legalName: body.legalName,
    tradeName: body.tradeName,
    displayName: body.displayName,
    email: body.email,
    phone: body.phone,
    websiteLink: body.websiteLink,
    registrationNumber: body.registrationNumber,
    licenseTypeId: body.licenseTypeId,
    tan: body.tan,
    msme: body.msme,
    timezone: body.timezone,
    financialYear: body.financialYear,
    description: body.description,
  };

  // ==========================================================
  // REMOVE UNDEFINED VALUES
  // ==========================================================

  Object.keys(updateData).forEach((key) => {
    if (updateData[key] === undefined) {
      delete updateData[key];
    }
  });

  // ==========================================================
  // CATEGORY RELATION
  // ==========================================================

  if (businessCategoryId) {
    updateData.category = {
      connect: {
        id: businessCategoryId,
      },
    };
  }

  if (businessSubCategoryId) {
    updateData.subCategory = {
      connect: {
        id: businessSubCategoryId,
      },
    };
  }

  // ==========================================================
  // INDUSTRY RELATION
  // ==========================================================

  if (industryId) {
    updateData.industry = {
      connect: {
        id: industryId,
      },
    };
  }

  // ==========================================================
  // REGISTRATION TYPE RELATION
  // ==========================================================

  if (registrationTypeId) {
    updateData.registrationType = {
      connect: {
        id: registrationTypeId,
      },
    };
  }

  // ==========================================================
  // CURRENCY RELATION
  // ==========================================================

  if (currencyId) {
    updateData.currency = {
      connect: {
        id: currencyId,
      },
    };
  }

  // ==========================================================
  // LOGO
  // ==========================================================

  if (compressedFile?.fileUrl) {
    updateData.logo = compressedFile.fileUrl;
  }

  // ==========================================================
  // UPDATE BUSINESS
  // ==========================================================

  const updatedBusiness =
    await repository.updateBusiness(
      id,
      updateData
    );

  return {
    status: 200,
    message: "Business updated successfully.",
    data: updatedBusiness,
  };
};



export const deleteBusinessService = async (
  id: string
) => {
  // Check if business exists
  const business = await repository.findById(id);

  if (!business) {
    throw new NotFoundError("Business not found.");
  }

  await repository.deleteBusiness(id);

  return {
    status: 200,
    message: "Business deleted successfully.",
  };
};




export const deleteBusiness = async (id: string) => {
  const deletedAt = new Date();

  return prisma.$transaction(async (tx) => {
    // Soft delete Business Addresses
    await tx.businessAddress.updateMany({
      where: {
        businessId: id,
        deletedAt: null,
      },
      data: {
        deletedAt,
      },
    });

    // Soft delete Business Banks
    await tx.businessBank.updateMany({
      where: {
        businessId: id,
        deletedAt: null,
      },
      data: {
        deletedAt,
      },
    });

    // Soft delete Business Branches
    await tx.businessBranch.updateMany({
      where: {
        businessId: id,
        deletedAt: null,
      },
      data: {
        deletedAt,
      },
    });

    // Soft delete Business Documents
    await tx.businessDocument.updateMany({
      where: {
        businessId: id,
        deletedAt: null,
      },
      data: {
        deletedAt,
      },
    });

    // Finally soft delete Business
    return tx.business.update({
      where: {
        id,
      },
      data: {
        deletedAt,
      },
    });
  });
};



export const getBusinessesByUserService = async (
  userId: string
) => {
  if (!userId) {
    throw new ValidationError("User ID is required.");
  }

  const businesses =
    await repository.getBusinessesByUser(userId);

  console.log(
    "Businesses for user:",
    userId
  );

  console.log(
    "Business logo from DB:",
    businesses.map((business) => ({
      id: business.id,
      tenantId: business.tenantId,
      createdBy: business.createdBy,
      logo: business.logo,
    }))
  );

  const formattedBusinesses =
    businesses.map((business) => ({
      ...business,

      logo: getFileUrl(business.logo),

      documents: business.documents.map(
        (document) => ({
          ...document,

          fileUrl: getFileUrl(
            document.fileUrl
          ),
        })
      ),

      // ================================
      // BRANCHES
      // ================================

      branches: business.branches.map(
        (branch) => ({
          ...branch,

          documents:
            branch.documents.map(
              (document) => ({
                ...document,

                fileUrl: getFileUrl(
                  document.fileUrl
                ),
              })
            ),
        })
      ),
    }));

  return {
    status: 200,
    message: "Businesses fetched successfully.",
    data: formattedBusinesses,
  };
};