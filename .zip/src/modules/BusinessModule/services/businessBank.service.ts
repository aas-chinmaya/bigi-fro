import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";
import ValidationError from "../../../common/exceptions/ValidationError";
import * as repository from "../repository/businessBank.repository";
import prisma from "../../../config/db";


// export const createBankService = async (body: any) => {
//   const {
//     tenantId,
//     accountHolderName,
//     bankName,
//     accountNumber,
//     ifscCode,
//     branch,
//     upiId,
//   } = body;

//   // ===============================
//   // Required Validation
//   // ===============================

//   if (!tenantId) {
//     return {
//       status: 400,
//       message: "Tenant is required.",
//     };
//   }

//   if (!accountHolderName) {
//     return {
//       status: 400,
//       message: "Account Holder Name is required.",
//     };
//   }

//   if (!bankName) {
//     return {
//       status: 400,
//       message: "Bank Name is required.",
//     };
//   }

//   if (!accountNumber) {
//     return {
//       status: 400,
//       message: "Account Number is required.",
//     };
//   }

//   if (!ifscCode) {
//     return {
//       status: 400,
//       message: "IFSC Code is required.",
//     };
//   }

//   if (!branch) {
//     return {
//       status: 400,
//       message: "Branch is required.",
//     };
//   }

//   // Business Validation
//   const business = await prisma.business.findFirst({
//     where: {
//       tenantId: tenantId,
//       deletedAt: null,
//     },
//   });

//   if (!business) {
//     return {
//       status: 404,
//       message: "Business not found.",
//     };
//   }

//   // Duplicate Account Number
//   const accountExists =
//     await repository.findByAccountNumber(
//       tenantId,
//       accountNumber
//     );

//   if (accountExists) {
//     if (!accountExists.deletedAt) {
//       return {
//         status: 400,
//         message: "Account Number already exists.",
//       };
//     }

//     const restored =
//       await repository.restoreBank(
//         accountExists.id,
//         body
//       );

//     return {
//       status: 200,
//       message: "Bank restored successfully.",
//       data: restored,
//     };
//   }

//   // Duplicate UPI
//   if (upiId) {
//     const upiExists =
//       await repository.findByUPI(
//         tenantId,
//         upiId
//       );

//     if (
//       upiExists &&
//       !upiExists.deletedAt
//     ) {
//       return {
//         status: 400,
//         message: "UPI ID already exists.",
//       };
//     }
//   }

  
//   // Create Bank
//   const bank =
//     await repository.createBank({
//       tenantId,
//       accountHolderName,
//       bankName,
//       accountNumber,
//       ifscCode,
//       branch,
//       upiId,
//     });

//   return {
//     status: 201,
//     message: "Business Bank created successfully.",
//     data: bank,
//   };
// };



export const createBankService = async (body: any) => {
  const {
    tenantId,
    accountHolderName,
    bankName,
    accountNumber,
    ifscCode,
    branch,
    upiId,
  } = body;

  // ===============================
  // Required Validation
  // ===============================

  if (!tenantId) {
    throw new ValidationError("Tenant is required.");
  }

  if (!accountHolderName?.trim()) {
    throw new ValidationError("Account Holder Name is required.");
  }

  if (!bankName?.trim()) {
    throw new ValidationError("Bank Name is required.");
  }

  if (!accountNumber?.trim()) {
    throw new ValidationError("Account Number is required.");
  }

  if (!ifscCode?.trim()) {
    throw new ValidationError("IFSC Code is required.");
  }

  if (!branch?.trim()) {
    throw new ValidationError("Branch is required.");
  }

  // ===============================
  // Business Validation
  // ===============================

  const business =
    await prisma.business.findFirst({
      where: {
        tenantId,
        deletedAt: null,
      },
      select: {
        id: true,
        tenantId: true,
      },
    });

  if (!business) {
    throw new NotFoundError("Business not found.");
  }

  // ===============================
  // Find Existing Bank
  // ===============================

  const existingBank =
    await repository.findByAccountNumber(
      tenantId,
      accountNumber
    );

  // ==========================================================
  // EXISTING BANK
  // ==========================================================

  if (existingBank) {

    // ===============================
    // Active Bank
    // ===============================

    if (!existingBank.deletedAt) {

      // Check whether the UPI belongs
      // to another bank
      if (upiId) {
        const upiExists =
          await repository.findByUPI(
            tenantId,
            upiId
          );

        if (
          upiExists &&
          upiExists.id !== existingBank.id
        ) {
          return {
            status: 400,
            message:
              "UPI ID already exists.",
          };
        }
      }

      // ===============================
      // Update Existing Bank
      // ===============================

      const updated =
        await repository.updateBank(
          existingBank.id,
          {
            accountHolderName,
            bankName,
            accountNumber,
            ifscCode,
            branch,
            upiId,
          }
        );

      return {
        status: 200,
        message:
          "Bank details updated successfully.",
        data: updated,
      };
    }

    // ===============================
    // Restore Deleted Bank
    // ===============================

    if (upiId) {
      const upiExists =
        await repository.findByUPI(
          tenantId,
          upiId
        );

      if (
        upiExists &&
        upiExists.id !== existingBank.id &&
        !upiExists.deletedAt
      ) {
        return {
          status: 400,
          message:
            "UPI ID already exists.",
        };
      }
    }

    const restored =
      await repository.restoreBank(
        existingBank.id,
        {
          tenantId,
          accountHolderName,
          bankName,
          accountNumber,
          ifscCode,
          branch,
          upiId,
        }
      );

    return {
      status: 200,
      message:
        "Bank restored successfully.",
      data: restored,
    };
  }

  // ==========================================================
  // NO BANK WITH THIS ACCOUNT NUMBER
  // ==========================================================

  // ===============================
  // Check UPI
  // ===============================

  if (upiId) {
    const upiExists =
      await repository.findByUPI(
        tenantId,
        upiId
      );

    if (
      upiExists &&
      !upiExists.deletedAt
    ) {
      return {
        status: 400,
        message:
          "UPI ID already exists.",
      };
    }

    // If the UPI belongs to a deleted
    // bank, don't automatically restore
    // that bank because the account number
    // is different.
  }

  // ===============================
  // Create New Bank
  // ===============================

  const bank =
    await repository.createBank({
      tenantId,
      accountHolderName,
      bankName,
      accountNumber,
      ifscCode,
      branch,
      upiId,
    });

  return {
    status: 201,
    message:
      "Business Bank created successfully.",
    data: bank,
  };
};



export const getBanksService = async (
  tenantId: string
) => {
  const banks =
    await repository.getAllByBusiness(
      tenantId
    );

  return {

    message: "Business Banks fetched successfully.",
    data: banks,
  };
};


export const getBankByIdService = async (
  id: string
) => {
  const bank =
    await repository.findById(id);

  if (!bank) {
    throw new NotFoundError("Bank not found.");
  }

  return {

    message: "Business Bank fetched successfully.",
    data: bank,
  };
};



export const updateBankService = async (
  id: string,
  body: any
) => {
  const bank =
    await repository.findById(id);

  if (!bank) {
    return {
      status: 404,
      message: "Business Bank not found.",
    };
  }

  if (body.businessId) {
    const business =
      await prisma.business.findFirst({
        where: {
          id: body.businessId,
          deletedAt: null,
        },
      });

    if (!business) {
      return {
        status: 404,
        message: "Business not found.",
      };
    }
  }

  if (body.accountNumber) {
    const accountExists =
      await repository.findByAccountNumber(
        body.tenantId || bank.tenantId,
        body.accountNumber
      );

    if (
      accountExists &&
      accountExists.id !== id &&
      !accountExists.deletedAt
    ) {
      return {
        status: 400,
        message: "Account Number already exists.",
      };
    }
  }

  if (body.upiId) {
    const upiExists =
      await repository.findByUPI(
        body.tenantId || bank.tenantId,
        body.upiId
      );

    if (
      upiExists &&
      upiExists.id !== id &&
      !upiExists.deletedAt
    ) {
      return {
        status: 400,
        message: "UPI ID already exists.",
      };
    }
  }

  const updated =
    await repository.updateBank(
      id,
      body
    );

  return {
    status: 200,
    message: "Business Bank updated successfully.",
    data: updated,
  };
};



export const deleteBankService = async (
  id: string
) => {
  const bank =
    await repository.findById(id);

  if (!bank) {
    return {
      status: 404,
      message: "Business Bank not found.",
    };
  }

  await repository.deleteBank(id);

  return {

    message: "Business Bank deleted successfully.",
  };
};
