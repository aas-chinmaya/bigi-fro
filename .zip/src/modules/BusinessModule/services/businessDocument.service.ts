import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";
import ValidationError from "../../../common/exceptions/ValidationError";
import prisma from "../../../config/db";
import * as repository from "../repository/businessDocument.repository";
import { BusinessDocumentType } from "@prisma/client";



export const createDocumentService = async (
  body: any,
  file?: any,
  compressedFile?: any
) => {
  // ==========================================================
  // EFFECTIVE BODY
  // ==========================================================

  const uploadedFile = compressedFile || file;

  const effectiveBody = {
    ...body,

    ...(uploadedFile
      ? {
          fileName:
            body.fileName ||
            uploadedFile.originalname ||
            uploadedFile.filename,
          fileUrl:
            body.fileUrl ||
            (uploadedFile.filename
              ? `/uploads/business/${uploadedFile.fieldname || "file"}/${uploadedFile.filename}`
              : undefined),
        }
      : {}),
  };

  const {
    tenantId,
    branchId,
    documentType,
    fileName,
    fileUrl,
  } = effectiveBody;

  // ==========================================================
  // REQUIRED VALIDATION
  // ==========================================================

  if (!tenantId) {
    throw new ValidationError("Business is required.");
  }

  if (!documentType) {
    throw new ValidationError("Document Type is required.");
  }

  if (!fileName?.trim()) {
    throw new ValidationError("File Name is required.");
  }

  if (!fileUrl?.trim()) {
    throw new ValidationError("File URL is required.");
  }

  // ==========================================================
  // BUSINESS VALIDATION
  // ==========================================================

  const business =
    await prisma.business.findFirst({
      where: {
        tenantId,
        deletedAt: null,
      },
      select: {
        id: true,
        tenantId: true,
      },
    });

  if (!business) {
    throw new NotFoundError("Business not found.");
  }

  // ==========================================================
  // BRANCH VALIDATION
  // ==========================================================

  if (branchId) {
    const branch =
      await prisma.businessBranch.findFirst({
        where: {
          id: branchId,
          isDeleted: false,
          deletedAt: null,
        },
        select: {
          id: true,
          tenantId: true,
        },
      });

    if (!branch) {
      throw new NotFoundError("Branch not found.");
    }

    if (branch.tenantId !== tenantId) {
      throw new ConflictError("Branch does not belong to this business.");
    }
  }

  // ==========================================================
  // FIND EXISTING DOCUMENT
  // ==========================================================

  const existingDocument =
    await repository.findByType(
      tenantId,
      branchId ?? null,
      documentType as BusinessDocumentType
    );

  // ==========================================================
  // EXISTING DOCUMENT
  // ==========================================================

  if (existingDocument) {

    // ========================================================
    // ACTIVE DOCUMENT → UPDATE
    // ========================================================

    if (!existingDocument.deletedAt) {

      const updated =
        await repository.updateDocument(
          existingDocument.id,
          {
            documentType:
              documentType as BusinessDocumentType,
            fileName,
            fileUrl,
            branchId: branchId ?? null,
            verified: false,
          }
        );

      return {
        message: "Business Document updated successfully.",
        data: updated,
      };
    }

    // ========================================================
    // DELETED DOCUMENT → RESTORE + UPDATE
    // ========================================================

    const restored =
      await repository.restoreDocument(
        existingDocument.id,
        {
          tenantId,
          branchId: branchId ?? null,
          documentType:
            documentType as BusinessDocumentType,
          fileName,
          fileUrl,
          verified: false,
        }
      );

    return {
      message: "Business Document restored successfully.",
      data: restored,
    };
  }

  // ==========================================================
  // CREATE NEW DOCUMENT
  // ==========================================================

  const document =
    await repository.createDocument({
      tenantId,
      branchId: branchId ?? null,
      documentType:
        documentType as BusinessDocumentType,
      fileName,
      fileUrl,
      verified: false,
    });

  return {
    message: "Business Document created successfully.",
    data: document,
  };
};




export const getDocumentsService =
  async () => {
    const documents =
      await repository.getAllDocuments();

    return {
      message: "Documents fetched successfully.",
      data: documents,
    };
  };


export const getDocumentByIdService =
    async (id: string) => {
    const document =
    await repository.findById(id);

    if (!document) {
      throw new NotFoundError("Document not found.");
    }

    return {
      message: "Document fetched successfully.",
      data: document,
    };
};


export const getDocumentsByBusinessService =
  async (tenantId: string) => {
    const documents =
      await repository.getDocumentsByBusiness(
        tenantId
      );

    return {
      status: 200,
      data: documents,
    };
};


export const getDocumentsByBranchService =
  async (branchId: string) => {
    const documents =
      await repository.getDocumentsByBranch(
        branchId
      );

    return {
      status: 200,
      message: "Documents fetched successfully.",
      data: documents,
    };
};


export const updateDocumentService = async (
  id: string,
  body: any,
  file?: any,
  compressedFile?: any
) => {
  const document = await repository.findById(id);

  if (!document) {
    return {
      status: 404,
      message: "Document not found.",
    };
  }

  const uploadedFile = compressedFile || file;

  const effectiveBody = {
    ...body,
    ...(uploadedFile
      ? {
          fileName:
            body.fileName ||
            uploadedFile.originalname ||
            uploadedFile.filename,
          fileUrl:
            body.fileUrl ||
            (uploadedFile.filename
              ? `/uploads/business/${uploadedFile.fieldname || "file"}/${uploadedFile.filename}`
              : undefined),
        }
      : {}),
  };

  const {
    tenantId,
    branchId,
    documentType,
    fileName,
    fileUrl,
  } = effectiveBody;

  // ==========================
  // Business Validation
  // ==========================

  if (tenantId) {
    const business = await prisma.business.findFirst({
      where: {
        id: tenantId,
        deletedAt: null,
      },
    });

    if (!business) {
      throw new NotFoundError("Business not found.");
    }
  }

  // ==========================
  // Branch Validation
  // ==========================

  if (branchId) {
    const branch = await prisma.businessBranch.findFirst({
      where: {
        id: branchId,
        deletedAt: null,
      },
    });

    if (!branch) {
      return {
        status: 404,
        message: "Branch not found.",
      };
    }

    if (
      branch.tenantId !==
      (tenantId || document.tenantId)
    ) {
      return {
        status: 400,
        message:
          "Branch does not belong to the selected tenant.",
      };
    }
  }

  // ==========================
  // Duplicate Validation
  // ==========================

  if (documentType) {
    const duplicate =
      await repository.findByType(
        tenantId || document.tenantId,
        branchId ?? document.branchId ?? null,
        documentType
      );

    if (
      duplicate &&
      duplicate.id !== id &&
      !duplicate.deletedAt
    ) {
      throw new ConflictError("Document type already exists.");
    }
  }

  // ==========================
  // Update
  // ==========================

  const updated =
    await repository.updateDocument(id, {
      tenantId,
      branchId,
      documentType,
      fileName,
      fileUrl,
    });

  return {
    message: "Document updated successfully.",
    data: updated,
  };
};


export const deleteDocumentService = async (
  id: string
) => {
  const document =
    await repository.findById(id);

  if (!document) {
    return {
      status: 404,
      message: "Document not found.",
    };
  }

  await repository.deleteDocument(id);

  return {
    message: "Document deleted successfully.",
     data: {
      id,
    },
  };
};
