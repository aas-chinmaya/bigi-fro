import prisma from "../../../config/db";

// ==========================================================
// CREATE BANK
// ==========================================================

export const createBank = (data: {
  tenantId: string;
  accountHolderName: string;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  branch: string;
  upiId?: string;
}) => {
  return prisma.businessBank.create({
    data,
  });
};

// ==========================================================
// FIND BY ID
// ==========================================================

export const findById = (id: string) => {
  return prisma.businessBank.findFirst({
    where: {
      id,
      deletedAt: null,
    },
    include: {
      business: true,
    },
  });
};

// ==========================================================
// GET ALL BANKS BY BUSINESS
// ==========================================================

export const getAllByBusiness = (
  tenantId: string
) => {
  return prisma.businessBank.findMany({
    where: {
      tenantId,
      deletedAt: null,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

// ==========================================================
// FIND BY ACCOUNT NUMBER
// ==========================================================

export const findByAccountNumber = (
  tenantId: string,
  accountNumber: string
) => {
  return prisma.businessBank.findFirst({
    where: {
      tenantId,
      accountNumber,
    },
  });
};

// ==========================================================
// FIND BY UPI
// ==========================================================

export const findByUPI = (
  tenantId: string,
  upiId: string
) => {
  return prisma.businessBank.findFirst({
    where: {
      tenantId,
      upiId,
    },
  });
};

// ==========================================================
// UPDATE BANK
// ==========================================================

export const updateBank = (
  id: string,
  data: {
    accountHolderName?: string;
    bankName?: string;
    accountNumber?: string;
    ifscCode?: string;
    branch?: string;
    upiId?: string;
  }
) => {
  return prisma.businessBank.update({
    where: {
      id,
    },
    data,
  });
};

// ==========================================================
// RESTORE BANK
// ==========================================================

export const restoreBank = (
  id: string,
  data: {
    tenantId: string;
    accountHolderName: string;
    bankName: string;
    accountNumber: string;
    ifscCode: string;
    branch: string;
    upiId?: string;
  }
) => {
  return prisma.businessBank.update({
    where: {
      id,
    },
    data: {
      tenantId: data.tenantId,
      accountHolderName:
        data.accountHolderName,
      bankName: data.bankName,
      accountNumber:
        data.accountNumber,
      ifscCode: data.ifscCode,
      branch: data.branch,
      upiId: data.upiId,
      deletedAt: null,
    },
  });
};

// ==========================================================
// DELETE BANK
// ==========================================================

export const deleteBank = (
  id: string
) => {
  return prisma.businessBank.update({
    where: {
      id,
    },
    data: {
      deletedAt: new Date(),
    },
  });
};
