import variantTypeRepository from "../repository/variantType.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

interface CreateVariantTypeDto {
    subCategoryId: string;
    variantTypeCode: string;
    variantTypeName: string;
    description?: string;
    status?: boolean;
}

interface UpdateVariantTypeDto {
    subCategoryId?: string;
    variantTypeCode?: string;
    variantTypeName?: string;
    description?: string;
    status?: boolean;
}

class VariantTypeService {

    async createVariantType(payload: CreateVariantTypeDto) {

        const {
            subCategoryId,
            variantTypeCode,
            variantTypeName,
            description,
            status = true,
        } = payload;

        if (!subCategoryId) {
            throw new ValidationError("Sub Category is required.");
        }

        if (!variantTypeCode?.trim()) {
            throw new ValidationError("Variant Type Code is required.");
        }

        if (!variantTypeName?.trim()) {
            throw new ValidationError("Variant Type Name is required.");
        }

        // Validate Sub Category
        const subCategory =
            await variantTypeRepository.findSubCategory(subCategoryId);

        if (!subCategory) {
            throw new ValidationError("Sub Category not found.");
        }

        // Duplicate Code
        const existingCode =
            await variantTypeRepository.findByCode(
                variantTypeCode.trim()
            );

        if (existingCode) {
            throw new ValidationError("Variant Type Code already exists.");
        }

        // Duplicate Name within Sub Category
        const existingName =
            await variantTypeRepository.findByName(
                subCategoryId,
                variantTypeName.trim()
            );

        if (existingName) {
            throw new ValidationError(
                "Variant Type Name already exists for this Sub Category."
            );
        }

        return await variantTypeRepository.create({
            variantTypeCode: variantTypeCode.trim(),
            variantTypeName: variantTypeName.trim(),
            description,
            status,
            subCategory: {
                connect: {
                    id: subCategoryId,
                },
            },
        });

    }

    async getAllVariantTypes(
        page = 1,
        limit = 10,
        search?: string,
        status?: boolean
    ) {

        page = Number(page);
        limit = Number(limit);

        if (page < 1) page = 1;
        if (limit < 1) limit = 10;

        return await variantTypeRepository.getAll(
            page,
            limit,
            search,
            status
        );

    }

    async getVariantTypeById(id: string) {

        const variantType =
            await variantTypeRepository.findById(id);

        if (!variantType) {
            throw new ValidationError("Variant Type not found.");
        }

        return variantType;

    }

    async updateVariantType(
        id: string,
        payload: UpdateVariantTypeDto
    ) {

        const variantType =
            await variantTypeRepository.findById(id);

        if (!variantType) {
            throw new ValidationError("Variant Type not found.");
        }

        // Validate Sub Category if changed
        if (payload.subCategoryId) {

            const subCategory =
                await variantTypeRepository.findSubCategory(
                    payload.subCategoryId
                );

            if (!subCategory) {
                throw new ValidationError("Sub Category not found.");
            }

        }

        // Duplicate Code
        if (payload.variantTypeCode) {

            const existingCode =
                await variantTypeRepository.findByCode(
                    payload.variantTypeCode.trim()
                );

            if (
                existingCode &&
                existingCode.id !== id
            ) {
                throw new ValidationError(
                    "Variant Type Code already exists."
                );
            }

        }

        // Duplicate Name
        if (
            payload.variantTypeName &&
            (payload.subCategoryId || variantType.subCategoryId)
        ) {

            const subCategoryId =
                payload.subCategoryId || variantType.subCategoryId;

            const existingName =
                await variantTypeRepository.findByName(
                    subCategoryId,
                    payload.variantTypeName.trim()
                );

            if (
                existingName &&
                existingName.id !== id
            ) {
                throw new ValidationError(
                    "Variant Type Name already exists."
                );
            }

        }

        return await variantTypeRepository.update(id, {

            variantTypeCode: payload.variantTypeCode?.trim(),

            variantTypeName: payload.variantTypeName?.trim(),

            description: payload.description,

            status: payload.status,

            ...(payload.subCategoryId && {
                subCategory: {
                    connect: {
                        id: payload.subCategoryId,
                    },
                },
            }),

        });

    }

    async deleteVariantType(id: string) {

        const variantType =
            await variantTypeRepository.findById(id);

        if (!variantType) {
            throw new ValidationError("Variant Type not found.");
        }

        return await variantTypeRepository.softDelete(id);

    }

    async restoreVariantType(id: string) {

        const variantType =
            await variantTypeRepository.findById(id);

        if (variantType) {
            throw new ValidationError(
                "Variant Type is already active."
            );
        }

        return await variantTypeRepository.restore(id);

    }

}

export default new VariantTypeService();