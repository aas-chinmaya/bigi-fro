import brandRepository from "../repository/brand.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

interface CreateBrandDto {
    brandName: string;
    description?: string;
    status?: boolean;
}

interface UpdateBrandDto {
    brandName?: string;
    description?: string;
    status?: boolean;
}

class BrandService {

    async createBrand(payload: CreateBrandDto) {

        const {
            brandName,
            description,
            status = true,
        } = payload;

        if (!brandName?.trim()) {
            throw new ValidationError("Brand name is required.");
        }

        const existingBrand = await brandRepository.findByName(
            brandName.trim()
        );

        if (existingBrand) {
            throw new ValidationError("Brand already exists.");
        }

        return await brandRepository.create({
            brandName: brandName.trim(),
            description,
            status,
        });
    }

    async getAllBrands(
        page = 1,
        limit = 10,
        search?: string,
        status?: boolean
    ) {

        page = Number(page);
        limit = Number(limit);

        if (page < 1) page = 1;
        if (limit < 1) limit = 10;

        return await brandRepository.getAll(
            page,
            limit,
            search,
            status
        );
    }

    async getBrandById(id: string) {

        const brand = await brandRepository.findById(id);

        if (!brand) {
            throw new ValidationError("Brand not found.");
        }

        return brand;
    }

    async updateBrand(
        id: string,
        payload: UpdateBrandDto
    ) {

        const brand = await brandRepository.findById(id);

        if (!brand) {
            throw new ValidationError("Brand not found.");
        }

        if (payload.brandName) {

            const existingBrand = await brandRepository.findByName(
                payload.brandName.trim()
            );

            if (
                existingBrand &&
                existingBrand.id !== id
            ) {
                throw new ValidationError("Brand already exists.");
            }
        }

        return await brandRepository.update(id, {
            brandName: payload.brandName?.trim(),
            description: payload.description,
            status: payload.status,
        });
    }

    async deleteBrand(id: string) {

        const brand = await brandRepository.findById(id);

        if (!brand) {
            throw new ValidationError("Brand not found.");
        }

        return await brandRepository.softDelete(id);
    }

    async restoreBrand(id: string) {

        const brand = await brandRepository.findById(id);

        if (brand) {
            throw new ValidationError("Brand is already active.");
        }

        return await brandRepository.restore(id);
    }

}

export default new BrandService();