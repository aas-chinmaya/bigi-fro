import subCategoryRepository from "../repository/subCategory.repository";
import categoryRepository from "../repository/category.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

interface CreateSubCategoryDto {
    categoryId: string;
    subCategoryName: string;
    description?: string;
    status?: boolean;
}

interface UpdateSubCategoryDto {
    categoryId?: string;
    subCategoryName?: string;
    description?: string;
    status?: boolean;
}

class SubCategoryService {

    async createSubCategory(payload: CreateSubCategoryDto) {

        const {
            categoryId,
            subCategoryName,
            description,
            status = true
        } = payload;

        if (!categoryId) {
            throw new ValidationError("Category is required.");
        }

        if (!subCategoryName?.trim()) {
            throw new ValidationError("Sub Category name is required.");
        }

        // Check Category Exists
        const category = await categoryRepository.findById(categoryId);

        if (!category) {
            throw new ValidationError("Category not found.");
        }

        // Duplicate Check
        const existingSubCategory =
            await subCategoryRepository.findByName(
                categoryId,
                subCategoryName.trim()
            );

        if (existingSubCategory) {
            throw new ValidationError(
                "Sub Category already exists in this Category."
            );
        }

        return await subCategoryRepository.create({
            subCategoryName: subCategoryName.trim(),
            description,
            status,

            category: {
                connect: {
                    id: categoryId
                }
            }
        });
    }

    async getAllSubCategories(
        page = 1,
        limit = 10,
        search?: string,
        status?: boolean
    ) {

        page = Number(page);
        limit = Number(limit);

        if (page < 1) page = 1;
        if (limit < 1) limit = 10;

        return await subCategoryRepository.getAll(
            page,
            limit,
            search,
            status
        );
    }

    async getSubCategoryById(id: string) {

        const subCategory =
            await subCategoryRepository.findById(id);

        if (!subCategory) {
            throw new ValidationError("Sub Category not found.");
        }

        return subCategory;
    }

    async updateSubCategory(
        id: string,
        payload: UpdateSubCategoryDto
    ) {

        const subCategory =
            await subCategoryRepository.findById(id);

        if (!subCategory) {
            throw new ValidationError("Sub Category not found.");
        }

        let categoryId = subCategory.categoryId;

        if (payload.categoryId) {

            const category =
                await categoryRepository.findById(payload.categoryId);

            if (!category) {
                throw new ValidationError("Category not found.");
            }

            categoryId = payload.categoryId;
        }

        if (payload.subCategoryName) {

            const existing =
                await subCategoryRepository.findByName(
                    categoryId,
                    payload.subCategoryName.trim()
                );

            if (
                existing &&
                existing.id !== id
            ) {
                throw new ValidationError(
                    "Sub Category already exists in this Category."
                );
            }
        }

        return await subCategoryRepository.update(id, {

            subCategoryName: payload.subCategoryName?.trim(),

            description: payload.description,

            status: payload.status,

            ...(payload.categoryId && {
                category: {
                    connect: {
                        id: payload.categoryId
                    }
                }
            })

        });
    }

    async deleteSubCategory(id: string) {

        const subCategory =
            await subCategoryRepository.findById(id);

        if (!subCategory) {
            throw new ValidationError("Sub Category not found.");
        }

        return await subCategoryRepository.softDelete(id);
    }

    async restoreSubCategory(id: string) {

        const subCategory =
            await subCategoryRepository.findById(id);

        if (subCategory) {
            throw new ValidationError(
                "Sub Category is already active."
            );
        }

        return await subCategoryRepository.restore(id);
    }

    async getByCategory(categoryId: string) {

        const category =
            await categoryRepository.findById(categoryId);

        if (!category) {
            throw new ValidationError("Category not found.");
        }

        return await subCategoryRepository.getByCategoryId(categoryId);
    }

}

export default new SubCategoryService();