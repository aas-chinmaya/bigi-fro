import taxRepository from "../repository/tax.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

interface CreateTaxDto {
    hsnCode?: string;
    sacCode?: string;
    gstRate: number;
    cgst?: number;
    sgst?: number;
    igst?: number;
    ugst?: number;
    cess?: number;
    effectiveFrom?: Date;
    effectiveTo?: Date;
    status?: boolean;
}

interface UpdateTaxDto {
    hsnCode?: string;
    sacCode?: string;
    gstRate?: number;
    cgst?: number;
    sgst?: number;
    igst?: number;
    ugst?: number;
    cess?: number;
    effectiveFrom?: Date;
    effectiveTo?: Date;
    status?: boolean;
}

class TaxService {

    async createTax(payload: CreateTaxDto) {

        const {
            hsnCode,
            sacCode,
            gstRate,
            cgst,
            sgst,
            igst,
            ugst,
            cess,
            effectiveFrom,
            effectiveTo,
            status = true,
        } = payload;

        if (!hsnCode?.trim() && !sacCode?.trim()) {
            throw new ValidationError(
                "Either HSN Code or SAC Code is required."
            );
        }

        if (gstRate === undefined || gstRate === null) {
            throw new ValidationError("GST Rate is required.");
        }

        if (hsnCode) {
            const existingHSN = await taxRepository.findByHsnCode(
                hsnCode.trim()
            );

            if (existingHSN) {
                throw new ValidationError("HSN Code already exists.");
            }
        }

        if (sacCode) {
            const existingSAC = await taxRepository.findBySacCode(
                sacCode.trim()
            );

            if (existingSAC) {
                throw new ValidationError("SAC Code already exists.");
            }
        }

        return await taxRepository.create({
            hsnCode: hsnCode?.trim(),
            sacCode: sacCode?.trim(),
            gstRate,
            cgst,
            sgst,
            igst,
            ugst,
            cess,
            // effectiveFrom,
            // effectiveTo,
            effectiveFrom: effectiveFrom
                          ? new Date(effectiveFrom)
                           : undefined,
            effectiveTo: effectiveTo
                         ? new Date(effectiveTo)
                         : undefined,
            status,
        });

    }

    async getAllTaxes(
        page = 1,
        limit = 10,
        search?: string,
        status?: boolean
    ) {

        page = Number(page);
        limit = Number(limit);

        if (page < 1) page = 1;
        if (limit < 1) limit = 10;

        return await taxRepository.getAll(
            page,
            limit,
            search,
            status
        );

    }

    async getTaxById(id: string) {

        const tax = await taxRepository.findById(id);

        if (!tax) {
            throw new ValidationError("Tax record not found.");
        }

        return tax;

    }

    async updateTax(
        id: string,
        payload: UpdateTaxDto
    ) {

        const tax = await taxRepository.findById(id);

        if (!tax) {
            throw new ValidationError("Tax record not found.");
        }

        if (payload.hsnCode) {

            const existingHSN =
                await taxRepository.findByHsnCode(
                    payload.hsnCode.trim()
                );

            if (
                existingHSN &&
                existingHSN.id !== id
            ) {
                throw new ValidationError(
                    "HSN Code already exists."
                );
            }

        }

        if (payload.sacCode) {

            const existingSAC =
                await taxRepository.findBySacCode(
                    payload.sacCode.trim()
                );

            if (
                existingSAC &&
                existingSAC.id !== id
            ) {
                throw new ValidationError(
                    "SAC Code already exists."
                );
            }

        }

        return await taxRepository.update(id, {

            hsnCode: payload.hsnCode?.trim(),

            sacCode: payload.sacCode?.trim(),

            gstRate: payload.gstRate,

            cgst: payload.cgst,

            sgst: payload.sgst,

            igst: payload.igst,

            ugst: payload.ugst,

            cess: payload.cess,

            effectiveFrom: payload.effectiveFrom,

            effectiveTo: payload.effectiveTo,

            status: payload.status,

        });

    }

    async deleteTax(id: string) {

        const tax = await taxRepository.findById(id);

        if (!tax) {
            throw new ValidationError("Tax record not found.");
        }

        return await taxRepository.softDelete(id);

    }

    async restoreTax(id: string) {

        const tax = await taxRepository.findById(id);

        if (tax) {
            throw new ValidationError(
                "Tax record is already active."
            );
        }

        return await taxRepository.restore(id);

    }

}

export default new TaxService();