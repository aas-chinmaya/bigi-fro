import categoryRepository from "../repository/category.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

interface CreateCategoryDto {
  categoryName: string;
  icon: string;
  description?: string;
  status?: boolean;
}

interface UpdateCategoryDto {
  categoryName?: string;
  icon?: string;
  description?: string;
  status?: boolean;
}

class CategoryService {

  async createCategory(payload: CreateCategoryDto) {

    const { categoryName, description, status = true } = payload;

    if (!categoryName?.trim()) {
      throw new ValidationError("Category name is required");
    }

    // if (!icon?.trim()) {
    //   throw new ValidationError("Category icon is required");
    // }

    const existingCategory = await categoryRepository.findByName(
      categoryName.trim()
    );

    if (existingCategory) {
      throw new ValidationError("Category already exists");
    }

    return await categoryRepository.create({
      categoryName: categoryName.trim(),
      description,
      status,
    });
  }

  async getAllCategories(
    page = 1,
    limit = 10,
    search?: string,
    status?: boolean
  ) {

    page = Number(page);
    limit = Number(limit);

    if (page < 1) page = 1;

    if (limit < 1) limit = 10;

    return await categoryRepository.getAll(
      page,
      limit,
      search,
      status
    );
  }

  async getCategoryById(id: string) {

    const category = await categoryRepository.findById(id);

    if (!category) {
      throw new ValidationError("Category not found");
    }

    return category;
  }

  async updateCategory(
    id: string,
    payload: UpdateCategoryDto
  ) {

    const category = await categoryRepository.findById(id);

    if (!category) {
      throw new ValidationError("Category not found");
    }

    if (payload.categoryName) {

      const existingCategory =
        await categoryRepository.findByName(payload.categoryName);

      if (
        existingCategory &&
        existingCategory.id !== id
      ) {
        throw new ValidationError(
          "Category already exists"
        );
      }
    }

    return await categoryRepository.update(id, {
      ...payload,
      categoryName: payload.categoryName?.trim(),
    });
  }

  async deleteCategory(id: string) {

    const category = await categoryRepository.findById(id);

    if (!category) {
      throw new ValidationError("Category not found");
    }

    return await categoryRepository.softDelete(id);
  }

  async restoreCategory(id: string) {

    const category = await categoryRepository.findById(id);

    if (category) {
      throw new ValidationError("Category is already active");
    }

    return await categoryRepository.restore(id);
  }
}

export default new CategoryService();