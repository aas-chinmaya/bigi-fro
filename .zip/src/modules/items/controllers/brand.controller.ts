import { Request, Response, NextFunction } from "express";
import brandService from "../services/brand.service";

class BrandController {

    async createBrand(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const brand = await brandService.createBrand(req.body);

            return res.status(201).json({
                success: true,
                message: "Brand created successfully.",
                data: brand,
            });

        } catch (error) {
            next(error);
        }
    }

    async getAllBrands(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const brands = await brandService.getAllBrands(
                Number(page),
                Number(limit),
                search as string,
                status !== undefined
                    ? status === "true"
                    : undefined
            );

            return res.status(200).json({
                success: true,
                message: "Brands fetched successfully.",
                data: brands,
            });

        } catch (error) {
            next(error);
        }
    }

    async getBrandById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const brand = await brandService.getBrandById(req.params.id as string);

            return res.status(200).json({
                success: true,
                message: "Brand fetched successfully.",
                data: brand,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateBrand(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const brand = await brandService.updateBrand(req.params.id as string, req.body);

            return res.status(200).json({
                success: true,
                message: "Brand updated successfully.",
                data: brand,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteBrand(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await brandService.deleteBrand(req.params.id as string);

            return res.status(200).json({
                success: true,
                message: "Brand deleted successfully.",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreBrand(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const brand = await brandService.restoreBrand(req.params.id as string);

            return res.status(200).json({
                success: true,
                message: "Brand restored successfully.",
                data: brand,
            });

        } catch (error) {
            next(error);
        }
    }

}

export default new BrandController();