import { Request, Response, NextFunction } from "express";
import subCategoryService from "../services/subCategory.service";

class SubCategoryController {

    async createSubCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const subCategory =
                await subCategoryService.createSubCategory(req.body);

            return res.status(201).json({
                success: true,
                message: "Sub Category created successfully.",
                data: subCategory,
            });

        } catch (error) {
            next(error);
        }
    }

    async getAllSubCategories(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const subCategories =
                await subCategoryService.getAllSubCategories(
                    Number(page),
                    Number(limit),
                    search as string,
                    status !== undefined
                        ? status === "true"
                        : undefined
                );

            return res.status(200).json({
                success: true,
                message: "Sub Categories fetched successfully.",
                data: subCategories,
            });

        } catch (error) {
            next(error);
        }
    }

    async getSubCategoryById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const subCategory =
                await subCategoryService.getSubCategoryById(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Sub Category fetched successfully.",
                data: subCategory,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateSubCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const subCategory =
                await subCategoryService.updateSubCategory(req.params.id, req.body);

            return res.status(200).json({
                success: true,
                message: "Sub Category updated successfully.",
                data: subCategory,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteSubCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await subCategoryService.deleteSubCategory(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Sub Category deleted successfully.",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreSubCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const subCategory =
                await subCategoryService.restoreSubCategory(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Sub Category restored successfully.",
                data: subCategory,
            });

        } catch (error) {
            next(error);
        }
    }

    async getSubCategoriesByCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const subCategories =
                await subCategoryService.getByCategory(req.params.categoryId);

            return res.status(200).json({
                success: true,
                message: "Sub Categories fetched successfully.",
                data: subCategories,
            });

        } catch (error) {
            next(error);
        }
    }

}

export default new SubCategoryController();