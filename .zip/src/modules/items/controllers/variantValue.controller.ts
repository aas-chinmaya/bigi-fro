import { Request, Response, NextFunction } from "express";
import variantValueService from "../services/variantValue.service";

class VariantValueController {

    async createVariantValue(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const variantValue = await variantValueService.createVariantValue(req.body);

            return res.status(201).json({
                success: true,
                message: "Variant Value created successfully.",
                data: variantValue,
            });

        } catch (error) {
            next(error);
        }
    }

    async getAllVariantValues(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const variantValues =
                await variantValueService.getAllVariantValues(
                    Number(page),
                    Number(limit),
                    search as string,
                    status !== undefined
                        ? status === "true"
                        : undefined
                );

            return res.status(200).json({
                success: true,
                message: "Variant Values fetched successfully.",
                data: variantValues,
            });

        } catch (error) {
            next(error);
        }
    }

    async getVariantValueById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const variantValue =
                await variantValueService.getVariantValueById(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Variant Value fetched successfully.",
                data: variantValue,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateVariantValue(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const variantValue =
                await variantValueService.updateVariantValue(req.params.id, req.body);

            return res.status(200).json({
                success: true,
                message: "Variant Value updated successfully.",
                data: variantValue,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteVariantValue(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await variantValueService.deleteVariantValue(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Variant Value deleted successfully.",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreVariantValue(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const variantValue =
                await variantValueService.restoreVariantValue(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Variant Value restored successfully.",
                data: variantValue,
            });

        } catch (error) {
            next(error);
        }
    }

}

export default new VariantValueController();