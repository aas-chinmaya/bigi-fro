import { Router } from "express";
import subCategoryController from "../controllers/subCategory.controller";

const router = Router();

/**
 * Create Sub Category
 * POST /api/sub-categories
 */
router.post(
    "/create",
    subCategoryController.createSubCategory
);

/**
 * Get All Sub Categories
 * GET /api/sub-categories?page=1&limit=10&search=&status=true
 */
router.get(
    "/getall",
    subCategoryController.getAllSubCategories
);

/**
 * Get Sub Category By Id
 * GET /api/sub-categories/:id
 */
router.get(
    "/getbyid/:id",
    subCategoryController.getSubCategoryById
);

/**
 * Get Sub Categories By Category
 * GET /api/sub-categories/category/:categoryId
 */
router.get(
    "/category/:categoryId",
    subCategoryController.getSubCategoriesByCategory
);

/**
 * Update Sub Category
 * PUT /api/sub-categories/:id
 */
router.put(
    "/update/:id",
    subCategoryController.updateSubCategory
);

/**
 * Soft Delete Sub Category
 * DELETE /api/sub-categories/:id
 */
router.delete(
    "/delete/:id",
    subCategoryController.deleteSubCategory
);

/**
 * Restore Sub Category
 * PATCH /api/sub-categories/:id/restore
 */
router.patch(
    "/restore/:id",
    subCategoryController.restoreSubCategory
);

export default router;