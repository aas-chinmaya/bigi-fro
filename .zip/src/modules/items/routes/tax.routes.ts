import { Router } from "express";
import taxController from "../controllers/tax.controller";

const router = Router();

/**
 * Create Tax
 */
router.post(
    "/create",
    taxController.createTax
);

/**
 * Get All Taxes
 */
router.get(
    "/getall",
    taxController.getAllTaxes
);

/**
 * Get Tax By ID
 */
router.get(
    "/getbyid/:id",
    taxController.getTaxById
);

/**
 * Update Tax
 */
router.put(
    "/update/:id",
    taxController.updateTax
);

/**
 * Soft Delete Tax
 */
router.delete(
    "/delete/:id",
    taxController.deleteTax
);

/**
 * Restore Tax
 */
router.patch(
    "/restore/:id",
    taxController.restoreTax
);

export default router;