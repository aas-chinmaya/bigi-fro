import { Router } from "express";
import variantTypeController from "../controllers/variantType.controller";

const router = Router();

/**
 * Create Variant Type
 * POST /api/variant-types
 */
router.post(
    "/create",
    variantTypeController.createVariantType
);

/**
 * Get All Variant Types
 * GET /api/variant-types
 */
router.get(
    "/getall",
    variantTypeController.getAllVariantTypes
);

/**
 * Get Variant Type By ID
 * GET /api/variant-types/:id
 */
router.get(
    "/getby/:id",
    variantTypeController.getVariantTypeById
);

/**
 * Update Variant Type
 * PUT /api/variant-types/:id
 */
router.put(
    "/update/:id",
    variantTypeController.updateVariantType
);

/**
 * Soft Delete Variant Type
 * DELETE /api/variant-types/:id
 */
router.delete(
    "/delete/:id",
    variantTypeController.deleteVariantType
);

/**
 * Restore Variant Type
 * PATCH /api/variant-types/:id/restore
 */
router.patch(
    "/:id/restore",
    variantTypeController.restoreVariantType
);

export default router;
