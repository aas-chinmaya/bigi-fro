import { Router } from "express";
import categoryController from "../controllers/category.controller";

const router = Router();

/**
 * Create Category
 * POST /api/categories
 */
router.post("/create", categoryController.createCategory);

/**
 * Get All Categories
 * GET /api/categories?page=1&limit=10&search=&status=true
 */
router.get("/getall", categoryController.getAllCategories);

/**
 * Get Category By Id
 * GET /api/categories/:id
 */
router.get("/getby/:id", categoryController.getCategoryById);

/**
 * Update Category
 * PUT /api/categories/:id
 */
router.put("/update/:id", categoryController.updateCategory);

/**
 * Soft Delete Category
 * DELETE /api/categories/:id
 */
router.delete("/delete/:id", categoryController.deleteCategory);

/**
 * Restore Category
 * PATCH /api/categories/:id/restore
 */
router.patch("/:id/restore", categoryController.restoreCategory);

export default router;