import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class CategoryRepository {

    async create(data: Prisma.ProductCategoryCreateInput) {
        return prisma.productCategory.create({
            data,
        });
    }

    async findById(id: string) {
        return prisma.productCategory.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findByName(categoryName: string) {
        return prisma.productCategory.findFirst({
            where: {
                categoryName,
                deletedAt: null,
            },
        });
    }

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {
        const skip = (page - 1) * limit;

        const where: Prisma.ProductCategoryWhereInput = {
            deletedAt: null,

            ...(search && {
                categoryName: {
                    contains: search,
                    mode: "insensitive",
                },
            }),

            ...(status !== undefined && {
                status,
            }),
        };

        const [categories, total] = await prisma.$transaction([
            prisma.productCategory.findMany({
                where,
                skip,
                take: limit,
                orderBy: {
                    createdAt: "desc",
                },
            }),

            prisma.productCategory.count({
                where,
            }),
        ]);

        return {
            data: categories,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
        };
    }

    async update(id: string, data: Prisma.ProductCategoryUpdateInput) {
        return prisma.productCategory.update({
            where: { id },
            data,
        });
    }

    async softDelete(id: string) {
        return prisma.productCategory.update({
            where: { id },
            data: {
                deletedAt: new Date(),
                status: false,
            },
        });
    }

    async restore(id: string) {
        return prisma.productCategory.update({
            where: { id },
            data: {
                deletedAt: null,
                status: true,
            },
        });
    }
}

export default new CategoryRepository();