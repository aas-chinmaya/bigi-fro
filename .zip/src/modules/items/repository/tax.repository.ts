import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class TaxRepository {

    async create(data: Prisma.TaxCreateInput) {
        return prisma.tax.create({
            data,
        });
    }

    async findById(id: string) {
        return prisma.tax.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findByHsnCode(hsnCode: string) {
        return prisma.tax.findFirst({
            where: {
                hsnCode,
                deletedAt: null,
            },
        });
    }

    async findBySacCode(sacCode: string) {
        return prisma.tax.findFirst({
            where: {
                sacCode,
                deletedAt: null,
            },
        });
    }

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {

        const skip = (page - 1) * limit;

        const where: Prisma.TaxWhereInput = {

            deletedAt: null,

            ...(search && {
                OR: [
                    {
                        hsnCode: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },
                    {
                        sacCode: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },
                ],
            }),

            ...(status !== undefined && {
                status,
            }),

        };

        const [taxes, total] = await prisma.$transaction([

            prisma.tax.findMany({

                where,

                skip,

                take: limit,

                orderBy: {
                    createdAt: "desc",
                },

            }),

            prisma.tax.count({
                where,
            }),

        ]);

        return {

            data: taxes,

            total,

            page,

            limit,

            totalPages: Math.ceil(total / limit),

        };

    }

    async update(
        id: string,
        data: Prisma.TaxUpdateInput
    ) {

        return prisma.tax.update({

            where: {
                id,
            },

            data,

        });

    }

    async softDelete(id: string) {

        return prisma.tax.update({

            where: {
                id,
            },

            data: {

                deletedAt: new Date(),

                status: false,

            },

        });

    }

    async restore(id: string) {

        return prisma.tax.update({

            where: {
                id,
            },

            data: {

                deletedAt: null,

                status: true,

            },

        });

    }

}

export default new TaxRepository();