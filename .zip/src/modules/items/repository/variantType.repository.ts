import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class VariantTypeRepository {

    async create(data: Prisma.VariantTypeCreateInput) {
        return prisma.variantType.create({
            data,
        });
    }

    async findById(id: string) {
        return prisma.variantType.findFirst({
            where: {
                id,
                deletedAt: null,
            },
            include: {
                subCategory: true,
            },
        });
    }

    async findByCode(variantTypeCode: string) {
        return prisma.variantType.findFirst({
            where: {
                variantTypeCode,
                deletedAt: null,
            },
        });
    }

    async findByName(
        subCategoryId: string,
        variantTypeName: string
    ) {
        return prisma.variantType.findFirst({
            where: {
                subCategoryId,
                variantTypeName,
                deletedAt: null,
            },
        });
    }

    async findSubCategory(subCategoryId: string) {
        return prisma.subCategory.findFirst({
            where: {
                id: subCategoryId,
                deletedAt: null,
            },
        });
    }

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {

        const skip = (page - 1) * limit;

        const where: Prisma.VariantTypeWhereInput = {

            deletedAt: null,

            ...(search && {
                OR: [
                    {
                        variantTypeCode: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },
                    {
                        variantTypeName: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },
                ],
            }),

            ...(status !== undefined && {
                status,
            }),

        };

        const [variantTypes, total] = await prisma.$transaction([

            prisma.variantType.findMany({

                where,

                skip,

                take: limit,

                orderBy: {
                    createdAt: "desc",
                },

                include: {
                    subCategory: {
                        select: {
                            id: true,
                            subCategoryName: true,
                        },
                    },
                },

            }),

            prisma.variantType.count({
                where,
            }),

        ]);

        return {

            data: variantTypes,

            total,

            page,

            limit,

            totalPages: Math.ceil(total / limit),

        };

    }

    async update(
        id: string,
        data: Prisma.VariantTypeUpdateInput
    ) {

        return prisma.variantType.update({

            where: {
                id,
            },

            data,

        });

    }

    async softDelete(id: string) {

        return prisma.variantType.update({

            where: {
                id,
            },

            data: {
                deletedAt: new Date(),
                status: false,
            },

        });

    }

    async restore(id: string) {

        return prisma.variantType.update({

            where: {
                id,
            },

            data: {
                deletedAt: null,
                status: true,
            },

        });

    }

}

export default new VariantTypeRepository();