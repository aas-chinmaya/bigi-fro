import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class ProductUnitRepository {

    async create(data: Prisma.ProductUnitCreateInput) {
        return prisma.productUnit.create({
            data,
            include: {
                product: true,
                fromUnit: true,
                toUnit: true,
            },
        });
    }

    async findById(id: string) {
        return prisma.productUnit.findFirst({
            where: {
                id,
                deletedAt: null,
            },
            include: {
                product: true,
                fromUnit: true,
                toUnit: true,
            },
        });
    }

    async findProduct(productId: string) {
        return prisma.product.findFirst({
            where: {
                id: productId,
                deletedAt: null,
            },
        });
    }

    async findUnit(id: string) {
        return prisma.unit.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findDuplicate(
        productId: string,
        fromUnitId: string,
        toUnitId: string
    ) {
        return prisma.productUnit.findFirst({
            where: {
                productId,
                fromUnitId,
                toUnitId,
                deletedAt: null,
            },
        });
    }

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {

        const skip = (page - 1) * limit;

        const where: Prisma.ProductUnitWhereInput = {

            deletedAt: null,

            ...(status !== undefined && {
                status,
            }),

            ...(search && {
                product: {
                    itemName: {
                        contains: search,
                        mode: "insensitive",
                    },
                },
            }),

        };

        const [data, total] = await prisma.$transaction([

            prisma.productUnit.findMany({

                where,

                skip,

                take: limit,

                orderBy: {
                    createdAt: "desc",
                },

                include: {
                    product: true,
                    fromUnit: true,
                    toUnit: true,
                },

            }),

            prisma.productUnit.count({
                where,
            }),

        ]);

        return {

            data,

            total,

            page,

            limit,

            totalPages: Math.ceil(total / limit),

        };

    }

    async update(
        id: string,
        data: Prisma.ProductUnitUpdateInput
    ) {

        return prisma.productUnit.update({

            where: {
                id,
            },

            data,

            include: {
                product: true,
                fromUnit: true,
                toUnit: true,
            },

        });

    }

    async softDelete(id: string) {

        return prisma.productUnit.update({

            where: {
                id,
            },

            data: {
                deletedAt: new Date(),
                status: false,
            },

        });

    }

    async restore(id: string) {

        return prisma.productUnit.update({

            where: {
                id,
            },

            data: {
                deletedAt: null,
                status: true,
            },

        });

    }

    async findByBarcode(barcode: string) {

    return prisma.product.findFirst({

        where: {

            barcode,

            deletedAt: null,

        },

    });

}

}


export default new ProductUnitRepository();