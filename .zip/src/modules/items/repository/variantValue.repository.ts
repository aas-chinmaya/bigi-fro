import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class VariantValueRepository {

    async create(data: Prisma.VariantValueCreateInput) {
        return prisma.variantValue.create({
            data,
        });
    }

    async findById(id: string) {
        return prisma.variantValue.findFirst({
            where: {
                id,
                deletedAt: null,
            },
            include: {
                variantType: true,
            },
        });
    }

    async findVariantType(id: string) {
        return prisma.variantType.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findByValue(
        variantTypeId: string,
        value: string
    ) {
        return prisma.variantValue.findFirst({
            where: {
                variantTypeId,
                value,
                deletedAt: null,
            },
        });
    }

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {

        const skip = (page - 1) * limit;

        const where: Prisma.VariantValueWhereInput = {

            deletedAt: null,

            ...(search && {
                OR: [
                    {
                        value: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },
                    {
                        shortName: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },
                ],
            }),

            ...(status !== undefined && {
                status,
            }),

        };

        const [variantValues, total] = await prisma.$transaction([

            prisma.variantValue.findMany({

                where,

                skip,

                take: limit,

                orderBy: {
                    displayOrder: "asc",
                },

                include: {

                    variantType: {
                        select: {
                            id: true,
                            variantTypeName: true,
                            variantTypeCode: true,
                        },
                    },

                },

            }),

            prisma.variantValue.count({
                where,
            }),

        ]);

        return {

            data: variantValues,

            total,

            page,

            limit,

            totalPages: Math.ceil(total / limit),

        };

    }

    async update(
        id: string,
        data: Prisma.VariantValueUpdateInput
    ) {

        return prisma.variantValue.update({

            where: {
                id,
            },

            data,

        });

    }

    async softDelete(id: string) {

        return prisma.variantValue.update({

            where: {
                id,
            },

            data: {

                deletedAt: new Date(),

                status: false,

            },

        });

    }

    async restore(id: string) {

        return prisma.variantValue.update({

            where: {
                id,
            },

            data: {

                deletedAt: null,

                status: true,

            },

        });

    }

}

export default new VariantValueRepository();