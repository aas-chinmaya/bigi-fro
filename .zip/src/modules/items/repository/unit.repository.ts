import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class UnitRepository {

    async create(data: Prisma.UnitCreateInput) {
        return prisma.unit.create({
            data,
        });
    }

    async findById(id: string) {
        return prisma.unit.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findByName(unitName: string) {
        return prisma.unit.findFirst({
            where: {
                unitName,
                deletedAt: null,
            },
        });
    }

    async findByShortName(shortName: string) {
        return prisma.unit.findFirst({
            where: {
                shortName,
                deletedAt: null,
            },
        });
    }

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {

        const skip = (page - 1) * limit;

        const where: Prisma.UnitWhereInput = {

            deletedAt: null,

            ...(search && {
                OR: [
                    {
                        unitName: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },
                    {
                        shortName: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },
                ],
            }),

            ...(status !== undefined && {
                status,
            }),

        };

        const [units, total] = await prisma.$transaction([

            prisma.unit.findMany({

                where,

                skip,

                take: limit,

                orderBy: {
                    createdAt: "desc",
                },

            }),

            prisma.unit.count({
                where,
            }),

        ]);

        return {

            data: units,

            total,

            page,

            limit,

            totalPages: Math.ceil(total / limit),

        };

    }

    async update(
        id: string,
        data: Prisma.UnitUpdateInput
    ) {

        return prisma.unit.update({

            where: {
                id,
            },

            data,

        });

    }

    async softDelete(id: string) {

        return prisma.unit.update({

            where: {
                id,
            },

            data: {

                deletedAt: new Date(),

                status: false,

            },

        });

    }

    async restore(id: string) {

        return prisma.unit.update({

            where: {
                id,
            },

            data: {

                deletedAt: null,

                status: true,

            },

        });

    }

}

export default new UnitRepository();