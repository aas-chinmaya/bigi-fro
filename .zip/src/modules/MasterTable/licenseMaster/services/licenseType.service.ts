import ConflictError from "../../../../common/exceptions/ConflictError";
import NotFoundError from "../../../../common/exceptions/NotFoundError";
import ValidationError from "../../../../common/exceptions/ValidationError";
import * as repository from "../repository/licenseType.repository";

export const createLicenseTypeService = async (
  licenseTypeName: string,
  description?: string,
  icon?: string
) => {
  if (!licenseTypeName?.trim()) {
    throw new ValidationError("License type name is required.");
  }

  const existing = await repository.findByName(
    licenseTypeName
  );

  if (existing) {
    if (existing.isDeleted) {
      return repository.restoreLicenseType(existing.id, {
        licenseTypeName,
        description,
        icon,
      });
    }

    throw new ConflictError(
      "License type already exists."
    );
  }

  return repository.createLicenseType({
    licenseTypeName,
    description,
    icon,
  });
};

export const getLicenseTypesService = async () => {
  return repository.getAllLicenseTypes();
};

export const getLicenseTypeByIdService = async (
  id: string
) => {
  const licenseType =
    await repository.findById(id);

  if (!licenseType) {
    throw new NotFoundError(
      "License type not found."
    );
  }

  return licenseType;
};

export const updateLicenseTypeService = async (
  id: string,
  body: any
) => {
  const licenseType =
    await repository.findById(id);

  if (!licenseType) {
    throw new NotFoundError(
      "License type not found."
    );
  }

  if (body.licenseTypeName) {
    const existing =
      await repository.findByName(
        body.licenseTypeName
      );

    if (
      existing &&
      existing.id !== id &&
      !existing.isDeleted
    ) {
      throw new ConflictError(
        "License type already exists."
      );
    }
  }

  return repository.updateLicenseType(
    id,
    body
  );
};

export const deleteLicenseTypeService = async (
  id: string
) => {
  const licenseType =
    await repository.findById(id);

  if (!licenseType) {
    throw new NotFoundError(
      "License type not found."
    );
  }

  await repository.deleteLicenseType(id);
};