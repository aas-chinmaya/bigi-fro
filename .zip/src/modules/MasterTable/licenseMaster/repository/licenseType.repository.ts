import prisma from "../../../../config/db";

/**
 * Create License Type
 */
export const createLicenseType = (data: {
  licenseTypeName: string;
  description?: string;
  icon?: string;
}) => {
  return prisma.licenseType.create({
    data,
  });
};

/**
 * Find By ID
 */
export const findById = (id: string) => {
  return prisma.licenseType.findFirst({
    where: {
      id,
      isDeleted: false,
    },
  });
};

/**
 * Find By Name
 */
export const findByName = (licenseTypeName: string) => {
  return prisma.licenseType.findFirst({
    where: {
      licenseTypeName,
    },
  });
};

/**
 * Get All
 */
export const getAllLicenseTypes = () => {
  return prisma.licenseType.findMany({
    where: {
      isDeleted: false,
    },
    orderBy: {
      licenseTypeName: "asc",
    },
  });
};

/**
 * Update
 */
export const updateLicenseType = (
  id: string,
  data: {
    licenseTypeName?: string;
    description?: string;
    icon?: string;
    status?: boolean;
  }
) => {
  return prisma.licenseType.update({
    where: {
      id,
    },
    data,
  });
};

/**
 * Soft Delete
 */
export const deleteLicenseType = (id: string) => {
  return prisma.licenseType.update({
    where: {
      id,
    },
    data: {
      isDeleted: true,
      deletedAt: new Date(),
    },
  });
};

/**
 * Restore
 */
export const restoreLicenseType = (
  id: string,
  data: {
    licenseTypeName: string;
    description?: string;
    icon?: string;
  }
) => {
  return prisma.licenseType.update({
    where: {
      id,
    },
    data: {
      ...data,
      status: true,
      isDeleted: false,
      deletedAt: null,
    },
  });
};