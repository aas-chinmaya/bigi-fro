import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/licenseType.service";

export const createLicenseType = asyncHandler(
  async (req: Request, res: Response) => {
    const {
      licenseTypeName,
      description,
      icon,
    } = req.body;

    const result =
      await service.createLicenseTypeService(
        licenseTypeName,
        description,
        icon
      );

    return res.status(201).json({
      success: true,
      message:
        "License type created successfully.",
      data: result,
    });
  }
);

export const getLicenseTypes = asyncHandler(
  async (_req: Request, res: Response) => {
    const result =
      await service.getLicenseTypesService();

    return res.status(200).json({
      success: true,
      data: result,
    });
  }
);

export const getLicenseTypeById = asyncHandler(
  async (req: Request, res: Response) => {
    const result =
      await service.getLicenseTypeByIdService(
        req.params.id as string
      );

    return res.status(200).json({
      success: true,
      data: result,
    });
  }
);

export const updateLicenseType = asyncHandler(
  async (req: Request, res: Response) => {
    const result =
      await service.updateLicenseTypeService(
        req.params.id as string,
        req.body
      );

    return res.status(200).json({
      success: true,
      message:
        "License type updated successfully.",
      data: result,
    });
  }
);

export const deleteLicenseType = asyncHandler(
  async (req: Request, res: Response) => {
    await service.deleteLicenseTypeService(
      req.params.id as string
    );

    return res.status(200).json({
      success: true,
      message:
        "License type deleted successfully.",
    });
  }
);