import { Router } from "express";
import * as controller from "../controller/licenseType.controller";

const router = Router();

router.post("/createLicenseType", controller.createLicenseType);
router.get("/listLicenseTypes", controller.getLicenseTypes);
router.get("/detailLicenseType/:id", controller.getLicenseTypeById);
router.put("/updateLicenseType/:id", controller.updateLicenseType);
router.delete("/deleteLicenseType/:id", controller.deleteLicenseType);

export default router;