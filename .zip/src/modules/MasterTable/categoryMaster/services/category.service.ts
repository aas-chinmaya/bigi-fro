import ConflictError from "../../../../common/exceptions/ConflictError";
import NotFoundError from "../../../../common/exceptions/NotFoundError";
import ValidationError from "../../../../common/exceptions/ValidationError";
import * as repository from "../repository/category.repository";

export const createCategoryService = async (
  categoryName: string,
  description: string | undefined,
  icon: string
) => {
  if (!categoryName?.trim()) {
    throw new ValidationError("Category name is required.");
  }

  const exists = await repository.findByName(categoryName);

  if (exists) {
    if (!exists.isDeleted) {
      throw new ConflictError("Category already exists");
    }

    return repository.restoreCategory(exists.id, description, icon);
  }

  return repository.createCategory({
    categoryName,
    description,
    icon,
  });
};

export const getCategoriesService = async () => {
  return repository.getAll();
};

export const getCategoryByIdService = async (id: string) => {
  const category = await repository.findById(id);

  if (!category) {
    throw new NotFoundError("Category not found");
  }

  return category;
};

export const updateCategoryService = async (id: string, body: any) => {
  const category = await repository.findById(id);

  if (!category) {
    throw new NotFoundError("Category not found");
  }

  return repository.updateCategory(id, body);
};

export const deleteCategoryService = async (id: string) => {
  const category = await repository.findById(id);

  if (!category) {
    throw new NotFoundError("Category not found");
  }

  await repository.deleteCategory(id);
};

