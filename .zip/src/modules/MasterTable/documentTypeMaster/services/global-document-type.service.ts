import {
  create,
  findAll,
  findById,
  findByCode,
  update,
  softDelete,
} from "../repository/global-document-type.repository";

interface CreateGlobalDocumentTypeInput {
  code: string;
  name: string;
  description?: string;
}

interface UpdateGlobalDocumentTypeInput {
  code?: string;
  name?: string;
  description?: string;
  isActive?: boolean;

}


export const createDocumentType = (
  data: CreateGlobalDocumentTypeInput
) => {
  const code = data.code?.trim().toUpperCase();
  const name = data.name?.trim();

  if (!code) {
    return Promise.reject(
      new Error("Document type code is required")
    );
  }

  if (!name) {
    return Promise.reject(
      new Error("Document type name is required")
    );
  }

  return findByCode(code).then((existing) => {
    if (existing) {
      if (existing.isActive) {
        throw new Error(
          "Document type with this code already exists"
        );
      }

      throw new Error(
        "Document type with this code already exists but is inactive"
      );
    }

    return create({
      code,
      name,
      description: data.description?.trim() || null,
      isActive: true,
    });
  });
};


// export const getAllDocumentTypes = () => {
//   return findAll();
// };
export const getAllDocumentTypes = (
  page: number,
  limit: number
) => {
  const skip = (page - 1) * limit;

  return findAll(skip, limit).then(
    ([documentTypes, total]) => {
      const totalPages = Math.ceil(total / limit);

      return {
        data: documentTypes,
        pagination: {
          page,
          limit,
          total,
          totalPages,
          hasNextPage: page < totalPages,
          hasPreviousPage: page > 1,
        },
      };
    }
  );
};

export const getDocumentTypeById = (id: string) => {
  return findById(id).then((documentType) => {
    if (!documentType) {
      throw new Error("Document type not found");
    }

    return documentType;
  });
};

// export const updateDocumentType = (
//   id: string,
//   data: UpdateGlobalDocumentTypeInput
// ) => {
//   return findById(id).then((existing) => {
//     if (!existing) {
//       throw new Error("Document type not found");
//     }

//     let code: string | undefined;

//     if (data.code !== undefined) {
//       code = data.code.trim().toUpperCase();

//       if (!code) {
//         throw new Error(
//           "Document type code cannot be empty"
//         );
//       }

//       return findByCode(code).then((duplicate) => {
//         if (duplicate && duplicate.id !== id) {
//           throw new Error(
//             "Document type with this code already exists"
//           );
//         }

//         return performUpdate(id, data, code);
//       });
//     }

//     return performUpdate(id, data);
//   });
// };


// const performUpdate = (
//   id: string,
//   data: UpdateGlobalDocumentTypeInput,
//   code?: string
// ) => {
//   let name: string | undefined;

//   if (data.name !== undefined) {
//     name = data.name.trim();

//     if (!name) {
//       throw new Error(
//         "Document type name cannot be empty"
//       );
//     }
//   }

//   let description: string | null | undefined;

//   if (data.description !== undefined) {
//     description = data.description.trim() || null;
//   }

//   return update(id, {
//     ...(code !== undefined && {
//       code,
//     }),

//     ...(name !== undefined && {
//       name,
//     }),

//     ...(description !== undefined && {
//       description,
//     }),
//   });
// };

export const updateDocumentType = (
  id: string,
  data: UpdateGlobalDocumentTypeInput
) => {
  return findById(id).then((existing) => {
    if (!existing) {
      throw new Error("Document type not found");
    }

    let code: string | undefined;

    /**
     * Validate code
     */
    if (data.code !== undefined) {
      code = data.code.trim().toUpperCase();

      if (!code) {
        throw new Error(
          "Document type code cannot be empty"
        );
      }

      return findByCode(code).then((duplicate) => {
        if (
          duplicate &&
          duplicate.id !== id
        ) {
          throw new Error(
            "Document type with this code already exists"
          );
        }

        return performUpdate(
          id,
          data,
          code
        );
      });
    }

    return performUpdate(id, data);
  });
};

/**
 * Perform actual update
 */
const performUpdate = (
  id: string,
  data: UpdateGlobalDocumentTypeInput,
  code?: string
) => {
  let name: string | undefined;

  /**
   * Validate name
   */
  if (data.name !== undefined) {
    name = data.name.trim();

    if (!name) {
      throw new Error(
        "Document type name cannot be empty"
      );
    }
  }

  let description:
    | string
    | null
    | undefined;

  /**
   * Handle description
   */
  if (data.description !== undefined) {
    description =
      data.description.trim() || null;
  }

  /**
   * Validate status
   */
  if (
    data.isActive !== undefined &&
    typeof data.isActive !== "boolean"
  ) {
    throw new Error(
      "isActive must be a boolean value"
    );
  }

  /**
   * Update only fields that were provided
   */
  return update(id, {
    ...(code !== undefined && {
      code,
    }),

    ...(name !== undefined && {
      name,
    }),

    ...(description !== undefined && {
      description,
    }),

    ...(data.isActive !== undefined && {
      isActive: data.isActive,
    }),
  });
};

export const deleteDocumentType = (id: string) => {
  return findById(id).then((existing) => {
    if (!existing) {
      throw new Error("Document type not found");
    }

    return softDelete(id);
  });
};