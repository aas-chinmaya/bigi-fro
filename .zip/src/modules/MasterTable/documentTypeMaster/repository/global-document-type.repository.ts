import prisma from "../../../../config/db";

import type { Prisma } from "@prisma/client";


export const create = (data: Prisma.GlobalDocumentTypeCreateInput) => {
  return prisma.globalDocumentType.create({
    data,
  });
};


// export const findAll = (skip: number, take: number) => {
//   return Promise.all([
//     prisma.globalDocumentType.findMany({
//       where: {
//         isActive: true,
//       },
//       orderBy: {
//         createdAt: "desc",
//       },
//       skip,
//       take,
//     }),

//     prisma.globalDocumentType.count({
//       where: {
//         isActive: true,
//       },
//     }),
//   ]);
// };
export const findAll = (skip: number, take: number) => {
  return Promise.all([
    prisma.globalDocumentType.findMany({
      where: {
        isActive: true,
      },
      orderBy: {
        createdAt: "desc",
      },
      skip,
      take,
    }),

    prisma.globalDocumentType.count({
      where: {
        isActive: true,
      },
    }),
  ]);
};

export const findById = (id: string) => {
  return prisma.globalDocumentType.findFirst({
    where: {
      id,
      isActive: true,
    },
  });
};


// export const findByCode = (code: string) => {
//   return prisma.globalDocumentType.findUnique({
//     where: {
//       code,
//     },
//   });
// };
export const findByCode = (code: string) => {
  return prisma.globalDocumentType.findUnique({
    where: {
      code,
    },
  });
};

export const update = (
  id: string,
  data: Prisma.GlobalDocumentTypeUpdateInput
) => {
  return prisma.globalDocumentType.update({
    where: {
      id,
    },
    data,
  });
};


export const softDelete = (id: string) => {
  return prisma.globalDocumentType.update({
    where: {
      id,
    },
    data: {
      isActive: false,
    },
  });
};