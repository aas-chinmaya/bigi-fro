import { Router } from "express";
import {
  create,
  getAll,
  getById,
  update,
  remove,
} from "../controllers/global-document-type.controller";

const router = Router();


router.post(
  "/createglobaldocumenttype",
  create
);

router.get(
  "/getallglobaldocumenttypes",
  getAll
);

router.get(
  "/getglobaldocumenttypebyid/:id",
  getById
);


router.put(
  "/updateglobaldocumenttype/:id",
  update
);

router.delete(
  "/deleteglobaldocumenttype/:id",
  remove
);

export default router;