import { Request, Response } from "express";
// import globalDocumentTypeService from "../services/global-document-type.service";
import {
  createDocumentType,
  getAllDocumentTypes,
  getDocumentTypeById,
  updateDocumentType,
  deleteDocumentType,
} from "../services/global-document-type.service";
// POST /global-document-types
export const create = (req: Request, res: Response) => {
  console.log("Create Global Document Type - req.body:", req.body);

  return createDocumentType(req.body)
    .then((documentType) => {
      return res.status(201).json({
        success: true,
        message: "Global document type created successfully",
        data: documentType,
      });
    })
    .catch((error: any) => {
      console.error("Create Global Document Type Error:", error);

      return res.status(400).json({
        success: false,
        message:
          error.message ||
          "Failed to create global document type",
      });
    });
};

// GET /global-document-types
export const getAll = (req: Request, res: Response) => {
  const page = Math.max(
    Number(req.query.page),
    1
  );

  const limit = Math.min(
    Math.max(Number(req.query.limit) ),
    100
  );

  return getAllDocumentTypes(page, limit)
    .then((result) => {
      return res.status(200).json({
        success: true,
        message:
          "Global document types fetched successfully",
        data: result.data,
        pagination: result.pagination,
      });
    })
    .catch((error: any) => {
      console.error(
        "Get All Global Document Types Error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          error.message ||
          "Failed to fetch global document types",
      });
    });
};

// GET /global-document-types/:id
export const getById = (req: Request, res: Response) => {
  const { id } = req.params;

  return getDocumentTypeById(id as string)
    .then((documentType) => {
      return res.status(200).json({
        success: true,
        message: "Global document type fetched successfully",
        data: documentType,
      });
    })
    .catch((error: any) => {
      return res.status(404).json({
        success: false,
        message:
          error.message ||
          "Global document type not found",
      });
    });
};

// PUT /global-document-types/:id
export const update = (req: Request, res: Response) => {
  const { id } = req.params;

  return updateDocumentType(id as string, req.body)
    .then((documentType) => {
      return res.status(200).json({
        success: true,
        message: "Global document type updated successfully",
        data: documentType,
      });
    })
    .catch((error: any) => {
      return res.status(400).json({
        success: false,
        message:
          error.message ||
          "Failed to update global document type",
      });
    });
};

// DELETE /global-document-types/:id
export const remove = (req: Request, res: Response) => {
  const { id } = req.params;

  return deleteDocumentType(id as string)
    .then(() => {
      return res.status(200).json({
        success: true,
        message: "Global document type deleted successfully",
      });
    })
    .catch((error: any) => {
      return res.status(400).json({
        success: false,
        message:
          error.message ||
          "Failed to delete global document type",
      });
    });
};