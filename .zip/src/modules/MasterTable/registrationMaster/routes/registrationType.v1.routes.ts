import { Router } from "express";
import * as controller from "../controller/registrationType.controller";

const router = Router();

router.post("/createRegistrationType", controller.createRegistrationType);

router.get("/getAllRegistrationTypes", controller.getAllRegistrationTypes);

router.put("/updateRegistrationType/:id", controller.updateRegistrationType);

router.delete("/deleteRegistrationType/:id", controller.deleteRegistrationType);

export default router;
