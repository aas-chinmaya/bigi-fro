import ConflictError from "../../../../common/exceptions/ConflictError";
import NotFoundError from "../../../../common/exceptions/NotFoundError";
import ValidationError from "../../../../common/exceptions/ValidationError";
import * as repository from "../repository/currency.repository";

export const createCurrencyService = async (
  currencyName: string,
  currencyCode: string,
  currencySymbol: string,
  countryName?: string
) => {
  if (!currencyName?.trim() || !currencyCode?.trim() || !currencySymbol?.trim()) {
    throw new ValidationError("Currency name, code, and symbol are required.");
  }

  const existingCode = await repository.findByCode(currencyCode);

  if (existingCode) {
    if (existingCode.isDeleted) {
      return repository.restoreCurrency(existingCode.id, {
        currencyName,
        currencyCode,
        currencySymbol,
        countryName,
      });
    }

    throw new ConflictError("Currency code already exists.");
  }

  const existingName = await repository.findByName(currencyName);

  if (existingName) {
    throw new ConflictError("Currency name already exists.");
  }

  return repository.createCurrency({
    currencyName,
    currencyCode,
    currencySymbol,
    countryName,
  });
};

export const getCurrenciesService = async () => {
  return repository.getAllCurrencies();
};

export const getCurrencyByIdService = async (id: string) => {
  const currency = await repository.findById(id);

  if (!currency) {
    throw new NotFoundError("Currency not found.");
  }

  return currency;
};

export const updateCurrencyService = async (id: string, body: any) => {
  const currency = await repository.findById(id);

  if (!currency) {
    throw new NotFoundError("Currency not found.");
  }

  if (body.currencyCode) {
    const existingCode = await repository.findByCode(body.currencyCode);

    if (existingCode && existingCode.id !== id && !existingCode.isDeleted) {
      throw new ConflictError("Currency code already exists.");
    }
  }

  if (body.currencyName) {
    const existingName = await repository.findByName(body.currencyName);

    if (existingName && existingName.id !== id) {
      throw new ConflictError("Currency name already exists.");
    }
  }

  return repository.updateCurrency(id, body);
};

export const deleteCurrencyService = async (id: string) => {
  const currency = await repository.findById(id);

  if (!currency) {
    throw new NotFoundError("Currency not found.");
  }

  await repository.deleteCurrency(id);
};
