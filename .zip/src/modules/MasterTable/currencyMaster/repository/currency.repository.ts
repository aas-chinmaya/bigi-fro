import prisma from "../../../../config/db";

/**
 * Create Currency
 */
export const createCurrency = (data: {
  currencyName: string;
  currencyCode: string;
  currencySymbol: string;
  countryName?: string;
}) => {
  return prisma.currency.create({
    data,
  });
};

/**
 * Find Currency By ID
 */
export const findById = (id: string) => {
  return prisma.currency.findFirst({
    where: {
      id,
      isDeleted: false,
    },
  });
};

/**
 * Find Currency By Code
 */
export const findByCode = (currencyCode: string) => {
  return prisma.currency.findFirst({
    where: {
      currencyCode,
    },
  });
};


export const findByName = (currencyName: string) => {
  return prisma.currency.findFirst({
    where: {
      currencyName,
      isDeleted: false,
    },
  });
};

/**
 * Get All Currencies
 */
export const getAllCurrencies = () => {
  return prisma.currency.findMany({
    where: {
      isDeleted: false,
    },
    orderBy: {
      currencyName: "asc",
    },
  });
};

/**
 * Update Currency
 */
export const updateCurrency = (
  id: string,
  data: {
    currencyName?: string;
    currencyCode?: string;
    currencySymbol?: string;
    countryName?: string;
    status?: boolean;
  }
) => {
  return prisma.currency.update({
    where: {
      id,
    },
    data,
  });
};

/**
 * Soft Delete Currency
 */
export const deleteCurrency = (id: string) => {
  return prisma.currency.update({
    where: {
      id,
    },
    data: {
      isDeleted: true,
      deletedAt: new Date(),
    },
  });
};

/**
 * Restore Currency
 */
export const restoreCurrency = (
  id: string,
  data: {
    currencyName: string;
    currencyCode: string;
    currencySymbol: string;
    countryName?: string;
  }
) => {
  return prisma.currency.update({
    where: {
      id,
    },
    data: {
      ...data,
      status: true,
      isDeleted: false,
      deletedAt: null,
    },
  });
};
