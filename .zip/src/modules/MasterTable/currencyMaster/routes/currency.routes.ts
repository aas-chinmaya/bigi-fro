import { Router } from "express";
import * as controller from "../controllers/currency.controller";

const router = Router();

// Create Currency
router.post("/createCurrency", controller.createCurrency);

// Get All Currencies
router.get("/getAllCurrencies", controller.getCurrencies);

// Get Currency By Id
router.get("/getCurrencyById/:id", controller.getCurrencyById);

// Update Currency
router.put("/updateCurrency/:id", controller.updateCurrency);

// Delete Currency
router.delete("/deleteCurrency/:id", controller.deleteCurrency);

export default router;