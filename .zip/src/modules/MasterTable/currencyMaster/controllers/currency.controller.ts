import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/currency.service";

export const createCurrency = asyncHandler(async (req: Request, res: Response) => {
  const { currencyName, currencyCode, currencySymbol, countryName } = req.body;
  const result = await service.createCurrencyService(currencyName, currencyCode, currencySymbol, countryName);

  return res.status(201).json({
    success: true,
    message: "Currency created successfully.",
    data: result,
  });
});

export const getCurrencies = asyncHandler(async (_req: Request, res: Response) => {
  const result = await service.getCurrenciesService();

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const getCurrencyById = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getCurrencyByIdService(req.params.id as string);

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const updateCurrency = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateCurrencyService(req.params.id as string, req.body);

  return res.status(200).json({
    success: true,
    message: "Currency updated successfully.",
    data: result,
  });
});

export const deleteCurrency = asyncHandler(async (req: Request, res: Response) => {
  await service.deleteCurrencyService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: "Currency deleted successfully.",
  });
});