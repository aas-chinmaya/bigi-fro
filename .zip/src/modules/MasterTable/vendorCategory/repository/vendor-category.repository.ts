import prisma from "../../../../config/db";
import { Prisma } from "@prisma/client";

/**
 * Get all vendor categories
 */
export const findAll = async (
  skip: number,
  take: number
) => {
  return prisma.vendorCategory.findMany({
    skip,
    take,
    orderBy: {
      createdAt: "desc",
    },
  });
};

/**
 * Count vendor categories
 */
export const count = async () => {
  return prisma.vendorCategory.count();
};

/**
 * Get vendor category by ID
 */
export const findById = async (id: string) => {
  return prisma.vendorCategory.findUnique({
    where: {
      id,
    },
  });
};

/**
 * Get vendor category by code
 */
export const findByCode = async (code: string) => {
  return prisma.vendorCategory.findUnique({
    where: {
      code,
    },
  });
};

/**
 * Get vendor category by name
 */
export const findByName = async (name: string) => {
  return prisma.vendorCategory.findFirst({
    where: {
      name: {
        equals: name,
        mode: "insensitive",
      },
    },
  });
};

/**
 * Create vendor category
 */
export const create = async (
  data: Prisma.VendorCategoryCreateInput
) => {
  return prisma.vendorCategory.create({
    data,
  });
};

/**
 * Update vendor category
 */
export const update = async (
  id: string,
  data: Prisma.VendorCategoryUpdateInput
) => {
  return prisma.vendorCategory.update({
    where: {
      id,
    },
    data,
  });
};

/**
 * Delete vendor category
 */
export const remove = async (id: string) => {
  return prisma.vendorCategory.delete({
    where: {
      id,
    },
  });
};