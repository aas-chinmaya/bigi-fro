import { Request, Response } from "express";
import * as vendorCategoryService from "../services/vendor-category.service";

/**
 * GET /vendor-categories
 */
export const getAll = async (
  req: Request,
  res: Response
) => {
  try {
    const page = Math.max(
      Number(req.query.page) || 1,
      1
    );

    const limit = Math.min(
      Math.max(
        Number(req.query.limit) || 10,
        1
      ),
      100
    );

    const result =
      await vendorCategoryService.getAllVendorCategories(
        page,
        limit
      );

    return res.status(200).json({
      success: true,
      message: "Vendor categories fetched successfully",
      ...result,
    });
  } catch (error) {
    console.error(
      "Get Vendor Categories Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Failed to fetch vendor categories",
    });
  }
};

/**
 * GET /vendor-categories/:id
 */
export const getById = async (
  req: Request,
  res: Response
) => {
  try {
    const { id } = req.params;

    const category =
      await vendorCategoryService.getVendorCategoryById(
        id as string
      );

    return res.status(200).json({
      success: true,
      message: "Vendor category fetched successfully",
      data: category,
    });
  } catch (error: any) {
    console.error(
      "Get Vendor Category Error:",
      error
    );

    if (
      error.message ===
      "Vendor category not found"
    ) {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to fetch vendor category",
    });
  }
};

/**
 * POST /vendor-categories
 */
export const create = async (
  req: Request,
  res: Response
) => {
  try {
    console.log(
      "Create Vendor Category - req.body:",
      req.body
    );

    const {
      code,
      name,
      description,
      status,
    } = req.body;

    const category =
      await vendorCategoryService.createVendorCategory(
        {
          code,
          name,
          description,
          status,
        }
      );

    return res.status(201).json({
      success: true,
      message: "Vendor category created successfully",
      data: category,
    });
  } catch (error: any) {
    console.error(
      "Create Vendor Category Error:",
      error
    );

    if (
      error.message ===
        "Vendor category code is required" ||
      error.message ===
        "Vendor category name is required"
    ) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    if (
      error.message ===
        "Vendor category code already exists" ||
      error.message ===
        "Vendor category name already exists"
    ) {
      return res.status(409).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to create vendor category",
    });
  }
};

/**
 * PUT /vendor-categories/:id
 */
export const update = async (
  req: Request,
  res: Response
) => {
  try {
    const { id } = req.params;

    console.log(
      "Update Vendor Category - req.body:",
      req.body
    );

    const {
      code,
      name,
      description,
      status,
    } = req.body;

    const category =
      await vendorCategoryService.updateVendorCategory(
        id as string,
        {
          code,
          name,
          description,
          status,
        }
      );

    return res.status(200).json({
      success: true,
      message: "Vendor category updated successfully",
      data: category,
    });
  } catch (error: any) {
    console.error(
      "Update Vendor Category Error:",
      error
    );

    if (
      error.message ===
      "Vendor category not found"
    ) {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    if (
      error.message ===
        "Vendor category code already exists" ||
      error.message ===
        "Vendor category name already exists"
    ) {
      return res.status(409).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to update vendor category",
    });
  }
};

/**
 * DELETE /vendor-categories/:id
 */
export const remove = async (
  req: Request,
  res: Response
) => {
  try {
    const { id } = req.params;

    await vendorCategoryService.deleteVendorCategory(
      id as string
    );

    return res.status(200).json({
      success: true,
      message: "Vendor category deleted successfully",
    });
  } catch (error: any) {
    console.error(
      "Delete Vendor Category Error:",
      error
    );

    if (
      error.message ===
      "Vendor category not found"
    ) {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to delete vendor category",
    });
  }
};