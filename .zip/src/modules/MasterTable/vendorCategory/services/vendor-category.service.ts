import { Prisma } from "@prisma/client";
import * as vendorCategoryRepository from "../repository/vendor-category.repository";

/**
 * Get all vendor categories
 */
export const getAllVendorCategories = async (
  page: number = 1,
  limit: number = 10
) => {
  const skip = (page - 1) * limit;

  const [categories, total] = await Promise.all([
    vendorCategoryRepository.findAll(skip, limit),
    vendorCategoryRepository.count(),
  ]);

  return {
    data: categories,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  };
};

/**
 * Get vendor category by ID
 */
export const getVendorCategoryById = async (id: string) => {
  const category =
    await vendorCategoryRepository.findById(id);

  if (!category) {
    throw new Error("Vendor category not found");
  }

  return category;
};

/**
 * Create vendor category
 */
export const createVendorCategory = async (
  data: {
    code: string;
    name: string;
    description?: string;
    status?: string;
  }
) => {
  const code = data.code.trim().toUpperCase();
  const name = data.name.trim();

  if (!code) {
    throw new Error("Vendor category code is required");
  }

  if (!name) {
    throw new Error("Vendor category name is required");
  }

  const existingCode =
    await vendorCategoryRepository.findByCode(code);

  if (existingCode) {
    throw new Error(
      "Vendor category code already exists"
    );
  }

  const existingName =
    await vendorCategoryRepository.findByName(name);

  if (existingName) {
    throw new Error(
      "Vendor category name already exists"
    );
  }

  const createData: Prisma.VendorCategoryCreateInput = {
    code,
    name,
    description: data.description?.trim() || null,
    status: data.status || "ACTIVE",
  };

  return vendorCategoryRepository.create(createData);
};

/**
 * Update vendor category
 */
export const updateVendorCategory = async (
  id: string,
  data: {
    code?: string;
    name?: string;
    description?: string;
    status?: string;
  }
) => {
  const existing =
    await vendorCategoryRepository.findById(id);

  if (!existing) {
    throw new Error("Vendor category not found");
  }

  if (data.code) {
    const code = data.code.trim().toUpperCase();

    const existingCode =
      await vendorCategoryRepository.findByCode(code);

    if (
      existingCode &&
      existingCode.id !== id
    ) {
      throw new Error(
        "Vendor category code already exists"
      );
    }

    data.code = code;
  }

  if (data.name) {
    const name = data.name.trim();

    const existingName =
      await vendorCategoryRepository.findByName(name);

    if (
      existingName &&
      existingName.id !== id
    ) {
      throw new Error(
        "Vendor category name already exists"
      );
    }

    data.name = name;
  }

  const updateData: Prisma.VendorCategoryUpdateInput = {};

  if (data.code !== undefined) {
    updateData.code = data.code;
  }

  if (data.name !== undefined) {
    updateData.name = data.name;
  }

  if (data.description !== undefined) {
    updateData.description =
      data.description.trim() || null;
  }

  if (data.status !== undefined) {
    updateData.status = data.status;
  }

  return vendorCategoryRepository.update(
    id,
    updateData
  );
};

/**
 * Delete vendor category
 */
export const deleteVendorCategory = async (
  id: string
) => {
  const existing =
    await vendorCategoryRepository.findById(id);

  if (!existing) {
    throw new Error("Vendor category not found");
  }

  return vendorCategoryRepository.remove(id);
};