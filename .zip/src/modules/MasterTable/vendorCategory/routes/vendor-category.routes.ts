import { Router } from "express";
import {
  getAll,
  getById,
  create,
  update,
  remove,
} from "../controllers/vendor-category.controller";

const router = Router();

/**
 * Vendor Category Routes
 */

// Get all vendor categories
router.get("/getallvendorcategory", getAll);

// Get vendor category by ID
router.get("/getvendorcategorybyid/:id", getById);

// Create vendor category
router.post("/createvendorcategory", create);

// Update vendor category
router.put("/updatevendorcategory/:id", update);

// Delete vendor category
router.delete("/deletevendorcategory/:id", remove);

export default router;