import ConflictError from "../../../../common/exceptions/ConflictError";
import NotFoundError from "../../../../common/exceptions/NotFoundError";
import ValidationError from "../../../../common/exceptions/ValidationError";
import * as repository from "../repository/subCategory.repository";

export const createSubCategoryService = async (categoryId: string, subCategoryName: string, description?: string) => {
  if (!categoryId?.trim() || !subCategoryName?.trim()) {
    throw new ValidationError("Category ID and sub category name are required");
  }

  const exists = await repository.findByName(categoryId, subCategoryName);

  if (exists) {
    if (!exists.isDeleted) {
      throw new ConflictError("Sub Category already exists");
    }

    return repository.restoreSubCategory(exists.id, {
      categoryId,
      description,
    });
  }

  return repository.createSubCategory({
    categoryId,
    subCategoryName,
    description,
  });
};

export const getSubCategoriesService = async () => {
  return repository.getAll();
};

export const getSubCategoryByIdService = async (id: string) => {
  const subCategory = await repository.findById(id);

  if (!subCategory) {
    throw new NotFoundError("Sub Category not found");
  }

  return subCategory;
};

export const getSubCategoryByCategoryService = async (categoryId: string) => {
  return repository.getByCategory(categoryId);
};

export const updateSubCategoryService = async (id: string, body: any) => {
  const subCategory = await repository.findById(id);

  if (!subCategory) {
    throw new NotFoundError("Sub Category not found");
  }

  if (body.categoryId && body.subCategoryName) {
    const duplicate = await repository.findByName(body.categoryId, body.subCategoryName);

    if (duplicate && duplicate.id !== id && !duplicate.isDeleted) {
      throw new ConflictError("Sub Category already exists");
    }
  }

  return repository.updateSubCategory(id, body);
};

export const deleteSubCategoryService = async (id: string) => {
  const subCategory = await repository.findById(id);

  if (!subCategory) {
    throw new NotFoundError("Sub Category not found");
  }

  await repository.deleteSubCategory(id);
};
