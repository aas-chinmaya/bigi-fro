import { Router } from "express";
import * as controller from "../controllers/subCategory.controller";

const router = Router();

router.post("/addSubCategory", controller.createSubCategory);

router.get("/getAllSubCategories", controller.getSubCategories);

router.get("/getSubCategoryById/:id", controller.getSubCategoryById);

router.get(
  "/getSubCategoriesByCategory/:categoryId",
  controller.getByCategory
);

router.put("/updateSubCategory/:id", controller.updateSubCategory);

router.delete("/deleteSubCategory/:id", controller.deleteSubCategory);

export default router;