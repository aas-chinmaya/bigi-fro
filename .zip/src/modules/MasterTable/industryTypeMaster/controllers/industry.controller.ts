import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/industry.service";

export const createIndustry = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createIndustryService(req.body);

  return res.status(201).json({
    success: true,
    message: "Industry created successfully",
    data: result,
  });
});

export const getAllIndustries = asyncHandler(async (_req: Request, res: Response) => {
  const result = await service.getAllIndustriesService();

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const updateIndustry = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateIndustryService(req.params.id as string, req.body);

  return res.status(200).json({
    success: true,
    message: "Industry updated successfully",
    data: result,
  });
});

export const deleteIndustry = asyncHandler(async (req: Request, res: Response) => {
  await service.deleteIndustryService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: "Industry deleted successfully",
  });
});