import prisma from "../../../../config/db";

export const createIndustry = async (data: any) => {
  return prisma.industry.create({
    data,
  });
};

export const findIndustryById = async (id: string) => {
  return prisma.industry.findFirst({
    where: {
      id,
      isDeleted: false,
    },
  });
};

export const findIndustryByName = async (
  industryName: string
) => {
  return prisma.industry.findFirst({
    where: {
      industryName,
      isDeleted: false,
    },
  });
};

export const getAllIndustries = async () => {
  return prisma.industry.findMany({
    where: {
      isDeleted: false,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const updateIndustry = async (
  id: string,
  data: any
) => {
  return prisma.industry.update({
    where: {
      id,
    },
    data,
  });
};

export const deleteIndustry = async (
  id: string
) => {
  return prisma.industry.update({
    where: {
      id,
    },
    data: {
      isDeleted: true,
    },
  });
};