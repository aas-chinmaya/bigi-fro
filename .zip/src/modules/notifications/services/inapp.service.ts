

import { Server } from "socket.io";


export class InAppService {
  private connectedUsers = new Map<string, string>();

  constructor(private readonly io: Server) {}

  registerUser(userId: string, socketId: string) {
    this.connectedUsers.set(userId, socketId);

      console.log(`👤 ${userId} → ${socketId}`);
  }

  removeUser(socketId: string) {
    for (const [userId, id] of this.connectedUsers.entries()) {
      if (id === socketId) {
        this.connectedUsers.delete(userId);
         console.log(`👋 Removed ${userId}`);
        break;
      }
    }
  }

async send(userId: string, notification: any): Promise<void> {
    const socketId = this.connectedUsers.get(userId);

    if (!socketId) {
      console.log(`📴 User ${userId} is offline`);
      return;
    }

    console.log(`🔔 Sending in-app notification to ${userId}`);
    console.log(`🔌 Socket: ${socketId}`);

    this.io.to(socketId).emit("notification", notification);

    console.log(`✅ In-app notification sent to ${userId}`);
  }
}