

import { SendNotificationDto } from "../dto/send-notification.dto";


import { NotificationChannel } from "../enums/notification-channel.enum";

import { NotificationStatus } from "../enums/notification-status.enum";


import { NotificationRepository } from "../repository/notification.repository";


import { EmailService } from "./email.service";

import { InAppService } from "./inapp.service";






export class NotificationService {
  constructor(
    private readonly repository: NotificationRepository,
    private readonly emailService: EmailService,
    private readonly inAppService: InAppService,
  ) {}

  async send(dto: SendNotificationDto): Promise<void> {
    for (const channel of dto.channels) {
      const notification = await this.repository.create({
        subject: dto.subject,
        message: dto.message,
        recipientId: dto.recipient.id,
        channel: channel.type,
        payload: channel.payload,
      });

   try {

        // 2. Send through selected channel
        switch (channel.type) {

          case NotificationChannel.EMAIL:
            await this.emailService.send(channel.payload);
            break;

          case NotificationChannel.IN_APP:
            await this.inAppService.send(
              channel.payload.userId,
              {
                id: notification.id,
                title: channel.payload.title,
                message: channel.payload.message,
              }
            );
            break;
        }

        // 3. Mark successful
        await this.repository.updateStatus(
          notification.id,
          NotificationStatus.SENT
        );

      } catch (error) {

        // 4. Mark failed
        await this.repository.updateStatus(
          notification.id,
          NotificationStatus.FAILED
        );

        console.error(
          `Notification failed: ${notification.id}`,
          error
        );
      }
    }
  }
}






















//       try {
//         switch (channel.type) {
//           case NotificationChannel.EMAIL:
//             await this.emailService.send(channel.payload);
//             break;




//         }

//         await this.repository.updateStatus(
//           notification.id,
//           NotificationStatus.SENT
//         );
//       } catch (error) {
//         await this.repository.updateStatus(
//           notification.id,
//           NotificationStatus.FAILED
//         );

//         console.error(
//           `Notification failed: ${notification.id}`,
//           error
//         );
//       }
//     }
//   }
// }