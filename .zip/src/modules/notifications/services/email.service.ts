import { EmailPayload } from "../dto/send-notification.dto";
import { graphClient } from "../../../config/microsoft-graph";

export class EmailService {
  async send(payload: EmailPayload): Promise<void> {
    // Validate
    if (!payload.to) {
      throw new Error("Recipient email is required.");
    }

    if (!payload.subject) {
      throw new Error("Email subject is required.");
    }

    if (!payload.body) {
      throw new Error("Email body is required.");
    }

    // Convert recipients
    const recipients = Array.isArray(payload.to)
      ? payload.to
      : [payload.to];

    // Build Graph Request
    const emailRequest = {
      message: {
        subject: payload.subject,
        body: {
          contentType: "HTML",
          content: payload.body,
        },
        toRecipients: recipients.map((email) => ({
          emailAddress: {
            address: email,
          },
        })),
      },
      saveToSentItems: true,
    };

    // Send Email
    await graphClient
      .api(`/users/${process.env.SENDER_EMAIL}/sendMail`)
      .post(emailRequest);
  }
}