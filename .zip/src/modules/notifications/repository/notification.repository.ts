// 

















import prisma from "../../../config/db";



import { NotificationChannel } from "../enums/notification-channel.enum";
import { NotificationStatus } from "../enums/notification-status.enum";

export class NotificationRepository {
  async create(data: {
    subject: string;
    message: string;
    recipientId: string;
    channel: NotificationChannel;
    payload: object;
  }) {
    return prisma.notification.create({
      data: {
        subject: data.subject,
        message: data.message,
        recipientId: data.recipientId,
        channel: data.channel,
        payload: data.payload,
        status: NotificationStatus.PENDING,
      },
    });
  }

  async updateStatus(
    id: string,
    status: NotificationStatus
  ) {
    return prisma.notification.update({
      where: { id },
      data: {
        status,
        sentAt:
          status === NotificationStatus.SENT
            ? new Date()
            : undefined,
      },
    });
  }

  async findByRecipient(recipientId: string) {
    return prisma.notification.findMany({
      where: { recipientId },
      orderBy: {
        createdAt: "desc",
      },
    });
  }

  async markAsRead(id: string) {
    return prisma.notification.update({
      where: { id },
      data: {
        status: NotificationStatus.READ,
      },
    });
  }

  async markAllAsRead(recipientId: string) {
    return prisma.notification.updateMany({
      where: {
        recipientId,
        status: NotificationStatus.SENT,
      },
      data: {
        status: NotificationStatus.READ,
      },
    });
  }

  async findById(id: string) {
    return prisma.notification.findUnique({
      where: { id },
    });
  }
}