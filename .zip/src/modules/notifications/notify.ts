export interface NotifyInput {
  userIds: string[];
  title: string;
  message: string;
}

export const notify = async (data: NotifyInput): Promise<void> => {
  console.log("🔔 notify() called");

  console.log("Users:", data.userIds);
  console.log("Title:", data.title);
  console.log("Message:", data.message);
};