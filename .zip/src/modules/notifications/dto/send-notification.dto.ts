import { NotificationChannel } from "../enums/notification-channel.enum";

export interface SendNotificationDto {
  subject: string;
  message: string;

  recipient: {
    id: string;
    type: string;
  };

  channels: NotificationRequest[];
}


export type NotificationRequest =
  | {
      type: NotificationChannel.EMAIL;
      payload: EmailPayload;
    }
  | {
      type: NotificationChannel.WHATSAPP;
      payload: WhatsAppPayload;
    }
  | {
      type: NotificationChannel.IN_APP;
      payload: InAppPayload;
    };





export interface EmailPayload {
  to: string | string[];
  subject: string;
  body: string;
}


export interface WhatsAppPayload {
  phone: string;
  template: string;
  variables: string[];
}


export interface InAppPayload {
  userId: string;
  title: string;
  message: string;
}