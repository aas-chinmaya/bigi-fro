import prisma from "../../../config/db";

export const findUserByEmail = async (email: string) => {
  return prisma.user.findUnique({
    where: {
      email,
    },
  });
};

export const findUserByContact = async (contact: string) => {
  return prisma.user.findUnique({
    where: {
      contact,
    },
  });
};

export const findRoleByName = async (name: string) => {
  return prisma.role.findUnique({
    where: {
      name,
    },
  });
};

export const createUser = async (
  fullName: string,
  email: string,
  password: string,
  contact: string,
  roleId: string
) => {
  return prisma.user.create({
    data: {
      fullName,
      email,
      password,
      contact,
      roleId,
    },
    include: {
      role: true,
    },
  });
};

export const countUsers = async (whereClause: any) => {
  return prisma.user.count({
    where: whereClause,
  });
};

export const getAllUsers = async (
  whereClause: any,
  isAll: boolean,
  skip?: number,
  limit?: number
) => {
  return prisma.user.findMany({
    where: whereClause,
    orderBy: {
      createdAt: "desc",
    },

    ...(!isAll && limit ? { skip, take: limit } : {}),

    select: {
      id: true,
      fullName: true,
      email: true,
      contact: true,
      createdAt: true,
      updatedAt: true,
      createdBy: true,
      updatedBy: true,
      role: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  });
};

export const findUserById = async (id: string) => {
  return prisma.user.findUnique({
    where: { id },
  });
};

export const updateUser = async (
  userId: string,
  data: {
    fullName: string;
    email: string;
    contact: string;
    roleId: string;
  }
) => {
  return prisma.user.update({
    where: { id: userId },
    data: {
      ...data,
      updatedAt: new Date(),
    },
  });
};

export const deleteUser = async (id: string) => {
  return prisma.user.update({
    where: {
      id,
    },
    data: {
      isDeleted: true,
      updatedAt: new Date(),
    },
  });
};



export const updateFailedAttempts = async (
  userId: string,
  attempts: number,
  freezeUntil: Date | null
) => {
  return prisma.user.update({
    where: { id: userId },
    data: {
      failedAttempts: attempts,
      freezeUntil,
    },
  });
};

export const updateLoginOtp = async (
  userId: string,
  otp: string,
  expiry: Date
) => {
  return prisma.user.update({
    where: { id: userId },
    data: {
      failedAttempts: 0,
      freezeUntil: null,
      loginOTP: otp,
      loginOtpExpiresAt: expiry,
    },
  });
};

export const findUserWithRoleByEmail = async (
  email: string
) => {
  return prisma.user.findUnique({
    where: { email },
    include: {
      role: true,
    },
  });
};


export const createSession = async (data: {
  userId: string;
  refreshToken: string;
  userAgent: string;
  ipAddress: string;
  deviceInfo: string;
  browser: string;
  os: string;
  deviceName: string;
  expiresAt: Date;
}) => {
  return prisma.session.create({
    data,
  });
};

export const clearLoginOtp = async (
  userId: string
) => {
  return prisma.user.update({
    where: { id: userId },
    data: {
      loginOTP: null,
      loginOtpExpiresAt: null,
    },
  });
};

export const findUserWithRoleById = async (
  userId: string
) => {
  return prisma.user.findUnique({
    where: {
      id: userId,
    },
    include: {
      role: true,
    },
  });
};


export const updateForgotPasswordOtp = async (
  userId: string,
  otp: string,
  expiry: Date
) => {
  return prisma.user.update({
    where: { id: userId },
    data: {
      forgotPasswordOTP: otp,
      forgotPasswordExpiresAt: expiry,
    },
  });
};

export const resetUserPassword = async (
  userId: string,
  hashedPassword: string
) => {
  return prisma.user.update({
    where: { id: userId },
    data: {
      password: hashedPassword,
      forgotPasswordOTP: null,
      forgotPasswordExpiresAt: null,
      failedAttempts: 0,
      freezeUntil: null,
    },
  });
};

export const updatePassword = async (
  userId: string,
  hashedPassword: string
) => {
  return prisma.user.update({
    where: {
      id: userId,
    },
    data: {
      password: hashedPassword,
    },
  });
};

export const deactivateSession = async (
  refreshToken: string
) => {
  return prisma.session.updateMany({
    where: {
      refreshToken,
    },
    data: {
      isActive: false,
    },
  });
};

export const deactivateAllSessions = async (
  userId: string
) => {
  return prisma.session.updateMany({
    where: {
      userId,
    },
    data: {
      isActive: false,
    },
  });
};

export const getActiveDevices = async (
  userId: string
) => {
  return prisma.session.findMany({
    where: {
      userId,
      isActive: true,
    },
    orderBy: {
      createdAt: "desc",
    },
    select: {
      id: true,
      deviceInfo: true,
      browser: true,
      os: true,
      deviceName: true,
      ipAddress: true,
      createdAt: true,
      expiresAt: true,
    },
  });
};
