import { graphClient, senderEmail } from "../../../config/mail.config";

type OTPPurpose = "LOGIN" | "FORGOT_PASSWORD";


// BIZNEX BRAND CONFIG

const BIZNEX_PRIMARY = "#2563EB"; // Change to your actual primary color
const BIZNEX_PRIMARY_LIGHT = "#EFF6FF";


// OTP EMAIL TEMPLATE

export const otpEmailTemplate = (
  userName: string,
  otp: string,
  purpose: OTPPurpose
) => {
  const config = {
    LOGIN: {
      title: "Login Verification",
      message:
        "Use the verification code below to securely sign in to your BIZNEX account.",
    },

    FORGOT_PASSWORD: {
      title: "Password Reset Verification",
      message:
        "Use the verification code below to securely reset your BIZNEX account password.",
    },
  };

  const currentConfig = config[purpose];

  return `
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />

  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
  />

  <title>${currentConfig.title}</title>
</head>

<body
  style="
    margin:0;
    padding:0;
    background-color:#F5F7FA;
    font-family:Arial, Helvetica, sans-serif;
    color:#1F2937;
  "
>

  <!-- Main Container -->
  <table
    width="100%"
    cellpadding="0"
    cellspacing="0"
    border="0"
    style="background-color:#F5F7FA;"
  >

    <tr>
      <td
        align="center"
        style="padding:40px 16px;"
      >

        <!-- Email Card -->
        <table
          width="100%"
          cellpadding="0"
          cellspacing="0"
          border="0"
          style="
            max-width:600px;
            background:#FFFFFF;
            border-radius:10px;
            border:1px solid #E5E7EB;
            overflow:hidden;
          "
        >

          <!-- Header -->
          <tr>
            <td
              style="
                padding:24px 32px;
                border-bottom:1px solid #E5E7EB;
              "
            >

              <table
                width="100%"
                cellpadding="0"
                cellspacing="0"
                border="0"
              >

                <tr>

                  <!-- Logo / Brand -->
                  <td
                    align="left"
                    style="
                      font-size:24px;
                      font-weight:700;
                      color:${BIZNEX_PRIMARY};
                    "
                  >
                    BIZNEX
                  </td>

                  <!-- Product -->
                  <td
                    align="right"
                    style="
                      font-size:12px;
                      color:#6B7280;
                    "
                  >
                    Business Management
                  </td>

                </tr>

              </table>

            </td>
          </tr>


          <!-- Content -->
          <tr>
            <td
              style="
                padding:40px 32px;
              "
            >

              <!-- Greeting -->
              <p
                style="
                  margin:0 0 8px 0;
                  font-size:16px;
                  color:#111827;
                "
              >
                Hi ${userName},
              </p>


              <!-- Title -->
              <h1
                style="
                  margin:0 0 16px 0;
                  font-size:24px;
                  line-height:32px;
                  color:#111827;
                  font-weight:600;
                "
              >
                ${currentConfig.title}
              </h1>


              <!-- Message -->
              <p
                style="
                  margin:0 0 28px 0;
                  font-size:15px;
                  line-height:24px;
                  color:#6B7280;
                "
              >
                ${currentConfig.message}
              </p>


              <!-- OTP Section -->
              <table
                width="100%"
                cellpadding="0"
                cellspacing="0"
                border="0"
                style="
                  background:${BIZNEX_PRIMARY_LIGHT};
                  border:1px solid #DBEAFE;
                  border-radius:8px;
                "
              >

                <tr>
                  <td
                    align="center"
                    style="
                      padding:24px 20px;
                    "
                  >

                    <p
                      style="
                        margin:0 0 10px 0;
                        font-size:12px;
                        font-weight:600;
                        color:#6B7280;
                        text-transform:uppercase;
                        letter-spacing:1px;
                      "
                    >
                      Verification Code
                    </p>


                    <div
                      style="
                        font-size:32px;
                        line-height:40px;
                        font-weight:700;
                        letter-spacing:8px;
                        color:${BIZNEX_PRIMARY};
                      "
                    >
                      ${otp}
                    </div>


                    <p
                      style="
                        margin:12px 0 0 0;
                        font-size:12px;
                        color:#6B7280;
                      "
                    >
                      This code is valid for 10 minutes.
                    </p>

                  </td>
                </tr>

              </table>


              <!-- Security Notice -->
              <table
                width="100%"
                cellpadding="0"
                cellspacing="0"
                border="0"
                style="
                  margin-top:28px;
                  background:#F9FAFB;
                  border-radius:8px;
                "
              >

                <tr>

                  <td
                    style="
                      padding:16px;
                      border-left:3px solid ${BIZNEX_PRIMARY};
                    "
                  >

                    <p
                      style="
                        margin:0 0 6px 0;
                        font-size:13px;
                        font-weight:600;
                        color:#374151;
                      "
                    >
                      Security reminder
                    </p>

                    <p
                      style="
                        margin:0;
                        font-size:13px;
                        line-height:20px;
                        color:#6B7280;
                      "
                    >
                      Never share this verification code with anyone.
                      BIZNEX support will never ask you for your OTP,
                      password, or other security credentials.
                    </p>

                  </td>

                </tr>

              </table>


              <!-- Ignore Message -->
              <p
                style="
                  margin:28px 0 0 0;
                  font-size:13px;
                  line-height:20px;
                  color:#9CA3AF;
                "
              >
                If you didn't request this code, you can safely ignore
                this email. Your account remains secure.
              </p>

            </td>
          </tr>


          <!-- Footer -->
          <tr>

            <td
              style="
                padding:24px 32px;
                background:#F9FAFB;
                border-top:1px solid #E5E7EB;
              "
            >

              <p
                style="
                  margin:0 0 8px 0;
                  font-size:13px;
                  font-weight:600;
                  color:#374151;
                "
              >
                BIZNEX
              </p>

              <p
                style="
                  margin:0 0 12px 0;
                  font-size:12px;
                  line-height:18px;
                  color:#9CA3AF;
                "
              >
                Simplifying business management, billing and operations.
              </p>

              <p
                style="
                  margin:0;
                  font-size:11px;
                  color:#9CA3AF;
                "
              >
                © ${new Date().getFullYear()} BIZNEX. All rights reserved.
              </p>

            </td>

          </tr>

        </table>

      </td>
    </tr>

  </table>

</body>

</html>
`;
};

  

// SEND OTP EMAIL

export const sendOTPEmail = async (
  to: string,
  userName: string,
  otp: string,
  purpose: OTPPurpose
) => {
  try {
    const subject =
      purpose === "LOGIN"
        ? "Your BIZNEX Login Verification Code"
        : "Your BIZNEX Password Reset Code";

    await graphClient
      .api(`/users/${senderEmail}/sendMail`)
      .post({
        message: {
          subject,

          body: {
            contentType: "HTML",
            content: otpEmailTemplate(
              userName,
              otp,
              purpose
            ),
          },

          toRecipients: [
            {
              emailAddress: {
                address: to,
              },
            },
          ],
        },
      });

    console.log(
      `${purpose} OTP email sent successfully to ${to}`
    );
  } catch (error) {
    console.error(
      "Email send error:",
      error
    );

    throw new Error(
      "Failed to send OTP email"
    );
  }
};