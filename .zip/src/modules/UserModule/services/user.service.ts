import bcrypt from "bcryptjs";
import * as repository from "../repository/user.repository";
import { sendOTPEmail } from "../templates/mail.template";
import {
  generateAccessToken,
  generateRefreshToken,
} from "../../../utils/jwt";
import { UAParser } from "ua-parser-js";

export const registerUserService = async (body: any) => {
  const {
    fullName,
    email,
    password,
    role,
    contact,
  } = body;

  // Validation
  if (
    !fullName ||
    !email ||
    !password ||
    !role ||
    !contact
  ) {
    return {
      status: 400,
      message: "All fields are required",
    };
  }

  // Check email
  const existingEmail =
    await repository.findUserByEmail(email);

  if (existingEmail) {
    return {
      status: 400,
      message: "Email already exists",
    };
  }

  // Check contact
  const existingContact =
    await repository.findUserByContact(contact);

  if (existingContact) {
    return {
      status: 400,
      message: "Contact already exists",
    };
  }

  // Check role
  const roleData =
    await repository.findRoleByName(role);

  if (!roleData) {
    return {
      status: 400,
      message: "Invalid role",
    };
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(
    password,
    10
  );

  // Create user
  const newUser = await repository.createUser(
    fullName,
    email,
    hashedPassword,
    contact,
    roleData.id
  );

  const { password: _, ...userWithoutPassword } =
    newUser;

  return {
    status: 201,
    message: "User registered successfully",
    user: {
      ...userWithoutPassword,
      role: newUser.role.name,
    },
  };
};

export const getAllUsersService = async (query: any) => {
  const page = query.page ? Number(query.page) : 1;
  const limit = query.limit
    ? Number(query.limit)
    : undefined;

  const search = query.search || "";
  const isAll = query.all === "true";

  const skip =
    !isAll && limit ? (page - 1) * limit : undefined;

  const whereClause: any = {
    isDeleted: false,

    ...(search && {
      OR: [
        {
          fullName: {
            contains: search,
            mode: "insensitive",
          },
        },
        {
          email: {
            contains: search,
            mode: "insensitive",
          },
        },
        {
          contact: {
            contains: search,
            mode: "insensitive",
          },
        },
      ],
    }),
  };

  const totalUsers = await repository.countUsers(
    whereClause
  );

  const users = await repository.getAllUsers(
    whereClause,
    isAll,
    skip,
    limit
  );

  return {
    status: 200,
    message: "Users fetched successfully",
    total: totalUsers,
    page: isAll ? null : page,
    limit: isAll ? null : limit,
    totalPages:
      !isAll && limit
        ? Math.ceil(totalUsers / limit)
        : null,
    users,
  };
};

export const updateUserService = async (
  userId: string,
  body: any
) => {
  const { fullName, email, role, contact } = body;

  const existingUser = await repository.findUserById(userId);

  if (!existingUser || existingUser.isDeleted) {
    return {
      status: 404,
      message: "User not found",
    };
  }

  let roleId = existingUser.roleId;

  // If role is passed → fetch roleId
  if (role) {
    const roleData = await repository.findRoleByName(role);

    if (!roleData) {
      return {
        status: 400,
        message: "Invalid role",
      };
    }

    roleId = roleData.id;
  }

  const updatedUser = await repository.updateUser(
    userId,
    {
      fullName: fullName || existingUser.fullName,
      email: email || existingUser.email,
      contact: contact || existingUser.contact,
      roleId,
    }
  );

  const { password: _, ...userWithoutPassword } =
    updatedUser;

  return {
    status: 200,
    message: "User updated successfully",
    user: userWithoutPassword,
  };
};

export const deleteUserService = async (
  userId: string
) => {
  const existingUser = await repository.findUserById(
    userId
  );

  if (!existingUser || existingUser.isDeleted) {
    return {
      status: 404,
      message: "User not found",
    };
  }

  const deletedUser = await repository.deleteUser(
    userId
  );

  const { password, ...userWithoutPassword } =
    deletedUser;

  return {
    status: 200,
    message: "User deleted successfully",
    user: userWithoutPassword,
  };
};


export const loginUserService = async (
  email: string,
  password: string
) => {
  if (!email || !password) {
    return {
      status: 400,
      message: "Email and password are required",
    };
  }

  const user = await repository.findUserByEmail(email);

  if (!user || user.isDeleted) {
    return {
      status: 400,
      message: "Invalid credentials",
    };
  }

  // Account locked
  if (
    user.freezeUntil &&
    user.freezeUntil > new Date()
  ) {
    return {
      status: 403,
      message:
        "Account is temporarily locked. Try again later.",
    };
  }

  const isMatch = await bcrypt.compare(
    password,
    user.password
  );

  if (!isMatch) {
    const attempts = user.failedAttempts + 1;

    let freezeTime: Date | null = null;

    if (attempts >= 5) {
      freezeTime = new Date(
        Date.now() + 15 * 60 * 1000
      );
    }

    await repository.updateFailedAttempts(
      user.id,
      attempts,
      freezeTime
    );

    return {
      status: 400,
      message: "Invalid credentials",
    };
  }

  // Generate OTP
  const otp = Math.floor(
    100000 + Math.random() * 900000
  ).toString();

  const expiry = new Date(
    Date.now() + 1 * 60 * 1000
  );

  await repository.updateLoginOtp(
    user.id,
    otp,
    expiry
  );

  await sendOTPEmail(
    user.email,
    user.fullName || "User",
    otp,
    "LOGIN"
  );

  return {
    status: 200,
    message: "OTP sent to your email",
  };
};


export const verifyLoginOtpService = async (
  email: string,
  otp: string,
  req: any
) => {
  if (!email || !otp) {
    return {
      status: 400,
      message: "Email and OTP are required",
    };
  }

  const user =
    await repository.findUserWithRoleByEmail(
      email
    );

  if (!user || user.isDeleted) {
    return {
      status: 400,
      message: "User not found",
    };
  }

  if (!user.loginOTP || user.loginOTP !== otp) {
    return {
      status: 400,
      message: "Invalid OTP",
    };
  }

  if (
    user.loginOtpExpiresAt &&
    user.loginOtpExpiresAt < new Date()
  ) {
    return {
      status: 400,
      message: "OTP expired",
    };
  }

  const accessToken = generateAccessToken({
    id: user.id,
    roleId: user.roleId,
    role: user.role.name,
  });

  const refreshToken = generateRefreshToken({
    id: user.id,
    roleId: user.roleId,
    role: user.role.name,
  });

  // Device information
  const ua = req.headers["user-agent"] || "";

  const parser = new UAParser(ua);
  const result = parser.getResult();

  const deviceType =
    result.device.type || "desktop";

  const browser =
    result.browser.name || "unknown";

  const os = result.os.name || "unknown";

  const ipAddress =
    req.ip || req.socket.remoteAddress || "";

  await repository.createSession({
    userId: user.id,
    refreshToken,
    userAgent: ua,
    ipAddress,
    deviceInfo: `${deviceType} - ${browser} - ${os}`,
    browser,
    os,
    deviceName:
      result.device.model || "unknown",
    expiresAt: new Date(
      Date.now() + 7 * 24 * 60 * 60 * 1000
    ),
  });

  await repository.clearLoginOtp(user.id);

  const { password, roleId, ...rest } = user;

  return {
    status: 200,
    message: "Login successful",
    accessToken,
    refreshToken,
    user: {
      ...rest,
      role: user.role.name,
    },
  };
};

export const getLoggedInUserService = async (
  userId: string
) => {
  const user =
    await repository.findUserWithRoleById(
      userId
    );

  if (!user || user.isDeleted) {
    return {
      status: 404,
      message: "User not found",
    };
  }

  const { password, roleId, ...rest } = user;

  return {
    status: 200,
    message: "User fetched successfully",
    user: {
      ...rest,
      role: user.role.name,
    },
  };
};


export const checkAuthService = async (
  userId?: string
) => {
  if (!userId) {
    return {
      status: 401,
      isAuthenticated: false,
    };
  }

  const user =
    await repository.findUserWithRoleById(
      userId
    );

  if (!user || user.isDeleted) {
    return {
      status: 401,
      isAuthenticated: false,
    };
  }

  return {
    status: 200,
    isAuthenticated: true,
    user: {
      id: user.id,
      name: user.fullName,
      email: user.email,
      role: user.role.name,
    },
  };
};

export const forgotPasswordService = async (
  email: string
) => {
  if (!email) {
    return {
      status: 400,
      message: "Email is required",
    };
  }

  const user = await repository.findUserByEmail(
    email
  );

  if (!user || user.isDeleted) {
    return {
      status: 400,
      message: "User not found",
    };
  }

  const otp = Math.floor(
    100000 + Math.random() * 900000
  ).toString();

  const expiry = new Date(
    Date.now() + 5 * 60 * 1000
  );

  await repository.updateForgotPasswordOtp(
    user.id,
    otp,
    expiry
  );

  await sendOTPEmail(
    user.email,
    user.fullName || "User",
    otp,
    "FORGOT_PASSWORD"
  );

  return {
    status: 200,
    message: `OTP sent to ${user.email}`,
  };
};

export const verifyForgotPasswordOtpService = async (
  email: string,
  otp: string,
  newPassword: string
) => {
  if (!email || !otp || !newPassword) {
    return {
      status: 400,
      message:
        "Email, OTP, and new password are required",
    };
  }

  const user = await repository.findUserByEmail(
    email
  );

  if (!user || user.isDeleted) {
    return {
      status: 400,
      message: "User not found",
    };
  }

  if (
    !user.forgotPasswordOTP ||
    user.forgotPasswordOTP !== otp
  ) {
    return {
      status: 400,
      message: "Invalid OTP",
    };
  }

  if (
    user.forgotPasswordExpiresAt &&
    user.forgotPasswordExpiresAt < new Date()
  ) {
    return {
      status: 400,
      message: "OTP expired",
    };
  }

  const hashedPassword = await bcrypt.hash(
    newPassword,
    10
  );

  await repository.resetUserPassword(
    user.id,
    hashedPassword
  );

  return {
    status: 200,
    message: "Password reset successful",
  };
};

export const changePasswordService = async (
  userId: string | undefined,
  currentPassword: string,
  newPassword: string
) => {
  if (!userId) {
    return {
      status: 401,
      message: "Unauthorized",
    };
  }

  if (!currentPassword || !newPassword) {
    return {
      status: 400,
      message: "Current and new passwords are required",
    };
  }

  const user = await repository.findUserById(userId);

  if (!user || user.isDeleted) {
    return {
      status: 404,
      message: "User not found",
    };
  }

  const isMatch = await bcrypt.compare(
    currentPassword,
    user.password
  );

  if (!isMatch) {
    return {
      status: 400,
      message: "Current password is incorrect",
    };
  }

  const hashedPassword = await bcrypt.hash(
    newPassword,
    10
  );

  await repository.updatePassword(
    userId,
    hashedPassword
  );

  return {
    status: 200,
    message: "Password changed successfully",
  };
};

export const logoutCurrentDeviceService = async (
  refreshToken?: string
) => {
  if (!refreshToken) {
    return {
      status: 400,
      message: "Refresh token not found",
    };
  }

  await repository.deactivateSession(
    refreshToken
  );

  return {
    status: 200,
    message:
      "Logged out from current device successfully",
  };
};

export const logoutAllDevicesService = async (
  userId?: string
) => {
  if (!userId) {
    return {
      status: 401,
      message: "Unauthorized",
    };
  }

  await repository.deactivateAllSessions(userId);

  return {
    status: 200,
    message: "Logged out from all devices successfully",
  };
};

export const getActiveDevicesService = async (
  userId?: string
) => {
  if (!userId) {
    return {
      status: 401,
      message: "Unauthorized",
    };
  }

  const sessions = await repository.getActiveDevices(userId);

  return {
    status: 200,
    devices: sessions,
  };
};
