import ConflictError from "../../../../common/exceptions/ConflictError";
import NotFoundError from "../../../../common/exceptions/NotFoundError";
import ValidationError from "../../../../common/exceptions/ValidationError";
import * as repository from "../repository/role.repository";

export const createRoleService = async (body: any) => {
  const { name, description } = body;

  if (!name?.trim()) {
    throw new ValidationError("Role name is required");
  }

  const roleName = name.trim().toUpperCase();
  const existingRole = await repository.findRoleByName(roleName);

  if (existingRole && !existingRole.isDeleted) {
    throw new ConflictError("Role already exists");
  }

  if (existingRole && existingRole.isDeleted) {
    return repository.reactivateRole(existingRole.id);
  }

  return repository.createRole(roleName, description);
};

export const getAllRolesService = async () => {
  return repository.getAllRoles();
};

export const updateRoleService = async (roleId: string, body: any) => {
  const { name, description } = body;
  const existingRole = await repository.findRoleById(roleId);

  if (!existingRole || existingRole.isDeleted) {
    throw new NotFoundError("Role not found");
  }

  let updatedName = existingRole.name;

  if (name) {
    const roleName = name.trim().toUpperCase();
    const duplicateRole = await repository.findRoleByName(roleName);

    if (duplicateRole && duplicateRole.id !== roleId) {
      throw new ConflictError("Role name already exists");
    }

    updatedName = roleName;
  }

  return repository.updateRole(roleId, updatedName, description !== undefined ? description : existingRole.description);
};

export const deleteRoleService = async (roleId: string) => {
  const existingRole = await repository.findRoleById(roleId);

  if (!existingRole || existingRole.isDeleted) {
    throw new NotFoundError("Role not found");
  }

  return repository.deleteRole(roleId);
};
