import { Router } from "express";
import { createRole , getAllRoles , updateRole, deleteRole} from "../controllers/role.controller";
// import { isAuthenticated } from "../../middleware/auth.middleware";
const router = Router();

router.post("/createRole", createRole);
router.get("/getAllRoles", getAllRoles);
router.put("/updateRole/:id", updateRole);
router.delete("/deleteRole/:id", deleteRole);

export default router;