import prisma from "../../../../config/db";

export const findRoleByName = async (name: string) => {
  return prisma.role.findUnique({
    where: {
      name,
    },
  });
};

export const reactivateRole = async (id: string) => {
  return prisma.role.update({
    where: {
      id,
    },
    data: {
      isDeleted: false,
    },
  });
};

export const createRole = async (
  name: string,
  description?: string
) => {
  return prisma.role.create({
    data: {
      name,
      description,
    },
  });
};

export const getAllRoles = async () => {
  return prisma.role.findMany({
    where: {
      isDeleted: false,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const findRoleById = async (id: string) => {
  return prisma.role.findUnique({
    where: { id },
  });
};


export const updateRole = async (
  id: string,
  name: string,
  description: string | null
) => {
  return prisma.role.update({
    where: { id },
    data: {
      name,
      description,
    },
  });
};

export const deleteRole = async (id: string) => {
  return prisma.role.update({
    where: {
      id,
    },
    data: {
      isDeleted: true,
    },
  });
};


