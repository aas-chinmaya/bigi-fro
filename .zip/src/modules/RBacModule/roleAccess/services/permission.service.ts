import * as repository from "../repository/permission.repository";

export const assignPermissionsService = async (
  roleId: string,
  body: any
) => {
  const role = await repository.findRoleById(roleId);

  if (!role || role.isDeleted) {
    return {
      status: 404,
      message: "Role not found",
    };
  }

  const permissions = Array.isArray(body)
    ? body
    : [body];

  const operations: any[] = [];

  for (const permission of permissions) {
    const {
      moduleIds = [],
      subModuleIds = [],
      featureIds = [],
      apiIds = [],
      isAllowed = true,
    } = permission;

    // ==========================================================
    // MODULE
    // ==========================================================

    for (const moduleId of moduleIds) {
      if (isAllowed) {
        // ------------------------------------------------------
        // GRANT MODULE
        // ------------------------------------------------------

        operations.push(
          repository.saveModulePermission(
            roleId,
            moduleId,
            true
          )
        );

        const apis =
          await repository.getApisByModuleIds([
            moduleId,
          ]);

        operations.push(
          ...repository.createApiPermissionOperations(
            roleId,
            apis,
            true
          )
        );
      } else {
        // ------------------------------------------------------
        // REVOKE MODULE
        // ------------------------------------------------------

        const hierarchy =
          await repository.getModuleDescendants(
            moduleId
          );

        operations.push(
          repository.revokeModulePermissions(
            roleId,
            moduleId,
            hierarchy.subModuleIds,
            hierarchy.featureIds,
            hierarchy.apiIds
          )
        );

        operations.push(
          repository.revokeRoleApiPermissions(
            roleId,
            hierarchy.apiIds
          )
        );
      }
    }

    // ==========================================================
    // SUB MODULE
    // ==========================================================

    for (const subModuleId of subModuleIds) {
      if (isAllowed) {
        // ------------------------------------------------------
        // GRANT SUB MODULE
        // ------------------------------------------------------

        operations.push(
          repository.saveSubModulePermission(
            roleId,
            subModuleId,
            true
          )
        );

        const apis =
          await repository.getApisBySubModuleIds([
            subModuleId,
          ]);

        operations.push(
          ...repository.createApiPermissionOperations(
            roleId,
            apis,
            true
          )
        );
      } else {
        // ------------------------------------------------------
        // REVOKE SUB MODULE
        // ------------------------------------------------------

        const hierarchy =
          await repository.getSubModuleDescendants(
            subModuleId
          );

        operations.push(
          repository.revokeSubModulePermissions(
            roleId,
            subModuleId,
            hierarchy.featureIds,
            hierarchy.apiIds
          )
        );

        operations.push(
          repository.revokeRoleApiPermissions(
            roleId,
            hierarchy.apiIds
          )
        );
      }
    }

    // ==========================================================
    // FEATURE
    // ==========================================================

    for (const featureId of featureIds) {
      if (isAllowed) {
        // ------------------------------------------------------
        // GRANT FEATURE
        // ------------------------------------------------------

        operations.push(
          repository.saveFeaturePermission(
            roleId,
            featureId,
            true
          )
        );

        const apis =
          await repository.getApisByFeatureIds([
            featureId,
          ]);

        operations.push(
          ...repository.createApiPermissionOperations(
            roleId,
            apis,
            true
          )
        );
      } else {
        // ------------------------------------------------------
        // REVOKE FEATURE
        // ------------------------------------------------------

        const apiIds =
          await repository.getApiIdsByFeatureId(
            featureId
          );

        operations.push(
          repository.revokeFeaturePermissions(
            roleId,
            featureId,
            apiIds
          )
        );

        operations.push(
          repository.revokeRoleApiPermissions(
            roleId,
            apiIds
          )
        );
      }
    }

    // ==========================================================
    // DIRECT API
    // ==========================================================

    for (const apiId of apiIds) {
      if (isAllowed) {
        operations.push(
          repository.saveApiPermission(
            roleId,
            apiId,
            true
          )
        );

        operations.push(
          repository.createPermissionOperation(
            roleId,
            apiId,
            true
          )
        );
      } else {
        // ------------------------------------------------------
        // REVOKE API
        // ------------------------------------------------------

        operations.push(
          repository.revokeApiPermission(
            roleId,
            apiId
          )
        );

        operations.push(
          repository.revokeRoleApiPermission(
            roleId,
            apiId
          )
        );
      }
    }
  }

  if (operations.length === 0) {
    return {
      status: 400,
      message: "Nothing to update",
    };
  }

  await repository.executeTransaction(
    operations
  );

  const updatedPermissions =
    await repository.getRolePermissions(roleId);

  return {
    status: 200,
    message: "Permissions updated successfully",
    totalApis: updatedPermissions.length,
    permissions: updatedPermissions,
  };
};

export const getRolePermissionsService = async (
  roleId: string
) => {
  // ==========================================================
  // GET ALL ROLE PERMISSIONS
  // IMPORTANT:
  // We fetch BOTH true and false permissions
  // ==========================================================

  const hierarchyPermissions =
    await repository.getRoleHierarchyPermissionsRepo(
      roleId
    );

  // ==========================================================
  // BUILD PERMISSION MAPS
  // ==========================================================

  const modulePermissions = new Map<
    string,
    boolean
  >();

  const subModulePermissions = new Map<
    string,
    boolean
  >();

  const featurePermissions = new Map<
    string,
    boolean
  >();

  const apiPermissions = new Map<
    string,
    boolean
  >();

  for (const permission of hierarchyPermissions) {
    if (permission.moduleId) {
      modulePermissions.set(
        permission.moduleId,
        permission.isAllowed
      );
    }

    if (permission.subModuleId) {
      subModulePermissions.set(
        permission.subModuleId,
        permission.isAllowed
      );
    }

    if (permission.featureId) {
      featurePermissions.set(
        permission.featureId,
        permission.isAllowed
      );
    }

    if (permission.apiId) {
      apiPermissions.set(
        permission.apiId,
        permission.isAllowed
      );
    }
  }



  const resolvePermission = (
    ...permissions: (boolean | undefined)[]
  ) => {
    for (const permission of permissions) {
      if (permission !== undefined) {
        return permission;
      }
    }

    return false;
  };

  // ==========================================================
  // GET COMPLETE MODULE HIERARCHY
  // ==========================================================

  const modules =
    await repository.getModuleHierarchyRepo();

  // ==========================================================
  // BUILD RESPONSE
  // ==========================================================

  const result = modules.map((module) => {
    // ========================================================
    // MODULE PERMISSION
    // ========================================================

    const moduleAllowed =
      modulePermissions.get(module.id) ??
      false;

    // ========================================================
    // DIRECT MODULE APIs
    // ========================================================

    const moduleApis = module.apis.map(
      (api) => ({
        ...api,

        isAllowed:
          resolvePermission(
            apiPermissions.get(api.id),
            modulePermissions.get(module.id)
          ),
      })
    );

    // ========================================================
    // FEATURES DIRECTLY UNDER MODULE
    // ========================================================

    const moduleFeatures =
      module.features.map(
        (feature) => {
          const featureAllowed =
            resolvePermission(
              featurePermissions.get(
                feature.id
              ),
              modulePermissions.get(
                module.id
              )
            );

          return {
            ...feature,

            isAllowed: featureAllowed,

            apis: feature.apis.map(
              (api) => ({
                ...api,

                isAllowed:
                  resolvePermission(
                    apiPermissions.get(
                      api.id
                    ),

                    featurePermissions.get(
                      feature.id
                    ),

                    modulePermissions.get(
                      module.id
                    )
                  ),
              })
            ),
          };
        }
      );

    // ========================================================
    // SUB MODULES
    // ========================================================

    const subModules =
      module.subModules.map(
        (subModule) => {
          const subModuleAllowed =
            resolvePermission(
              subModulePermissions.get(
                subModule.id
              ),

              modulePermissions.get(
                module.id
              )
            );

          // --------------------------------------------------
          // DIRECT APIs UNDER SUBMODULE
          // --------------------------------------------------

          const subModuleApis =
            subModule.apis.map(
              (api) => ({
                ...api,

                isAllowed:
                  resolvePermission(
                    apiPermissions.get(
                      api.id
                    ),

                    subModulePermissions.get(
                      subModule.id
                    ),

                    modulePermissions.get(
                      module.id
                    )
                  ),
              })
            );

          // --------------------------------------------------
          // FEATURES UNDER SUBMODULE
          // --------------------------------------------------

          const subModuleFeatures =
            subModule.features.map(
              (feature) => {
                const featureAllowed =
                  resolvePermission(
                    featurePermissions.get(
                      feature.id
                    ),

                    subModulePermissions.get(
                      subModule.id
                    ),

                    modulePermissions.get(
                      module.id
                    )
                  );

                return {
                  ...feature,

                  isAllowed:
                    featureAllowed,

                  apis:
                    feature.apis.map(
                      (api) => ({
                        ...api,

                        isAllowed:
                          resolvePermission(
                            apiPermissions.get(
                              api.id
                            ),

                            featurePermissions.get(
                              feature.id
                            ),

                            subModulePermissions.get(
                              subModule.id
                            ),

                            modulePermissions.get(
                              module.id
                            )
                          ),
                      })
                    ),
                };
              }
            );

          return {
            ...subModule,

            isAllowed:
              subModuleAllowed,

            apis:
              subModuleApis,

            features:
              subModuleFeatures,
          };
        }
      );

    // ========================================================
    // MODULE
    // ========================================================

    return {
      ...module,

      isAllowed:
        moduleAllowed,

      apis:
        moduleApis,

      features:
        moduleFeatures,

      subModules:
        subModules,
    };
  });

  return {
    status: 200,

    message:
      "Role permissions fetched successfully",

    data: result,
  };
};
