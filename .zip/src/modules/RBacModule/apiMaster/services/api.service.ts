import * as repository from "../repository/api.repository";

export const createApiService = async (body: any) => {
  const {
    name,
    method,
    route,
    description,
    featureId,
    subModuleId,
    moduleId,
  } = body;

  if (!name?.trim() || !method?.trim() || !route?.trim()) {
    return {
      status: 400,
      message: "Name, method and route are required",
    };
  }

  const parsedFeatureId = featureId ? String(featureId) : null;
  const parsedSubModuleId = subModuleId ? String(subModuleId) : null;
  const parsedModuleId = moduleId ? String(moduleId) : null;


  if (!parsedFeatureId && !parsedSubModuleId && !parsedModuleId) {
    return {
      status: 400,
      message:
        "At least one of featureId, subModuleId or moduleId is required",
    };
  }

  const finalFeatureId = parsedFeatureId;

  const finalSubModuleId = parsedFeatureId
    ? null
    : parsedSubModuleId;

  const finalModuleId =
    parsedFeatureId || parsedSubModuleId
      ? null
      : parsedModuleId;

  if (finalFeatureId) {
    const feature = await repository.findFeatureById(finalFeatureId);

    if (!feature || feature.isDeleted) {
      return {
        status: 404,
        message: "Feature not found",
      };
    }
  }

  if (finalSubModuleId) {
    const subModule =
      await repository.findSubModuleById(finalSubModuleId);

    if (!subModule || subModule.isDeleted) {
      return {
        status: 404,
        message: "SubModule not found",
      };
    }
  }

  if (finalModuleId) {
    const module =
      await repository.findModuleById(finalModuleId);

    if (!module || module.isDeleted) {
      return {
        status: 404,
        message: "Module not found",
      };
    }
  }

  const existingApi =
    await repository.findApiByMethodAndRoute(
      method.toUpperCase(),
      route.trim()
    );

  if (existingApi && !existingApi.isDeleted) {
    return {
      status: 400,
      message:
        "API with same method and route already exists",
    };
  }

  const payload = {
    name: name.trim(),
    method: method.toUpperCase(),
    route: route.trim(),
    description,
    featureId: finalFeatureId,
    subModuleId: finalSubModuleId,
    moduleId: finalModuleId,
  };

  if (existingApi && existingApi.isDeleted) {
    const api = await repository.updateApiRepo(
      existingApi.id,
      {
        ...payload,
        isDeleted: false,
      }
    );

    return {
      status: 200,
      message: "API re-activated successfully",
      data: api,
    };
  }

  const api = await repository.createApiRepo(payload);

  return {
    status: 201,
    message: "API created successfully",
    data: api,
  };
};

export const getAllApisService = async (query: any) => {
  const page = Number(query.page) || 1;
  const limit = query.limit ? Number(query.limit) : null;
  const search = (query.search as string) || "";
  const isAll = query.all === "true";

  const whereClause = {
    isDeleted: false,
    ...(search && {
      OR: [
        {
          name: {
            contains: search,
            mode: "insensitive" as const,
          },
        },
        {
          route: {
            contains: search,
            mode: "insensitive" as const,
          },
        },
      ],
    }),
  };

  // Dropdown
  if (isAll) {
    const apis =
      await repository.getAllApisDropdownRepo(whereClause);

    return {
      status: 200,
      message: "All APIs fetched",
      count: apis.length,
      data: apis,
    };
  }

  const take = limit || 10;
  const skip = (page - 1) * take;

  const totalApis =
    await repository.countApisRepo(whereClause);

  const apis = await repository.getAllApisRepo(
    whereClause,
    skip,
    take
  );

  return {
    status: 200,
    message: "APIs fetched successfully",
    data: apis,
    pagination: {
      total: totalApis,
      page,
      limit: take,
      totalPages: Math.ceil(totalApis / take),
    },
  };
};

export const getApisByFeatureService = async (
  featureId: string
) => {

  const apis = await repository.getApisByFeatureRepo(
    featureId
  );

  return {
    status: 200,
    message: "APIs fetched successfully",
    data: apis,
  };
};

export const getApisBySubModuleService = async (
  subModuleId: string
) => {

  const apis = await repository.getApisBySubModuleRepo(
    subModuleId
  );

  return {
    status: 200,
    message: "APIs fetched successfully",
    data: apis,
  };
};

export const getApisByModuleService = async (
  moduleId: string
) => {

  const apis = await repository.getApisByModuleRepo(
    moduleId
  );

  return {
    status: 200,
    message: "APIs fetched successfully",
    data: apis,
  };
};

export const updateApiService = async (
  id: string,
  body: any
) => {

  const {
    name,
    method,
    route,
    description,
    featureId,
    subModuleId,
    moduleId,
  } = body;

  const existing = await repository.findApiById(id);

  if (!existing || existing.isDeleted) {
    return {
      status: 404,
      message: "API not found",
    };
  }

  const parsedFeatureId =
    featureId !== undefined &&
    featureId !== null &&
    featureId !== ""
      ? String(featureId)
      : undefined;

  const parsedSubModuleId =
    subModuleId !== undefined &&
    subModuleId !== null &&
    subModuleId !== ""
      ? String(subModuleId)
      : undefined;

  const parsedModuleId =
    moduleId !== undefined &&
    moduleId !== null &&
    moduleId !== ""
      ? String(moduleId)
      : undefined;

  let updatedFeatureId = existing.featureId;
  let updatedSubModuleId = existing.subModuleId;
  let updatedModuleId = existing.moduleId;


  if (parsedFeatureId) {
    const feature = await repository.findFeatureById(
      parsedFeatureId
    );

    if (!feature || feature.isDeleted) {
      return {
        status: 404,
        message: "Feature not found",
      };
    }

    updatedFeatureId = parsedFeatureId;
    updatedSubModuleId = null;
    updatedModuleId = null;
  } else if (parsedSubModuleId) {
    const subModule =
      await repository.findSubModuleById(
        parsedSubModuleId
      );

    if (!subModule || subModule.isDeleted) {
      return {
        status: 404,
        message: "SubModule not found",
      };
    }

    updatedFeatureId = null;
    updatedSubModuleId = parsedSubModuleId;
    updatedModuleId = null;
  } else if (parsedModuleId) {
    const module = await repository.findModuleById(
      parsedModuleId
    );

    if (!module || module.isDeleted) {
      return {
        status: 404,
        message: "Module not found",
      };
    }

    updatedFeatureId = null;
    updatedSubModuleId = null;
    updatedModuleId = parsedModuleId;
  }

  const finalMethod =
    method?.toUpperCase() ?? existing.method;

  const finalRoute =
    route?.trim() ?? existing.route;

  const duplicate =
    await repository.findApiByMethodAndRoute(
      finalMethod,
      finalRoute
    );

  if (duplicate && duplicate.id !== id) {
    return {
      status: 400,
      message:
        "API with same method and route already exists",
    };
  }

  const updatedApi = await repository.updateApiRepo(
    id,
    {
      name: name?.trim() ?? existing.name,
      method: finalMethod,
      route: finalRoute,
      description:
        description ?? existing.description,
      featureId: updatedFeatureId,
      subModuleId: updatedSubModuleId,
      moduleId: updatedModuleId,
    }
  );

  return {
    status: 200,
    message: "API updated successfully",
    data: updatedApi,
  };
};

export const deleteApiService = async (id: string) => {

  const existing = await repository.findApiById(id);

  if (!existing || existing.isDeleted) {
    return {
      status: 404,
      message: "API not found",
    };
  }

  await repository.deleteApiRepo(id);

  return {
    status: 200,
    message: "API deleted successfully",
  };
};
