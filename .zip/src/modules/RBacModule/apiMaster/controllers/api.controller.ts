// controllers/api.controller.ts
import { Request, Response } from "express";
import * as service from "../services/api.service";



export const createApi = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await service.createApiService(req.body);

    return res.status(result.status).json({
      message: result.message,
      api: result.data,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};


export const getAllApis = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await service.getAllApisService(
      req.query
    );

    return res.status(result.status).json({
      message: result.message,
      count: result.count,
      data: result.data,
      pagination: result.pagination,
    });
  } catch (error) {
    console.error("Get APIs Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};


export const getApisByFeature = async (
  req: Request,
  res: Response
) => {
  try {
    const result =
      await service.getApisByFeatureService(
        String(req.params.featureId)
      );

    return res.status(result.status).json({
      message: result.message,
      apis: result.data,
    });
  } catch (error) {
    console.error("Get APIs by Feature Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};



export const getApisBySubModule = async (
  req: Request,
  res: Response
) => {
  try {
    const result =
      await service.getApisBySubModuleService(
        String(req.params.subModuleId)
      );

    return res.status(result.status).json({
      message: result.message,
      apis: result.data,
    });
  } catch (error) {
    console.error("Get APIs by SubModule Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};



export const getApisByModule = async (
  req: Request,
  res: Response
) => {
  try {
    const result =
      await service.getApisByModuleService(
        String(req.params.moduleId)
      );

    return res.status(result.status).json({
      message: result.message,
      apis: result.data,
    });
  } catch (error) {
    console.error("Get APIs by Module Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};



export const updateApi = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await service.updateApiService(
      String(req.params.id),
      req.body
    );

    return res.status(result.status).json({
      message: result.message,
      api: result.data,
    });
  } catch (error) {
    console.error("Update API Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};


export const deleteApi = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await service.deleteApiService(
      String(req.params.id)
    );

    return res.status(result.status).json({
      message: result.message,
    });
  } catch (error) {
    console.error("Delete API Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};