import ConflictError from "../../../../common/exceptions/ConflictError";
import NotFoundError from "../../../../common/exceptions/NotFoundError";
import ValidationError from "../../../../common/exceptions/ValidationError";
import * as repository from "../repository/subModule.repository";

export const createSubModuleService = async (body: any) => {
  const { name, route, description, priority, moduleId } = body;

  if (!name?.trim() || !route?.trim() || priority === undefined || priority === null) {
    throw new ValidationError("Name, route and priority are required");
  }

  const module = await repository.findModuleById(String(moduleId));

  if (!module || module.isDeleted) {
    throw new NotFoundError("Module not found");
  }

  const subModuleName = name.trim().toUpperCase();
  const existing = await repository.findSubModuleByName(subModuleName, String(moduleId));

  if (existing && !existing.isDeleted) {
    throw new ConflictError("SubModule already exists");
  }

  if (existing && existing.isDeleted) {
    return repository.updateSubModuleRepo(existing.id, {
      isDeleted: false,
      route,
      description,
      priority,
    });
  }

  return repository.createSubModuleRepo({
    name: subModuleName,
    route,
    description,
    priority,
    moduleId: String(moduleId),
  });
};

export const getAllSubModulesService = async (query: any) => {
  const page = query.page ? Number(query.page) : 1;
  const limit = query.limit ? Number(query.limit) : undefined;
  const search = (query.search as string) || "";
  const isAll = query.all === "true";

  const skip = !isAll && limit ? (page - 1) * limit : undefined;

  const whereClause = {
    isDeleted: false,
    ...(search && {
      name: {
        contains: search,
        mode: "insensitive" as const,
      },
    }),
  };

  const totalSubModules = await repository.countSubModulesRepo(whereClause);
  const subModules = await repository.getAllSubModulesRepo(whereClause, skip, limit);

  return {
    data: subModules,
    pagination: {
      total: totalSubModules,
      page: isAll ? null : page,
      limit: isAll ? null : limit,
      totalPages: !isAll && limit ? Math.ceil(totalSubModules / limit) : null,
    },
  };
};

export const getSubModulesByModuleService = async (moduleId: string, query: any) => {

  const page = Number(query.page) || 1;
  const limit = query.limit ? Number(query.limit) : null;
  const search = (query.search as string) || "";
  const isAll = query.all === "true";

  const whereClause = {
    moduleId,
    isDeleted: false,
    ...(search && {
      name: {
        contains: search,
        mode: "insensitive" as const,
      },
    }),
  };

  const total = await repository.countSubModulesByModuleRepo(whereClause);
  const take = isAll ? undefined : (limit ?? undefined);
  const skip = isAll || !limit ? undefined : (page - 1) * limit;
  const subModules = await repository.getSubModulesByModuleRepo(whereClause, skip, take);

  return {
    data: subModules,
    pagination: {
      total,
      page: isAll ? null : page,
      limit: isAll ? null : limit,
      totalPages: !isAll && limit ? Math.ceil(total / limit) : null,
    },
  };
};

export const updateSubModuleService = async (id: string, body: any) => {

  const { name, route, description, priority, moduleId } = body;
  const existing = await repository.findSubModuleById(id);

  if (!existing || existing.isDeleted) {
    throw new NotFoundError("SubModule not found");
  }

  let updatedName = existing.name;
  let updatedModuleId = existing.moduleId;

  if (moduleId) {
    const module = await repository.findModuleById(String(moduleId));

    if (!module || module.isDeleted) {
      throw new NotFoundError("Module not found");
    }

    updatedModuleId = String(moduleId);
  }

  if (name) {
    const subModuleName = name.trim().toUpperCase();
    const duplicate = await repository.findSubModuleByNameAndModule(subModuleName, updatedModuleId);

    if (duplicate && duplicate.id !== id) {
      throw new ConflictError("SubModule already exists in this module");
    }

    updatedName = subModuleName;
  }

  return repository.updateSubModuleRepo(id, {
    name: updatedName,
    route: route ?? existing.route,
    description: description ?? existing.description,
    priority: priority ?? existing.priority,
    moduleId: updatedModuleId,
  });
};

export const deleteSubModuleService = async (id: string) => {
 
  const existing = await repository.findSubModuleById(id);

  if (!existing || existing.isDeleted) {
    throw new NotFoundError("SubModule not found");
  }

  await repository.deleteSubModuleRepo(id);
};
