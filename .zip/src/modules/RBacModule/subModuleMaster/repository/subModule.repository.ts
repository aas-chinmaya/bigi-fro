import prisma from "../../../../config/db";


export const findSubModuleById = async (id: string) => {
  return prisma.subModule.findUnique({
    where: { id },
  });
};

export const findSubModuleByNameAndModule = async (
  name: string,
  moduleId: string
) => {
  return prisma.subModule.findFirst({
    where: {
      name,
      moduleId,
    },
  });
};

export const findModuleById = async (id: string) => {
  return prisma.module.findUnique({
    where: { id },
  });
};

export const findSubModuleByName = async (
  name: string,
  moduleId: string
) => {
  return prisma.subModule.findFirst({
    where: {
      name,
      moduleId,
    },
  });
};

export const createSubModuleRepo = async (data: any) => {
  return prisma.subModule.create({
    data,
  });
};

export const updateSubModuleRepo = async (
  id: string,
  data: any
) => {
  return prisma.subModule.update({
    where: { id },
    data,
  });
};


export const countSubModulesRepo = async (whereClause: any) => {
  return prisma.subModule.count({
    where: whereClause,
  });
};

export const getAllSubModulesRepo = async (
  whereClause: any,
  skip?: number,
  take?: number
) => {
  return prisma.subModule.findMany({
    where: whereClause,
    orderBy: {
      priority: "asc",
    },
    ...(skip !== undefined && take !== undefined
      ? { skip, take }
      : {}),

    include: {
      module: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  });
};

export const countSubModulesByModuleRepo = async (
  whereClause: any
) => {
  return prisma.subModule.count({
    where: whereClause,
  });
};

export const getSubModulesByModuleRepo = async (
  whereClause: any,
  skip?: number,
  take?: number
) => {
  return prisma.subModule.findMany({
    where: whereClause,
    orderBy: {
      priority: "asc",
    },
    ...(skip !== undefined ? { skip } : {}),
    ...(take !== undefined ? { take } : {}),
    include: {
      module: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  });
};

export const deleteSubModuleRepo = async (id: string) => {
  return prisma.subModule.update({
    where: { id },
    data: {
      isDeleted: true,
    },
  });
};
