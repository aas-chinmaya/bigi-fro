import * as repository from "../repository/feature.repository";

export const createFeatureService = async (body: any) => {
  const {
    name,
    route,
    description,
    subModuleId,
    moduleId,
  } = body;

  if (!name?.trim()) {
    return {
      status: 400,
      message: "Name is required",
    };
  }

  if (!subModuleId && !moduleId) {
    return {
      status: 400,
      message: "Either moduleId or subModuleId is required",
    };
  }

  const parsedSubModuleId = subModuleId
    ? String(subModuleId)
    : null;

  const parsedModuleId = moduleId
    ? String(moduleId)
    : null;

  // Priority:
  // SubModule > Module

  const finalSubModuleId = parsedSubModuleId;
  const finalModuleId = parsedSubModuleId
    ? null
    : parsedModuleId;

  if (finalSubModuleId) {
    const subModule =
      await repository.findSubModuleById(finalSubModuleId);

    if (!subModule || subModule.isDeleted) {
      return {
        status: 404,
        message: "SubModule not found",
      };
    }
  }

  if (finalModuleId) {
    const module =
      await repository.findModuleById(finalModuleId);

    if (!module || module.isDeleted) {
      return {
        status: 404,
        message: "Module not found",
      };
    }
  }

  const featureName = name.trim();

  const existing =
    await repository.findFeatureByName(
      featureName,
      finalSubModuleId,
      finalModuleId
    );

  if (existing && !existing.isDeleted) {
    return {
      status: 400,
      message: "Feature already exists",
    };
  }

  if (existing && existing.isDeleted) {
    const updatedFeature =
      await repository.updateFeatureRepo(existing.id, {
        isDeleted: false,
        name: featureName,
        route,
        description,
        subModuleId: finalSubModuleId,
        moduleId: finalModuleId,
      });

    return {
      status: 200,
      message: "Feature re-activated successfully",
      data: updatedFeature,
    };
  }

  const newFeature =
    await repository.createFeatureRepo({
      name: featureName,
      route,
      description,
      subModuleId: finalSubModuleId,
      moduleId: finalModuleId,
    });

  return {
    status: 201,
    message: "Feature created successfully",
    data: newFeature,
  };
};

export const getAllFeaturesService = async (query: any) => {
  const page = Number(query.page) || 1;
  const limit = query.limit ? Number(query.limit) : null;
  const search = (query.search as string) || "";
  const isAll = query.all === "true";

  const whereClause = {
    isDeleted: false,
    ...(search && {
      name: {
        contains: search,
        mode: "insensitive" as const,
      },
    }),
  };

  // Dropdown
  if (isAll) {
    const features =
      await repository.getAllFeaturesDropdownRepo(
        whereClause
      );

    return {
      status: 200,
      message: "All features fetched",
      count: features.length,
      data: features,
    };
  }

  const take = limit || 10;
  const skip = (page - 1) * take;

  const total =
    await repository.countFeaturesRepo(whereClause);

  const features =
    await repository.getAllFeaturesRepo(
      whereClause,
      skip,
      take
    );

  return {
    status: 200,
    message: "Features fetched successfully",
    data: features,
    pagination: {
      total,
      page,
      limit: take,
      totalPages: Math.ceil(total / take),
    },
  };
};

export const getFeaturesBySubModuleService = async (
  subModuleId: string
) => {
  

  const features =
    await repository.getFeaturesBySubModuleRepo(subModuleId);

  return {
    status: 200,
    message: "Features fetched successfully",
    data: features,
  };
};

export const getFeaturesByModuleService = async (
  moduleId: string
) => {

  const features = await repository.getFeaturesByModuleRepo(
    moduleId
  );

  return {
    status: 200,
    message: "Features fetched successfully",
    data: features,
  };
};

export const updateFeatureService = async (
  id: string,
  body: any
) => {

  const {
    name,
    route,
    description,
    subModuleId,
    moduleId,
  } = body;

  const existing = await repository.findFeatureById(id);

  if (!existing || existing.isDeleted) {
    return {
      status: 404,
      message: "Feature not found",
    };
  }

  let updatedName = existing.name;
  let updatedSubModuleId = existing.subModuleId;
  let updatedModuleId = existing.moduleId;

  // If moving under SubModule
  if (subModuleId) {
    const subModule = await repository.findSubModuleById(
      String(subModuleId)
    );

    if (!subModule || subModule.isDeleted) {
      return {
        status: 404,
        message: "SubModule not found",
      };
    }

    updatedSubModuleId = String(subModuleId);
    updatedModuleId = null;
  }

  // If moving directly under Module
  if (moduleId && !subModuleId) {
    const module = await repository.findModuleById(
      String(moduleId)
    );

    if (!module || module.isDeleted) {
      return {
        status: 404,
        message: "Module not found",
      };
    }

    updatedModuleId = String(moduleId);
    updatedSubModuleId = null;
  }

  if (name) {
    updatedName = name.trim();
  }

  const duplicate = await repository.findDuplicateFeature(
    updatedName,
    updatedSubModuleId,
    updatedModuleId,
    id
  );

  if (duplicate && !duplicate.isDeleted) {
    return {
      status: 400,
      message: "Feature already exists",
    };
  }

  const updatedFeature = await repository.updateFeatureRepo(id, {
    name: updatedName,
    route: route ?? existing.route,
    description:
      description ?? existing.description,
    subModuleId: updatedSubModuleId,
    moduleId: updatedModuleId,
  });

  return {
    status: 200,
    message: "Feature updated successfully",
    data: updatedFeature,
  };
};

export const deleteFeatureService = async (id: string) => {

  const existing = await repository.findFeatureById(id);

  if (!existing || existing.isDeleted) {
    return {
      status: 404,
      message: "Feature not found",
    };
  }

  await repository.deleteFeatureRepo(id);

  return {
    status: 200,
    message: "Feature deleted successfully",
  };
};
