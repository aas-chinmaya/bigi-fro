import { Router } from "express";
import { createFeature, deleteFeature, getAllFeatures, getFeaturesBySubModule, updateFeature,getFeaturesByModule } from "../controllers/feature.controller";
import { isAuthenticated } from "../../../../middleware/auth.middleware";
const router = Router();

router.post("/createFeature", createFeature);
router.get("/getAllFeatures", getAllFeatures);
router.get("/getFeaturesByModule/:moduleId", getFeaturesByModule);
router.get("/getFeaturesBySubModule/:subModuleId", getFeaturesBySubModule);
router.put("/updateFeature/:id", updateFeature);
router.delete("/deleteFeature/:id", deleteFeature);

export default router;