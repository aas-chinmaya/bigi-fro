import express from "express";
import salesInvoiceRouter from "../modules/sales/routes/salesInvoice.v1.routes";
import customerRouter from "../modules/customers/routes/customer.v1.routes";
import businessRoute from "../modules/BusinessModule/routes/business.v1.routes";
import businessDocumentRoute from "../modules/BusinessModule/routes/businessDocument.v1.routes";
import businessBankRoute from "../modules/BusinessModule/routes/businessBank.v1.routes";
import businessAddressRoute from "../modules/BusinessModule/routes/businessAddress.v1.routes";
import businessBranchRoute from "../modules/BusinessModule/routes/businessBranch.v1.routes";
import categoryRoute from "../modules/MasterTable/categoryMaster/routes/category.v1.routes";
import subCategoryRoute from "../modules/MasterTable/SubCategory/routes/subCategory.v1.routes";
import currencyRoute from "../modules/MasterTable/currencyMaster/routes/currency.v1.routes";
import industryRoute from "../modules/MasterTable/industryTypeMaster/routes/industry.v1.routes";
import registrationTypeRoute from "../modules/MasterTable/registrationMaster/routes/registrationType.v1.routes"
import apiMasterRoute from "../modules/RBacModule/apiMaster/routes/api.routes.v1";
import featureRoute from "../modules/RBacModule/featureMaster/routes/feature.routes.v1";
import subModuleRoute from "../modules/RBacModule/subModuleMaster/routes/subModule.routes.v1";
import moduleRoute from "../modules/RBacModule/moduleMaster/routes/module.routes.v1";
import roleMasterRoute from "../modules/RBacModule/roleMaster/routes/roleMaster.routes.v1";
import accessRoute from "../modules/RBacModule/roleAccess/routes/access.routes.v1";
import vendorRoute from "../modules/vendor/routes/vendor.routes";
import userRoute from "../modules/UserModule/routes/user.routes.v1";
import productCategoryRoute from "../modules/items/routes/category.route"
import productSubCategoryRoute from "../modules/items/routes/subCategory.routes"
import brandRoute from "../modules/items/routes/brand.routes"
import unitRoute from "../modules/items/routes/unit.routes"
import variantTypeRoute from "../modules/items/routes/variantType.routes"
import variantValueRoute from "../modules/items/routes/variantValue.routes"
import taxRoute from "../modules/items/routes/tax.routes"
import productUnit from "../modules/items/routes/productUnit.routes"
import productRoute from "../modules/items/routes/product.routes"
import paymentRouter from "../modules/sales/routes/payment.v1.routes";
import GlobalDocumentTypes from "../modules/MasterTable/documentTypeMaster/routes/global-document-type.routes";
import vendorCategoryRoute from "../modules/MasterTable/vendorCategory/routes/vendor-category.routes";
import licenseTypeRoute from "../modules/MasterTable/licenseMaster/routes/licenseType.routes";


const router = express.Router();

router.get("/health", (_req, res) => {
  res.json({
    success: true,
    status: "ok",
  });
});

// register routes here
router.use("/sales-invoices", salesInvoiceRouter);
router.use("/customers", customerRouter);
router.use("/payments", paymentRouter);

// register vendor routes
router.use("/vendor", vendorRoute);

// register business module routes
router.use("/business", businessRoute);
router.use("/business/business-documents", businessDocumentRoute);
router.use("/business/business-banks", businessBankRoute);
router.use("/business/business-addresses", businessAddressRoute);
router.use("/business/business-branches", businessBranchRoute);

// register other master module routes 
router.use("/categories", categoryRoute);
router.use("/subcategories", subCategoryRoute);
router.use("/currencies", currencyRoute);
router.use("/industries", industryRoute);
router.use("/registration-types", registrationTypeRoute);

// register rbac module routes 
router.use("/apis", apiMasterRoute);
router.use("/features", featureRoute);
router.use("/submodules", subModuleRoute);
router.use("/modules", moduleRoute);
router.use("/roles", roleMasterRoute);
router.use("/access", accessRoute);
router.use("/auth", userRoute);
router.use("/product-categories", productCategoryRoute);
router.use("/product-subcategories", productSubCategoryRoute);
router.use("/brands", brandRoute);
router.use("/units", unitRoute);
router.use("/variant-types", variantTypeRoute);
router.use("/variant-values", variantValueRoute);
router.use("/taxes", taxRoute);
router.use("/product-units", productUnit);
router.use("/products", productRoute);
router.use("/global-document", GlobalDocumentTypes);
router.use("/vendor-categories", vendorCategoryRoute);
router.use("/license-types", licenseTypeRoute); 


export default router;
