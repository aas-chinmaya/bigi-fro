import * as branchRepository from "../modules/BusinessModule/repository/businessBranch.repository";

export const generateBranchCode = async (
  tenantId: string
): Promise<string> => {
  if (!tenantId) {
    throw new Error("Tenant ID is required");
  }

  // Extract prefix from tenant ID
  // Example:
  // ABCT-Ten-001
  // becomes:
  // ABCT
  const prefix = tenantId
    .split("-")[0]
    .toUpperCase();

  if (!prefix) {
    throw new Error("Invalid Tenant ID");
  }

  // Find latest branch for this tenant
  const latestBranch =
    await branchRepository.findLatestBranchByTenant(
      tenantId
    );

  let nextNumber = 1;

  if (latestBranch?.branchCode) {
    const match = latestBranch.branchCode.match(
      new RegExp(`^${prefix}-BR-(\\d+)$`)
    );

    if (match) {
      nextNumber = Number(match[1]) + 1;
    }
  }

  return `${prefix}-BR-${String(nextNumber).padStart(3, "0")}`;
};

