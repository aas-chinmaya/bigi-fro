// export async function generateVendorCode(prisma: any) {

//     const lastVendor = await prisma.vendor.findFirst({
//         orderBy: {
//             createdAt: "desc"
//         },
//         select: {
//             vendorCode: true
//         }
//     });

//     if (!lastVendor?.vendorCode)
//         return "VEN-001";

//     const number =
//         Number(lastVendor.vendorCode.replace("VEN-", "")) + 1;

//     return `VEN-${String(number).padStart(3, "0")}`;
// }

export async function generateVendorCode(prisma: any) {

    const vendors = await prisma.vendor.findMany({
        where: {
            vendorCode: {
                not: null,
            },
        },
        select: {
            vendorCode: true,
        },
    });

    if (vendors.length === 0) {
        return "VEN-001";
    }

    let maxNumber = 0;

    for (const vendor of vendors) {

        if (!vendor.vendorCode) {
            continue;
        }

        const number = Number(
            vendor.vendorCode.replace("VEN-", "")
        );

        if (!isNaN(number) && number > maxNumber) {
            maxNumber = number;
        }
    }

    return `VEN-${String(maxNumber + 1).padStart(3, "0")}`;
}