export const generateVendorCode = async (prisma: any) => {
  const lastVendor = await prisma.vendor.findFirst({
    orderBy: {
      createdAt: "desc",
    },
    select: {
      vendorCode: true,
    },
  });

  if (!lastVendor || !lastVendor.vendorCode) {
    return "VEN-001";
  }

  const lastNumber = parseInt(
    lastVendor.vendorCode.replace("VEN-", ""),
    10
  );

  return `VEN-${String(lastNumber + 1).padStart(3, "0")}`;
};