import multer from "multer";
import path from "path";
import fs from "fs";

const uploadDir = path.join(
    process.cwd(),
    "uploads",
    "vendor",
    "excel"
);

if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, {
        recursive: true,
    });
}

const storage = multer.diskStorage({
    destination: (_req, _file, cb) => {
        cb(null, uploadDir);
    },

    filename: (_req, file, cb) => {
        const ext = path.extname(file.originalname);

        const fileName = `${Date.now()}-${Math.round(
            Math.random() * 1000000
        )}${ext}`;

        cb(null, fileName);
    },
});

const fileFilter: multer.Options["fileFilter"] = (
    _req,
    file,
    cb
) => {
    const allowedExtensions = [".xlsx", ".xls"];

    const extension = path
        .extname(file.originalname)
        .toLowerCase();

    if (allowedExtensions.includes(extension)) {
        cb(null, true);
    } else {
        cb(new Error("Invalid file type. Only Excel files are allowed."));
    }
};

const excelUpload = multer({
    storage,
    fileFilter,
    limits: {
        fileSize: 10 * 1024 * 1024,
    },
});

export default excelUpload;