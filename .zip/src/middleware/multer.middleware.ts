

import multer from "multer";
import fs from "fs";
import path from "path";

const uploadFactory = (moduleName: string) => {

    const storage = multer.diskStorage({

        destination(req, file, cb) {

            // Folder name comes from the field name
            const uploadPath = path.join(
                process.cwd(),
                "uploads",
                moduleName,
                file.fieldname
            );

            // fs.mkdirSync(uploadPath, {
            //     recursive: true,
            // });

            // cb(null, uploadPath);
             // Only create the folder if it doesn't already exist
            if (!fs.existsSync(uploadPath)) {
                fs.mkdirSync(uploadPath, {
                    recursive: true,
                });
            }

            cb(null, uploadPath);
        },

        filename(req, file, cb) {

            const fileName =
                `${Date.now()}-${Math.round(Math.random() * 1000000)}${path.extname(file.originalname)}`;

            cb(null, fileName);
        }

    });

    return multer({

        storage,

        limits: {
            fileSize: 20 * 1024 * 1024,
        },

        fileFilter(req, file, cb) {

            const allowed = [
                "image/jpeg",
                "image/jpg",
                "image/png",
                "image/webp",
                "application/pdf",
            ];

            if (allowed.includes(file.mimetype)) {
                cb(null, true);
            } else {
                cb(new Error("Invalid file type."));
            }
        }

    });

};

export default uploadFactory;

