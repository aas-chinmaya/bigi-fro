import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import prisma from "../config/db";
import { generateAccessToken } from "../utils/jwt";

const ACCESS_SECRET = process.env.JWT_SECRET as string;
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET as string;

export interface AuthRequest extends Request {
  user?: {
    id: string;
    roleId: string;
    role: string;
  };
}

export const isAuthenticated = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const accessToken = req.cookies?.accessToken;
    const refreshToken = req.cookies?.refreshToken;

    // No tokens at all
    if (!accessToken && !refreshToken) {
      return res.status(401).json({
        message: "Unauthorized: No tokens provided"
      });
    }

    // STEP 1: VERIFY ACCESS TOKEN
    if (accessToken) {
      try {
        const decoded = jwt.verify(accessToken, ACCESS_SECRET) as {
          id: string;
          roleId: string;
          role: string;
        };

        const session = await prisma.session.findFirst({
          where: {
            userId: decoded.id,
            refreshToken,
            isActive: true
          }
        });
        if (!session) {
          return res.status(401).json({
            message: "Unauthorized: Invalid session"
          });
        }

        req.user = decoded;
        return next();

      } catch (error: any) {
        // If NOT expired → invalid token
        if (error.name !== "TokenExpiredError") {
          return res.status(401).json({
            message: "Unauthorized: Invalid token"
          });
        }
        // If expired → try refresh flow
      }
    }
    //  STEP 2: REFRESH TOKEN FLOW
    if (!refreshToken) {
      return res.status(401).json({
        message: "Session expired. Please login again"
      });
    }

    try {
      const decodedRefresh = jwt.verify(refreshToken, REFRESH_SECRET) as {
        id: string;
      };

      const session = await prisma.session.findFirst({
        where: {
          userId: decodedRefresh.id,
          refreshToken,
          isActive: true
        }
      });

      if (!session) {
        return res.status(401).json({
          message: "Session expired. Please login again"
        });
      }
      
      if (session.expiresAt < new Date()) {
        return res.status(401).json({
          message: "Session expired. Please login again"  
        });
      }
      // Fetch user from DB
      const user = await prisma.user.findUnique({
        where: { id: decodedRefresh.id },
        include: { role: true }
      });

      if (!user || user.isDeleted) {
        return res.status(401).json({
          message: "User not found or deleted"
        });
      }

      // Generate new access token
      const newAccessToken = generateAccessToken({
        id: user.id,
        roleId: user.roleId,
        role: user.role.name
      });

      // Set new access token cookie
      res.cookie("accessToken", newAccessToken, {
        httpOnly: true,
        secure: false, // true in production
        sameSite: "lax",
        maxAge: 15 * 60 * 1000 // 15 min
      });

      // Attach user
      req.user = {
        id: user.id,
        roleId: user.roleId,
        role: user.role.name
      };

      return next();

    } catch (error) {
      return res.status(401).json({
        message: "Session expired. Please login again"
      });
    }

  } catch (error) {
    console.error("Auth Middleware Error:", error);

    return res.status(500).json({
      message: "Internal server error"
    });
  }
};
