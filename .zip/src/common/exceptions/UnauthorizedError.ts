import ApiError from "./ApiError";

class UnauthorizedError extends ApiError {
  constructor(message = "Unauthorized access") {
    super(401, message, "UNAUTHORIZED");
  }
}

export default UnauthorizedError;