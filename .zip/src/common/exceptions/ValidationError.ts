// exceptions/ValidationError.ts
import ApiError from "./ApiError";

export class ValidationError extends ApiError {
  public errors?: Record<string, string[] | undefined>;

  constructor(message = "Validation failed", errors?: Record<string, string[] | undefined>) {
    super(400, message, "VALIDATION_ERROR");
    this.errors = errors;
  }
}

export default ValidationError;