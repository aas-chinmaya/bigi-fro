import ApiError from "./ApiError";

class ConflictError extends ApiError {
  constructor(message = "Resource already exists") {
    super(409, message, "CONFLICT");
  }
}

export default ConflictError;