import { Client } from "@microsoft/microsoft-graph-client";
import { ClientSecretCredential } from "@azure/identity";
import "isomorphic-fetch";

type SendEmailPayload = {
  to: string;
  subject: string;
  html: string;
  cc?: string[];
};

const credential = new ClientSecretCredential(
  process.env.AZURE_TENANT_ID as string,
  process.env.AZURE_CLIENT_ID as string,
  process.env.AZURE_CLIENT_SECRET as string
);

const graphClient = Client.initWithMiddleware({
  authProvider: {
    getAccessToken: async (): Promise<string> => {
      const token = await credential.getToken("https://graph.microsoft.com/.default");
      return token.token;
    },
  },
});

export const sendEmail = async ({ to, subject, html, cc = [] }: SendEmailPayload): Promise<void> => {
  const message: Record<string, unknown> = {
    subject,
    body: {
      contentType: "HTML",
      content: html,
    },
    toRecipients: [
      {
        emailAddress: {
          address: to,
        },
      },
    ],
  };

  if (cc.length) {
    message.ccRecipients = cc.map((email) => ({
      emailAddress: {
        address: email,
      },
    }));
  }

  await graphClient.api(`/users/${process.env.SENDER_EMAIL}/sendMail`).post({
    message,
    saveToSentItems: true,
  });
};