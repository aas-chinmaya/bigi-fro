import fs from "fs";
import path from "path";

const deleteFile = (filePath?: string | null): void => {
  if (!filePath) return;

  const fullPath = path.join(process.cwd(), "uploads", filePath);

  if (fs.existsSync(fullPath)) {
    fs.unlinkSync(fullPath);
  }
};

export default deleteFile;