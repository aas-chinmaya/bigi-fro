import app from "./app";
import prisma from "./config/db";

const port = Number(process.env.PORT || 5000);

const startServer = async (): Promise<void> => {
  try {
    await prisma.$connect();
    console.log("Prisma connected to PostgreSQL");
  } catch (error) {
    console.error("Failed to connect to PostgreSQL:", error);
    process.exit(1);
  }

  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
};

void startServer();
